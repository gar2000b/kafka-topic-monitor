# kafka-topic-register

<b>NOTE:</b> Please ensure to change the <b>?version=</b> param in html, if you are updating any js/css