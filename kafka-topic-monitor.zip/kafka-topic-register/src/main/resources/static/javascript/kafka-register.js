var app = angular.module("myApp", [ "ngRoute" ]);

app.controller("kafka-request-controller", function($scope, $http) {

	$scope.generate = function() {

		var consumerGroup = "";
		var valid = true;

		if ($scope.topic == "" || $scope.serviceId == ""
				|| $scope.password == "" || $scope.domain == ""
				|| $scope.topic == null || $scope.serviceId == null
				|| $scope.password == null || $scope.domain == null) {
			alert("Input fields cannot be left empty.");
			valid = false;
		} else if ($scope.consumerGroupOption == "" || $scope.environment == ""
				| $scope.consumerGroupOption == null
				|| $scope.environment == null) {
			alert("Make sure to select an option from all the select boxes.");
			valid = false;
		} else if ($scope.processorType == null) {
			alert("Please select the processor type");
			valid = false;
		} else if ($scope.consumerGroupNumber == null) {
			if ($scope.consumerGroupOption == "-cg"
					|| $scope.consumerGroupOption == "-fcg") {
				alert("Please enter the Consumer Group Number");
				valid = false;
			}
		}

		if (valid) {

			if ($scope.consumerGroupOption == "-monitor") {
				consumerGroup = $scope.topic + $scope.consumerGroupOption;
			} else if ($scope.consumerGroupOption == "-cg"
					|| $scope.consumerGroupOption == "-fcg") {
				consumerGroup = $scope.topic + $scope.consumerGroupOption
						+ $scope.consumerGroupNumber;
			} else if ($scope.consumerGroupOption == "other") {
				consumerGroup = $scope.consumerGroup;
			}

			var kafka_request_url = "/v1/topic-detail?";
			kafka_request_url += "&topic=" + $scope.topic;
			kafka_request_url += "&consumer-group=" + consumerGroup;
			kafka_request_url += "&environment=" + $scope.environment;
			kafka_request_url += "&processor-type=" + $scope.processorType;
			kafka_request_url += "&service-id=" + $scope.serviceId;
			kafka_request_url += "&password=" + $scope.password;
			kafka_request_url += "&domain=" + $scope.domain;

			var rawResponse = function(value) {
				return value;
			};

			$http({
				method : "GET",
				url : kafka_request_url,
				transformResponse : rawResponse
			}).then(function(response) {
				$scope.payload = response.data;
			});
		}
	}
});