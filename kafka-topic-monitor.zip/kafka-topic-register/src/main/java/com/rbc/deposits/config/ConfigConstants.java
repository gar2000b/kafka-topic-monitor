package com.rbc.deposits.config;

public class ConfigConstants {

    //--------------------------------------------------
    // Service Constants
    //--------------------------------------------------
    public static final String CENTER_CODE_TRANSIT_NUMBER_SERVICE = "centerCodeTransitNumberService";
    public static final String CENTER_CODE_TRANSIT_NUMBER_SERVICE_IMPL = "centerCodeTransitNumberServiceImpl";

    //--------------------------------------------------
    // DAO Constants
    //--------------------------------------------------
    public static final String CENTER_CODE_DAO = "centerCodeDao";
}
