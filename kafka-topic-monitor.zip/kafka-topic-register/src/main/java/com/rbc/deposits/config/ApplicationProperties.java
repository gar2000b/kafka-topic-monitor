package com.rbc.deposits.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Application Properties.
 * 
 * @author 330885096
 *
 */
@Configuration
public class ApplicationProperties {

    @Value("${authentication.basic.realm:#{'DEPOSITS'}}")
    private String authenticationBasicRealm;
    
    @Value("${authentication.username:#{'username'}}")
    private String authenticationUsername;

    @Value("${authentication.password:#{'password'}}")
    private String authenticationPassword;

    @Value("${application.env-code}")
    private String applicationEnvCode;

    /**
     * Get the authenticationBasicRealm.
     * 
     * @return the authenticationBasicRealm
     */
    public String getAuthenticationBasicRealm() {
        return authenticationBasicRealm;
    }
    
    /**
     * Get the authenticationUsername.
     * 
     * @return the authenticationUsername
     */
    public String getAuthenticationUsername() {
        return authenticationUsername;
    }

    /**
     * Get the authenticationPassword.
     * 
     * @return the authenticationPassword
     */
    public String getAuthenticationPassword() {
        return authenticationPassword;
    }

    /**
     * Get the getApplicationEnvCode.
     * 
     * @return the applicationEnvCode
     */
    public String getApplicationEnvCode() {
        return applicationEnvCode;
    }
}
