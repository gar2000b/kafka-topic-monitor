package com.rbc.deposits.rest;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.util.Base64;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rbc.deposits.config.ApplicationProperties;

@Controller
@EnableAutoConfiguration
public class TopicRegistrationController {

    @Autowired
    private ApplicationProperties applicationProperties;

    private static final String TOPIC_REGISTRATION_PATH = "/v1/topic-detail";

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @RequestMapping(method = RequestMethod.GET, produces = "text/plain", value = TOPIC_REGISTRATION_PATH)
    @ResponseBody
    public String generateTopicRegistrationPayload(@RequestParam("topic") String topic, @RequestParam("consumer-group") String consumerGroup, @RequestParam("environment") String environment,
                    @RequestParam("processor-type") String processorType, @RequestParam("service-id") String serviceId, @RequestParam("password") String password,
                    @RequestParam("domain") String domain,
                    HttpServletRequest request,
                    HttpServletResponse response) {

        final String envCode = applicationProperties.getApplicationEnvCode();

        topic = addHyphensAndLowerCase(topic);

        logger.debug("**** incoming generateTopicRegistrationPayload() request ****");
        logger.debug("**** topic: {} ****", topic);
        logger.debug("**** consumerGroup: {} ****", consumerGroup);
        logger.debug("**** environment: {} ****", environment);
        logger.debug("**** processorType: {} ****", processorType);
        logger.debug("**** serviceId: {} ****", serviceId);
        logger.debug("**** domain: {} ****", domain);

        String jaasConfig = "";
        if (processorType.equals("consumer")) {
            jaasConfig = "jaasConsumerConf";
        } else if (processorType.equals("producer")) {
            jaasConfig = "jaasProducerConf";
        }

        String encodedKeytab = null;

        if (envCode.equals("l")) {
            encodedKeytab = "*** NO KEYTAB AVAILABLE IN LOCAL ENVIRONMENT ***";
        } else {
            encodedKeytab = generateEncodedKeytab(serviceId, domain, password);
        }

        String payload = "{\"topic\":\"" + topic
                        + "\", \"consumerGroup\":\"" + consumerGroup
                        + "\", \"environment\":\"" + environment + "\", \"" + jaasConfig
                        + "\":\"com.sun.security.auth.module.Krb5LoginModule required doNotPrompt=true "
                        + "refreshKrb5Config=true useKeyTab=true storeKey=true keyTab='{keytabFile}' principal='"
                        + serviceId
                        + "@" + domain
                        + "';\", \"keytabFilename\":\"" + serviceId + ".keytab\", \"keytab\":\"" + encodedKeytab + "\"}";

        return payload;
    }

    private String generateEncodedKeytab(String serviceId, String domain, String password) {
        // removeOldKeytabFile(serviceId);
        generateKeytabFile(serviceId, domain, password);
        try {
            Thread.sleep(1500);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        String encodedKeytab = loadAndEncodeKeytab(serviceId);
        removeOldKeytabFile(serviceId);
        return encodedKeytab;
    }

    private String loadAndEncodeKeytab(String serviceId) {
        File file = new File(serviceId + ".keytab");
        byte[] keytab = null;
        String encodedKeytab = null;
        try {
            keytab = Files.readAllBytes(file.toPath());
            logger.debug("**** keytab: " + keytab.toString() + " ***");
            encodedKeytab = Base64.getMimeEncoder().encodeToString(keytab);
        } catch (Exception e) {
            logger.error(e.getMessage());
            logger.error("*** No Keytab Available ***");
        }

        return encodedKeytab;
    }

    private void generateKeytabFile(String serviceId, String domain, String password) {
        try {
            ProcessBuilder builder = new ProcessBuilder("/bin/bash");
            Process exec = builder.start();

            try {
                OutputStream outputStream = exec.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));

                bufferedWriter.write("ktutil");
                bufferedWriter.newLine();
                bufferedWriter.flush();

                bufferedWriter.write("addent -password -p " + serviceId + "@" + domain + " -k 1 -e rc4-hmac");
                bufferedWriter.newLine();
                bufferedWriter.flush();

                bufferedWriter.write(password);
                bufferedWriter.newLine();
                bufferedWriter.flush();

                bufferedWriter.write("wkt " + serviceId + ".keytab");
                bufferedWriter.newLine();
                bufferedWriter.flush();

                bufferedWriter.write("q");
                bufferedWriter.newLine();
                bufferedWriter.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    private void removeOldKeytabFile(String serviceId) {
        File file = new File(serviceId + ".keytab");
        file.delete();
    }

    private String addHyphensAndLowerCase(String topicName) {
        topicName = topicName.trim();
        if (StringUtils.contains(topicName, StringUtils.SPACE)) {
            return topicName.replace(StringUtils.SPACE, "-").toLowerCase();
        }
        return topicName.toLowerCase();
    }

}
