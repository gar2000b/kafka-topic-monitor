package com.rbc.deposits;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main application entry point.
 * 
 * @author 330885096
 *
 */
@SpringBootApplication
public class KafkaTopicRegister {

    public static void main(String[] args) {
        SpringApplication.run(KafkaTopicRegister.class, args);
    }
}
