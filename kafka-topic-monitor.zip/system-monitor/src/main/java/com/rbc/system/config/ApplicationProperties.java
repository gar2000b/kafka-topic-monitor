package com.rbc.system.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationProperties {

    @Value("${application.env-code}")
    private String applicationEnvCode;

    @Value("${authentication.username:#{'username'}}")
    private String authenticationUsername;

    @Value("${authentication.password:#{'password'}}")
    private String authenticationPassword;

    @Value("${email.notification_elapsed_time}")
    private int notificationElapsedTime;

    @Value("${email.host}")
    private String host;

    @Value("${email.from}")
    private String from;

    @Value("${email.replyTo}")
    private String replyTo;

    @Value("${email.recipients}")
    private String recipients;

    @Value("${ad.ldapUrl}")
    private String adUrl;

    @Value("${ad.baseDn}")
    private String adBase;

    @Value("${ad.group}")
    private String group;

    @Value("${ultimate-answer}")
    private String ultimateAnswer;

    public String getApplicationEnvCode() {
        return applicationEnvCode;
    }

    public void setApplicationEnvCode(String applicationEnvCode) {
        this.applicationEnvCode = applicationEnvCode;
    }

    public String getAuthenticationUsername() {
        return authenticationUsername;
    }

    public void setAuthenticationUsername(String authenticationUsername) {
        this.authenticationUsername = authenticationUsername;
    }

    public String getAuthenticationPassword() {
        return authenticationPassword;
    }

    public void setAuthenticationPassword(String authenticationPassword) {
        this.authenticationPassword = authenticationPassword;
    }

    public int getNotificationElapsedTime() {
        return notificationElapsedTime;
    }

    public void setNotificationElapsedTime(int notificationElapsedTime) {
        this.notificationElapsedTime = notificationElapsedTime;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getReplyTo() {
        return replyTo;
    }

    public void setReplyTo(String replyTo) {
        this.replyTo = replyTo;
    }

    public String getRecipients() {
        return recipients;
    }

    public void setRecipients(String recipients) {
        this.recipients = recipients;
    }

    public String getAdUrl() {
        return adUrl;
    }

    public void setAdUrl(String adUrl) {
        this.adUrl = adUrl;
    }

    public String getAdBase() {
        return adBase;
    }

    public void setAdBase(String adBase) {
        this.adBase = adBase;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getUltimateAnswer() {
        return ultimateAnswer;
    }

    public void setUltimateAnswer(String ultimateAnswer) {
        this.ultimateAnswer = ultimateAnswer;
    }
}
