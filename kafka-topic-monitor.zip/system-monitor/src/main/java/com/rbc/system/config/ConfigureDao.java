package com.rbc.system.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;

import com.rbc.system.dao.WorkspaceDao;
import com.rbc.system.dao.impl.RedisWorkspaceDaoImpl;

/**
 * Configure the JDBC DAO implementations.
 * 
 * @author 330885096
 *
 */
@Configuration
public class ConfigureDao {

    private Logger logger = LoggerFactory.getLogger(this.getClass());


    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    @Bean(name = ConfigConstants.WORKSPACE_DAO)
    public WorkspaceDao workspaceDao() {
        if (logger.isDebugEnabled()) {
            logger.debug("Configuring bean workspaceDao");
        }

        RedisWorkspaceDaoImpl redisWorkspaceDaoImpl = new RedisWorkspaceDaoImpl(redisTemplate);
        logger.info("*** returning redisWorkspaceDaoImpl");
        return redisWorkspaceDaoImpl;
    }
}
