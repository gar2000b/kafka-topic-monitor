package com.rbc.system.util;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * JsonMessageConverter.
 * 
 * @author 316746874
 *
 */
public class JsonMessageConverter {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    private Class<?> clazz;

    private boolean pretty;

    /**
     * Create a JsonMessageConverter for a specific class type.
     * 
     * @param clazz the Class
     */
    public JsonMessageConverter(Class<?> clazz) {
        this.clazz = clazz;
    }

    public JsonMessageConverter setPretty(boolean pretty) {
        this.pretty = pretty;
        return this;
    }

    public void marshal(Object object, String filename) throws Exception {
        this.marshal(object, new File(filename));
    }

    public void marshal(Object object, File file) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("JSON marshal [{}] to [{}]", object.getClass().getName(), file.getPath());
        }

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        objectMapper.configOverride(List.class).setInclude(JsonInclude.Value.construct(JsonInclude.Include.NON_EMPTY, null));
        objectMapper.configOverride(Map.class).setInclude(JsonInclude.Value.construct(JsonInclude.Include.NON_EMPTY, null));
        if (pretty) {
            objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        }

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        objectMapper.setDateFormat(dateFormat);
        objectMapper.writeValue(file, object);
    }

    public String marshal(Object object) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("JSON marshal object [{}]", object.getClass().getName());
        }

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        objectMapper.configOverride(List.class).setInclude(JsonInclude.Value.construct(JsonInclude.Include.NON_EMPTY, null));
        objectMapper.configOverride(Map.class).setInclude(JsonInclude.Value.construct(JsonInclude.Include.NON_EMPTY, null));
        if (pretty) {
            objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        }

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        objectMapper.setDateFormat(dateFormat);

        String json = objectMapper.writeValueAsString(object);

        return json;
    }

    public Object unmarshal(File file) throws Exception {
        if (clazz == null) {
            throw new Exception("class type is undefined");
        }
        if (logger.isDebugEnabled()) {
            logger.debug("unmarshal JSON file [{}]", file.getAbsoluteFile());
        }

        ObjectMapper objectMapper = new ObjectMapper();
        Object object = objectMapper.readValue(file, clazz);

        return object;
    }

    public Object unmarshal(String json) throws Exception {
        if (clazz == null) {
            throw new Exception("class type is undefined");
        }
        Object object = null;

        ObjectMapper objectMapper = new ObjectMapper();
        object = objectMapper.readValue(json, clazz);

        if (logger.isDebugEnabled()) {
            logger.debug("unmarshal JSON string to [{}]", object.getClass().getSimpleName());
        }

        return object;
    }
}
