package com.rbc.system.context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

/**
 * Listener for {@link ContextRefreshedEvent}.
 * 
 * <p>
 * This listener will initiate any required boot strap processing.
 * </p>
 * 
 * @author 316746874
 * 
 */
@Component
public class ContextRefreshedEventListener implements ApplicationListener<ContextRefreshedEvent> {

    private Logger logger = LoggerFactory.getLogger(this.getClass());


    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (logger.isDebugEnabled()) {
            logger.debug("Received ContextRefreshedEvent");
        }

        @SuppressWarnings("unused")
        ApplicationContext applicationContext = event.getApplicationContext();
    }
}
