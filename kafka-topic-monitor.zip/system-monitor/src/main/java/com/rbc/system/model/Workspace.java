package com.rbc.system.model;

public class Workspace {
    private Long workspaceId;
    private String name;
    private WorkspaceState workspaceState;

    /**
     * Default constructor.
     */
    public Workspace() {}

    public Workspace(Long workspaceId, String name, WorkspaceState workspaceState) {
        this.workspaceId = workspaceId;
        this.name = name;
        this.workspaceState = workspaceState;
    }

    public Long getWorkspaceId() {
        return workspaceId;
    }

    public void setWorkspaceId(Long workspaceId) {
        this.workspaceId = workspaceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public WorkspaceState getWorkspaceState() {
        return workspaceState;
    }

    public void setWorkspaceState(WorkspaceState workspaceState) {
        this.workspaceState = workspaceState;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Workspace [workspaceId=");
        builder.append(workspaceId);
        builder.append(", name=");
        builder.append(name);
        builder.append(", workspace=");
        builder.append(workspaceState);
        builder.append("]");
        return builder.toString();
    }
}
