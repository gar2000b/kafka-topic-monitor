package com.rbc.system.health;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.info.BuildProperties;
import org.springframework.stereotype.Component;

import com.rbc.deposits.config.vcap.VcapUtil;
import com.rbc.deposits.health.CoreHealthStatus;
import com.rbc.system.config.ApplicationProperties;

@Component
public class CoreHealthIndicator implements HealthIndicator {

    @Autowired
    private BuildProperties buildProperties;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private CoreHealthStatus coreHealthStatus;

    @Override
    public Health health() {
        String envCode = applicationProperties.getApplicationEnvCode();

        int errorCode = 0;
        if (errorCode != 0) {
            return Health.down()
                            .withDetail("Error Code", errorCode)
                            .build();
        }

        if (envCode.equals("l") || envCode.equals("i") || envCode.equals("di")) {
            return Health.up()
                            .withDetail("app", "Alive and Kicking")
                            .withDetail("version", buildProperties.getVersion())
                            .withDetail("dateTime", coreHealthStatus.getFormatedDateTime().toString())
                            .build();
        } else {
            return Health.up()
                            .withDetail("app", "Alive and Kicking")
                            .withDetail("version", buildProperties.getVersion())
                            .withDetail("dateTime", coreHealthStatus.getFormatedDateTime().toString())
                            .withDetail("applicationId", VcapUtil.getApplicationId())
                            .build();
        }
    }
}
