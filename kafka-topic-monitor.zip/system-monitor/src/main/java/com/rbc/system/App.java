package com.rbc.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.rbc.system", "com.rbc.deposits"})
public class App {

    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }
}
