package com.rbc.system.config;

public class ConfigConstants {

    //--------------------------------------------------
    // Service Constants
    //--------------------------------------------------
    public static final String WORKSPACE_SERVICE = "workspaceService";

    //--------------------------------------------------
    // DAO Constants
    //--------------------------------------------------
    public static final String WORKSPACE_DAO = "workspaceDao";
}
