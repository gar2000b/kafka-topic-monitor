package com.rbc.system.health;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.codec.binary.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.rbc.deposits.email.EmailFactory;
import com.rbc.deposits.kafka.KafkaProperties;
import com.rbc.deposits.rest.client.ClientException;
import com.rbc.deposits.rest.client.ClientResponse;
import com.rbc.deposits.rest.client.handlers.GetHandler;
import com.rbc.system.config.ApplicationProperties;
import com.rbc.system.model.Workspace;
import com.rbc.system.model.WorkspaceState;
import com.rbc.system.service.WorkspaceService;

@Component
@EnableAutoConfiguration
@EnableScheduling
public class HealthPoller {
    private static final String DATE_FORMAT = "EEE MMM d HH:mm:ss z yyyy";
    private static final String CORE = "core";
    private static final int CORE_END_OFFSET = 19;
    private static final int CORE_START_OFFSET = 17;
    private static final String STATUS_UP = "UP";

    public static final String EMPTY = "";
    public static final String HEALTH_ENDPOINT_CLASS = "health-endpoint";
    public static final String HTML_BODY_START = "<html><body>";
    public static final String HTML_BODY_END = "</body></html>";
    public static final String HEALTH_PAYLOAD_KEY = "health_payload";
    public static final String LAST_UNHEALTHY_DATETIME_KEY = "last_unhealthy_datetime";
    public static final String LAST_SENT_NOTIFICATION_DATETIME_KEY = "last_sent_notification_datetime";

    public static Map<String, Map<String, String>> cache = new HashMap<>();

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private KafkaProperties kafkaProperties;

    @Autowired
    private WorkspaceService workspaceService;

    @Autowired
    private EmailFactory emailFactory;

    /**
     * Initializes the cache by loading in each and every health endpoint for subsequent polling.
     */
    @PostConstruct
    private void init() {
        if (logger.isDebugEnabled()) {
            logger.debug("**** init() called ****");
        }
        List<Workspace> workspaces = workspaceService.retrieveWorkspaces();
        for (Workspace workspace : workspaces) {
            WorkspaceState workspaceState = workspace.getWorkspaceState();
            String dom = StringUtils.newStringUtf8(org.apache.commons.codec.binary.Base64.decodeBase64(workspaceState.getDom()));
            dom = HTML_BODY_START + dom + HTML_BODY_END;
            Document doc = Jsoup.parse(dom);
            Elements elements = doc.getElementsByClass(HEALTH_ENDPOINT_CLASS);
            for (Element element : elements) {
                cache.put(element.val(), new HashMap<>());
                cache.get(element.val()).put(HEALTH_PAYLOAD_KEY, HealthPoller.EMPTY);
                if (logger.isDebugEnabled()) {
                    logger.debug("Workspace name: " + workspace.getName() + " - workspace id: " + workspace.getWorkspaceId() + " - key: " + element.val() + " - value: " + cache.get(element.val()));
                }
            }
        }

        System.out.println("The answer to life, the universe and everything is: " + applicationProperties.getUltimateAnswer());
         System.out.println(kafkaProperties.getTopicConfigs().get("student-segment-filter-service_zgv0-d-bda-account-open-event_producer").getKeytab());
    }

    /**
     * Periodically polls all health endpoints in our cache.
     * 
     */
    @Scheduled(fixedRate = 10000)
    private void pollHealthchecks() {
        GetHandler<String> getHander = new GetHandler<>(applicationProperties.getApplicationEnvCode(), true);
        for (Map.Entry<String, Map<String, String>> entry : cache.entrySet()) {
            try {
                ClientResponse<String> clientResponse = getHander.exec(entry.getKey(), String.class);
                String json = clientResponse.getValue();
                if (logger.isDebugEnabled()) {
                    logger.debug("{} - clientResponse {}", entry.getKey(), clientResponse);
                }
                if (clientResponse.getHttpStatus() == HttpStatus.OK) {
                    String core = null;
                    if (json.contains(CORE)) {
                        core = json.substring(json.indexOf(CORE) + CORE_START_OFFSET, json.indexOf(CORE) + CORE_END_OFFSET);
                    }
                    if (core == null || !core.equals(STATUS_UP)) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("*** service down " + entry.getKey() + " appears to be down.");
                            logger.debug("*** service down " + entry.getValue().get(HEALTH_PAYLOAD_KEY));
                        }
                        sendUnhealthyEmailNotification(entry, "<br/><br/>" + json);
                        if (logger.isDebugEnabled()) {
                            logger.debug("*** service down " + entry.getValue().get(LAST_UNHEALTHY_DATETIME_KEY));
                        }
                    } else {
                        if (logger.isDebugEnabled()) {
                            logger.debug("*** service up " + entry.getKey() + " appears to be up.");
                            logger.debug("*** service up " + entry.getValue().get(HEALTH_PAYLOAD_KEY));
                        }
                        sendhealthyEmailNotification(entry);
                        if (logger.isDebugEnabled()) {
                            logger.debug("*** service up " + entry.getValue().get(LAST_UNHEALTHY_DATETIME_KEY));
                        }
                    }
                    entry.getValue().put(HEALTH_PAYLOAD_KEY, json);
                } else {
                    if (logger.isDebugEnabled()) {
                        logger.debug("*** HTTP Status: " + clientResponse.getHttpStatus());
                        logger.debug("*** !OK service " + entry.getKey() + " appears to be down.");
                        logger.debug("*** !OK service " + entry.getValue().get(HEALTH_PAYLOAD_KEY));
                    }
                    entry.getValue().put(HEALTH_PAYLOAD_KEY, "{}");
                    sendUnhealthyEmailNotification(entry, EMPTY);
                    // cache.get(entry.getKey()).put(LAST_UNHEALTHY_DATETIME_KEY, new Date().toString());
                    if (logger.isDebugEnabled()) {
                        logger.debug("*** service " + entry.getValue().get(LAST_UNHEALTHY_DATETIME_KEY));
                    }
                }
            } catch (ClientException e) {
                if (logger.isDebugEnabled()) {
                    logger.debug("*** other exception service " + entry.getKey() + " appears to be down.");
                    logger.debug("*** other exception service " + entry.getValue().get(HEALTH_PAYLOAD_KEY));
                }
                entry.getValue().put(HEALTH_PAYLOAD_KEY, "{}");
                sendUnhealthyEmailNotification(entry, EMPTY);
                // cache.get(entry.getKey()).put(LAST_UNHEALTHY_DATETIME_KEY, new Date().toString());
                if (logger.isDebugEnabled()) {
                    logger.debug("*** service " + entry.getValue().get(LAST_UNHEALTHY_DATETIME_KEY));
                }
                continue;
            }
        }
    }

    private void sendhealthyEmailNotification(Map.Entry<String, Map<String, String>> entry) {
        if (cache.get(entry.getKey()).get(LAST_SENT_NOTIFICATION_DATETIME_KEY) != null && !cache.get(entry.getKey()).get(LAST_SENT_NOTIFICATION_DATETIME_KEY).equals(EMPTY)) {
            cache.get(entry.getKey()).put(LAST_SENT_NOTIFICATION_DATETIME_KEY, null);
            sendEmail("Deposit Support,<br/><br/>This is to notify you that the service on: " + entry.getKey() + " is healthy.", "Service Healthy");
        }
    }

    private void sendUnhealthyEmailNotification(Map.Entry<String, Map<String, String>> entry, String json) {
        Date datetime = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        Date lastSentNotificationDateTime;

        if (cache.get(entry.getKey()).get(LAST_SENT_NOTIFICATION_DATETIME_KEY) != null && !cache.get(entry.getKey()).get(LAST_SENT_NOTIFICATION_DATETIME_KEY).equals(EMPTY)) {
            try {
                lastSentNotificationDateTime = sdf.parse(cache.get(entry.getKey()).get(LAST_SENT_NOTIFICATION_DATETIME_KEY));
                long diffInMillies = Math.abs(datetime.getTime() - lastSentNotificationDateTime.getTime());
                long diff = TimeUnit.HOURS.convert(diffInMillies, TimeUnit.MILLISECONDS);
                if (diff >= applicationProperties.getNotificationElapsedTime()) {
                    // send unhealthy notification
                    sendEmail("Deposit Support,<br/><br/>This is to notify you that the service on: " + entry.getKey() + " is unhealthy." + json, "Service Unhealthy");
                    cache.get(entry.getKey()).put(LAST_SENT_NOTIFICATION_DATETIME_KEY, datetime.toString());
                }
            } catch (ParseException e) {
                logger.error(e.getMessage());
            }
        } else {
            // send unhealthy notification
            sendEmail("Deposit Support,<br/><br/>This is to notify you that the service on: " + entry.getKey() + " is unhealthy.", "Service Unhealthy");
            cache.get(entry.getKey()).put(LAST_SENT_NOTIFICATION_DATETIME_KEY, datetime.toString());
        }

        cache.get(entry.getKey()).put(LAST_UNHEALTHY_DATETIME_KEY, datetime.toString());
    }

    private void sendEmail(String message, String subject) {
        String host = applicationProperties.getHost();
        String from = applicationProperties.getFrom();
        String replyTo = applicationProperties.getReplyTo();
        String recipients = applicationProperties.getRecipients();
        String alt = message;

        String envCode = applicationProperties.getApplicationEnvCode();

        if (envCode.equals("l")) {
            if (logger.isDebugEnabled()) {
                logger.debug("*** mock email sent | " + subject + " | " + message + " | " + host + " | " + from + " | " + replyTo + " | " + recipients + " | " + alt + " ***");
            }
        } else {
            emailFactory.getEmailUtil().fireEmail(subject, message);
        }
    }

    /**
     * Periodically purges all leftover/redundant health endpoints in our cache.
     * 
     */
    @Scheduled(fixedRate = 300000)
    private void purgeHealthchecks() {
        Map<String, Map<String, String>> tempCache = loadTempCache();

        Iterator<String> it = HealthPoller.cache.keySet().iterator();
        while (it.hasNext()) {
            String key = it.next();
            if (tempCache.get(key) == null) {
                cache.remove(key);
                logger.info("Entry {} removed", key);
            }
        }
    }

    private Map<String, Map<String, String>> loadTempCache() {
        Map<String, Map<String, String>> tempCache = new HashMap<>();
        List<Workspace> workspaces = workspaceService.retrieveWorkspaces();
        for (Workspace workspace : workspaces) {
            WorkspaceState workspaceState = workspace.getWorkspaceState();
            String dom = StringUtils.newStringUtf8(org.apache.commons.codec.binary.Base64.decodeBase64(workspaceState.getDom()));
            dom = HTML_BODY_START + dom + HTML_BODY_END;
            Document doc = Jsoup.parse(dom);
            Elements elements = doc.getElementsByClass(HEALTH_ENDPOINT_CLASS);
            for (Element element : elements) {
                tempCache.put(element.val(), new HashMap<>());
                tempCache.get(element.val()).put(HEALTH_PAYLOAD_KEY, HealthPoller.EMPTY);
            }
        }
        return tempCache;
    }
}
