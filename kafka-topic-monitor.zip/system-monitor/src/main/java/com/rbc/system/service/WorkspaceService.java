package com.rbc.system.service;

import java.util.List;

import com.rbc.system.model.Workspace;

public interface WorkspaceService {

    /**
     * Create a new Workspace.
     * 
     * @param workspace the Workspace
     * @return the unique identifier for the Workspace
     * @throws ServiceRuntimeException on any store error
     */
    long createWorkspace(Workspace workspace) throws ServiceRuntimeException;
    
    public Workspace retrieveWorkspace(long workspaceId) throws ServiceRuntimeException;
    
    Workspace retrieveWorkspace(String name) throws ServiceRuntimeException;
    
    public List<Workspace> retrieveWorkspaces() throws ServiceRuntimeException;
    
    public int updateWorkspace(Workspace workspace) throws ServiceRuntimeException;
    
    public int deleteWorkspace(long workspaceId) throws ServiceRuntimeException;
}
