package com.rbc.system;

/**
 * URITemplates defines the URI resources for REST access.
 * 
 * @author 330885096
 *
 */
public class UriTemplates {

    public static final String WORKSPACES = "/workspaces";
    
    public static final String WORKSPACE_ID = "/workspaces/{workspaceId}";
    
    public static final String WORKSPACE_NAME = "/workspaces/name/{workspaceName}";
    
    public static final String SESSION_ALIVE = "/isSessionAlive";
}
