package com.rbc.system.rest;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbc.system.UriTemplates;
import com.rbc.system.health.HealthPoller;
import com.rbc.system.model.Workspace;
import com.rbc.system.model.WorkspaceState;
import com.rbc.system.service.WorkspaceService;
import com.rbc.system.util.JsonMessageConverter;

@Controller
@EnableAutoConfiguration
public class HealthcheckController {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private WorkspaceService workspaceService;

    /**
     * Request healthcheck status against a given endpoint.
     * 
     * @param endpoint to check against
     * @return healthcheck status
     */
    @RequestMapping(method = RequestMethod.GET, produces = "application/json", value = "/healthcheck")
    @ResponseBody
    public String healthcheck(@RequestParam("endpoint") String endpoint, HttpServletRequest request, HttpServletResponse response) {
        String url = StringUtils.newStringUtf8(org.apache.commons.codec.binary.Base64.decodeBase64(endpoint));
        if (HealthPoller.cache.get(url) == null) {
            HealthPoller.cache.put(url, new HashMap<>());
        }
        String healthPayload = HealthPoller.cache.get(url).get(HealthPoller.HEALTH_PAYLOAD_KEY);
        String mainPayload = healthPayload.substring(0, healthPayload.length() - 1);
        if (healthPayload.equals("{}")) {
            healthPayload = mainPayload + "\"last_unhealthy_datetime\":\"" + HealthPoller.cache.get(url).get(HealthPoller.LAST_UNHEALTHY_DATETIME_KEY) + "\"}";
        } else {
            healthPayload = mainPayload + ", \"last_unhealthy_datetime\":\"" + HealthPoller.cache.get(url).get(HealthPoller.LAST_UNHEALTHY_DATETIME_KEY) + "\"}";
        }
        return healthPayload;
    }

    @RequestMapping(method = RequestMethod.GET, produces = "application/json", value = "/token")
    @ResponseBody
    public String token(HttpServletRequest request, HttpServletResponse response) {
        CsrfToken token = (CsrfToken) request.getAttribute("_csrf");
        response.setHeader("X-CSRF-HEADER", token.getHeaderName());
        response.setHeader("X-CSRF-PARAM", token.getParameterName());
        response.setHeader("X-CSRF-TOKEN", token.getToken());
        return token.getToken();
    }

    /**
     * Creates a new workspace.
     * 
     * @param workspaceIn workspace
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    @RequestMapping(value = UriTemplates.WORKSPACES, method = RequestMethod.POST)
    public void createworkspace(
                    @RequestParam("workspace_in") String workspaceIn,
                    HttpServletRequest request,
                    HttpServletResponse response) {
        ObjectMapper objectMapper = new ObjectMapper();
        Workspace workspace = null;
        try {
            workspace = objectMapper.readValue(workspaceIn, Workspace.class);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Long workspaceId = workspaceService.createWorkspace(workspace);
        logger.info("createworkspace, id = " + workspaceId);
        registerHealthchecks(workspace);

        response.addHeader(HttpHeaders.LOCATION, UriTemplates.WORKSPACE_ID.replace("{workspaceId}", workspaceId.toString()));
        response.setStatus(HttpStatus.CREATED.value());
        logger.info("workspace " + workspaceId + " created");
    }

    /**
     * Get workspace by id.
     * 
     * @param workspaceId workspaceId
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @return workspace
     */
    @RequestMapping(value = UriTemplates.WORKSPACE_ID, method = RequestMethod.GET)
    @ResponseBody
    public Workspace getWorkspaceById(
                    @PathVariable("workspaceId") String workspaceId,
                    HttpServletRequest request,
                    HttpServletResponse response) {
        if (logger.isDebugEnabled()) {
            logger.debug("received get request for Workspace [{}]", workspaceId);
        }

        Workspace workspace;
        try {
            workspace = workspaceService.retrieveWorkspace(Long.parseLong(workspaceId));
        } catch (NumberFormatException e) {
            throw new BadRequestException("Invalid Workspace identifier [{}]", workspaceId);
        }
        response.setStatus(HttpStatus.OK.value());

        return workspace;
    }

    /**
     * Get workspace by name.
     * 
     * @param workspaceName workspaceName
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @return workspace
     */
    @RequestMapping(value = UriTemplates.WORKSPACE_NAME, method = RequestMethod.GET)
    @ResponseBody
    public Workspace getWorkspaceByName(
                    @PathVariable("workspaceName") String workspaceName,
                    HttpServletRequest request,
                    HttpServletResponse response) {
        if (logger.isDebugEnabled()) {
            logger.debug("received get request for Workspace [{}]", workspaceName);
        }
        Workspace workspace;
        try {
            workspace = workspaceService.retrieveWorkspace(workspaceName);
        } catch (NumberFormatException e) {
            throw new BadRequestException("Invalid Workspace name [{}]", workspaceName);
        }
        response.setStatus(HttpStatus.OK.value());
        return workspace;
    }

    /**
     * Get all workspaces.
     * 
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @return all workspaces
     */
    @RequestMapping(value = UriTemplates.WORKSPACES, method = RequestMethod.GET)
    @ResponseBody
    public List<Workspace> getAllWorkspaces(
                    HttpServletRequest request,
                    HttpServletResponse response) {
        if (logger.isDebugEnabled()) {
            logger.debug("received get request for Workspaces");
        }

        List<Workspace> workspaces = workspaceService.retrieveWorkspaces();
        response.setStatus(HttpStatus.OK.value());

        return workspaces;
    }

    /**
     * Update workspace.
     * 
     * @param workspaceId workspaceId
     * @param workspace workspace
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    @RequestMapping(value = UriTemplates.WORKSPACE_ID, method = RequestMethod.PUT)
    public void updateWorkspace(
                    @PathVariable("workspaceId") String workspaceId,
                    @RequestBody Workspace workspace,
                    HttpServletRequest request,
                    HttpServletResponse response) {
        if (logger.isDebugEnabled()) {
            logger.debug("received post request {}", workspace.toString());
            String json;
            try {
                json = new JsonMessageConverter(Workspace.class).marshal(workspace);
                logger.debug("received post request {}", json);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        }

        try {
            workspace.setWorkspaceId(Long.parseLong(workspaceId));
        } catch (NumberFormatException e) {
            throw new BadRequestException("Invalid Workspace identifier [{}]", workspaceId);
        }
        int count = workspaceService.updateWorkspace(workspace);

        HttpStatus status = count == 1 ? HttpStatus.NO_CONTENT : HttpStatus.NOT_FOUND;
        response.setStatus(status.value());
    }

    /**
     * Delete workspace.
     * 
     * @param workspaceId workspaceId
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     */
    @RequestMapping(value = UriTemplates.WORKSPACE_ID, method = RequestMethod.DELETE)
    @ResponseBody
    public void deleteWorkspace(
                    @PathVariable("workspaceId") String workspaceId,
                    HttpServletRequest request,
                    HttpServletResponse response) {
        if (logger.isDebugEnabled()) {
            logger.debug("received delete request for workspace [{}]", workspaceId);
        }

        try {
            workspaceService.deleteWorkspace(Long.parseLong(workspaceId));
        } catch (NumberFormatException e) {
            throw new BadRequestException("Invalid Workspace identifier [{}]", workspaceId);
        }
        response.setStatus(HttpStatus.NO_CONTENT.value());
        return;
    }
    
    @RequestMapping(value = UriTemplates.SESSION_ALIVE, method = RequestMethod.GET)
    @ResponseBody
    public void isSessionAlive(HttpServletRequest request, HttpServletResponse response) {
        try {
            response.setStatus(200);
            response.getWriter().write("Session Alive");
            response.getWriter().flush();
        } catch (IOException e) {
            logger.error(e.getMessage());
            response.setStatus(200);
        }
    }

    /**
     * Registers all services healthcheck endpoints in workspace with cache.
     * 
     * @param workspace workspace
     */
    private void registerHealthchecks(Workspace workspace) {
        WorkspaceState workspaceState = workspace.getWorkspaceState();
        String dom = StringUtils.newStringUtf8(org.apache.commons.codec.binary.Base64.decodeBase64(workspaceState.getDom()));
        dom = HealthPoller.HTML_BODY_START + dom + HealthPoller.HTML_BODY_END;
        Document doc = Jsoup.parse(dom);
        Elements elements = doc.getElementsByClass(HealthPoller.HEALTH_ENDPOINT_CLASS);
        for (Element element : elements) {
            HealthPoller.cache.put(element.val(), new HashMap<>());
            HealthPoller.cache.get(element.val()).put(HealthPoller.HEALTH_PAYLOAD_KEY, HealthPoller.EMPTY);
        }
    }
}
