package com.rbc.system.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbc.system.config.ConfigConstants;
import com.rbc.system.dao.WorkspaceDao;
import com.rbc.system.model.Workspace;
import com.rbc.system.service.ServiceRuntimeException;
import com.rbc.system.service.StoreRuntimeException;
import com.rbc.system.service.WorkspaceService;

@Service(value = ConfigConstants.WORKSPACE_SERVICE)
public class WorkspaceServiceImpl implements WorkspaceService {
    @SuppressWarnings("unused")
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private WorkspaceDao workspaceDao;

    public void setWorkspaceDao(WorkspaceDao workspaceDao) {
        this.workspaceDao = workspaceDao;
    }

    @Override
    public long createWorkspace(Workspace workspace) throws ServiceRuntimeException {
        try {
            return workspaceDao.createWorkspace(workspace);
        } catch (StoreRuntimeException e) {
            throw new ServiceRuntimeException(e);
        }
    }

    @Override
    public Workspace retrieveWorkspace(long workspaceId) throws ServiceRuntimeException {
        try {
            return workspaceDao.retrieveWorkspace(workspaceId);
        } catch (StoreRuntimeException e) {
            throw new ServiceRuntimeException(e);
        }
    }
    
    @Override
    public Workspace retrieveWorkspace(String name) throws ServiceRuntimeException {
        try {
            return workspaceDao.retrieveWorkspace(name);
        } catch (StoreRuntimeException e) {
            throw new ServiceRuntimeException(e);
        }
    }

    @Override
    public List<Workspace> retrieveWorkspaces() throws ServiceRuntimeException {
        try {
            return workspaceDao.retrieveWorkspaces();
        } catch (StoreRuntimeException e) {
            throw new ServiceRuntimeException(e);
        }
    }

    @Override
    public int updateWorkspace(Workspace workspace) throws ServiceRuntimeException {
        try {
            return workspaceDao.updateWorkspace(workspace);
        } catch (StoreRuntimeException e) {
            throw new ServiceRuntimeException(e);
        }
    }

    @Override
    public int deleteWorkspace(long workspaceId) throws ServiceRuntimeException {
        try {
            return workspaceDao.deleteWorkspace(workspaceId);
        } catch (StoreRuntimeException e) {
            throw new ServiceRuntimeException(e);
        }
    }
}
