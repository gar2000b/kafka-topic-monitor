package com.rbc.system.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WorkspaceState {
    private String dom;
    private int zedIndex;
    private int microserviceInstanceCounter;
    private int topicInstanceCounter;
    private int queueInstanceCounter;
    private int datastoreInstanceCounter;
    private int lineInstanceCounter;
    private int arrowInstanceCounter;
    private int partitionInstanceCounter;
    private int serviceInstanceCounter;
    private int textInstanceCounter;
    private int redisInstanceCounter;
    private int vaultInstanceCounter;
    private int fileInstanceCounter;

    public WorkspaceState() {}

    public WorkspaceState(String dom,
                    int zedIndex,
                    int microserviceInstanceCounter,
                    int topicInstanceCounter,
                    int queueInstanceCounter,
                    int datastoreInstanceCounter,
                    int lineInstanceCounter,
                    int arrowInstanceCounter,
                    int partitionInstanceCounter,
                    int serviceInstanceCounter,
                    int textInstanceCounter,
                    int redisInstanceCounter,
                    int vaultInstanceCounter,
                    int fileInstanceCounter) {
        this.dom = dom;
        this.zedIndex = zedIndex;
        this.microserviceInstanceCounter = microserviceInstanceCounter;
        this.topicInstanceCounter = topicInstanceCounter;
        this.queueInstanceCounter = queueInstanceCounter;
        this.datastoreInstanceCounter = datastoreInstanceCounter;
        this.lineInstanceCounter = lineInstanceCounter;
        this.arrowInstanceCounter = arrowInstanceCounter;
        this.partitionInstanceCounter = partitionInstanceCounter;
        this.serviceInstanceCounter = serviceInstanceCounter;
        this.textInstanceCounter = textInstanceCounter;
        this.redisInstanceCounter = redisInstanceCounter;
        this.vaultInstanceCounter = vaultInstanceCounter;
        this.fileInstanceCounter = fileInstanceCounter;
    }

    public String getDom() {
        return dom;
    }

    public void setDom(String dom) {
        this.dom = dom;
    }

    @JsonProperty("zIndex")
    public int getZedIndex() {
        return zedIndex;
    }

    public void setZedIndex(int zedIndex) {
        this.zedIndex = zedIndex;
    }

    public int getMicroserviceInstanceCounter() {
        return microserviceInstanceCounter;
    }

    public void setMicroserviceInstanceCounter(int microserviceInstanceCounter) {
        this.microserviceInstanceCounter = microserviceInstanceCounter;
    }

    public int getTopicInstanceCounter() {
        return topicInstanceCounter;
    }

    public void setTopicInstanceCounter(int topicInstanceCounter) {
        this.topicInstanceCounter = topicInstanceCounter;
    }
    
    public int getQueueInstanceCounter() {
        return queueInstanceCounter;
    }

    public void setQueueInstanceCounter(int queueInstanceCounter) {
        this.queueInstanceCounter = queueInstanceCounter;
    }

    public int getDatastoreInstanceCounter() {
        return datastoreInstanceCounter;
    }

    public void setDatastoreInstanceCounter(int datastoreInstanceCounter) {
        this.datastoreInstanceCounter = datastoreInstanceCounter;
    }

    public int getLineInstanceCounter() {
        return lineInstanceCounter;
    }

    public void setLineInstanceCounter(int lineInstanceCounter) {
        this.lineInstanceCounter = lineInstanceCounter;
    }

    public int getArrowInstanceCounter() {
        return arrowInstanceCounter;
    }

    public void setArrowInstanceCounter(int arrowInstanceCounter) {
        this.arrowInstanceCounter = arrowInstanceCounter;
    }

    public int getPartitionInstanceCounter() {
        return partitionInstanceCounter;
    }

    public void setPartitionInstanceCounter(int partitionInstanceCounter) {
        this.partitionInstanceCounter = partitionInstanceCounter;
    }

    public int getServiceInstanceCounter() {
        return serviceInstanceCounter;
    }

    public void setServiceInstanceCounter(int serviceInstanceCounter) {
        this.serviceInstanceCounter = serviceInstanceCounter;
    }

    public int getTextInstanceCounter() {
        return textInstanceCounter;
    }

    public void setTextInstanceCounter(int textInstanceCounter) {
        this.textInstanceCounter = textInstanceCounter;
    }
    
    public int getRedisInstanceCounter() {
        return redisInstanceCounter;
    }

    public void setRedisInstanceCounter(int redisInstanceCounter) {
        this.redisInstanceCounter = redisInstanceCounter;
    }
    
    public int getVaultInstanceCounter() {
        return vaultInstanceCounter;
    }

    public void setVaultInstanceCounter(int vaultInstanceCounter) {
        this.vaultInstanceCounter = vaultInstanceCounter;
    }
    
    public int getFileInstanceCounter() {
        return fileInstanceCounter;
    }

    public void setFileInstanceCounter(int fileInstanceCounter) {
        this.fileInstanceCounter = fileInstanceCounter;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("WorkspaceState [dom=");
        builder.append(dom);
        builder.append(", zedIndex=");
        builder.append(zedIndex);
        builder.append(", microserviceInstanceCounter=");
        builder.append(microserviceInstanceCounter);
        builder.append(", topicInstanceCounter=");
        builder.append(topicInstanceCounter);
        builder.append(", queueInstanceCounter=");
        builder.append(queueInstanceCounter);
        builder.append(", datastoreInstanceCounter=");
        builder.append(datastoreInstanceCounter);
        builder.append(", lineInstanceCounter=");
        builder.append(lineInstanceCounter);
        builder.append(", arrowInstanceCounter=");
        builder.append(arrowInstanceCounter);
        builder.append(", partitionInstanceCounter=");
        builder.append(partitionInstanceCounter);
        builder.append(", serviceInstanceCounter=");
        builder.append(serviceInstanceCounter);
        builder.append(", textInstanceCounter=");
        builder.append(textInstanceCounter);
        builder.append(", redisInstanceCounter=");
        builder.append(redisInstanceCounter);
        builder.append(", vaultInstanceCounter=");
        builder.append(vaultInstanceCounter);
        builder.append(", fileInstanceCounter=");
        builder.append(fileInstanceCounter);
        builder.append("]");
        return builder.toString();
    }
}
