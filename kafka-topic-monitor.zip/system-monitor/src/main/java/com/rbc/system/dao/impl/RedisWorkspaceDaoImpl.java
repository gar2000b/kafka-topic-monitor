package com.rbc.system.dao.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbc.system.dao.RedisBaseDao;
import com.rbc.system.dao.WorkspaceDao;
import com.rbc.system.exception.AppRuntimeException;
import com.rbc.system.model.Workspace;
import com.rbc.system.model.WorkspaceState;
import com.rbc.system.service.ServiceRuntimeException;
import com.rbc.system.service.StoreRuntimeException;
import com.rbc.system.util.RandomizedSequencer;

public class RedisWorkspaceDaoImpl extends RedisBaseDao implements WorkspaceDao {
    
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public RedisWorkspaceDaoImpl(RedisTemplate<String, Object> redisTemplate) {
        super(redisTemplate);
    }

    @Override
    public long createWorkspace(Workspace workspace) throws AppRuntimeException {
        try {
            long workspaceId = getLongSequence();
            logger.info("workspace: " + workspaceId + " saving to redis");
            //@formatter:off
            ObjectMapper mapper = new ObjectMapper();
            String workspaceState = mapper.writeValueAsString(workspace.getWorkspaceState());
            Map<String, String> workspaceMap = new HashMap<>();
            workspaceMap.put("id", String.valueOf(workspaceId));
            workspaceMap.put("name", workspace.getName());
            workspaceMap.put("workspace_state", workspaceState);
            hashOperations.putAll("workspace:" + workspaceId, workspaceMap);
            logger.info("workspace: " + workspaceId + " saved to redis");
            return workspaceId;
        } catch (Exception e) {
            throw new AppRuntimeException("create workspace", e);
        }
    }

    @Override
    public Workspace retrieveWorkspace(long workspaceId) throws ServiceRuntimeException {
        Long id = Long.valueOf(hashOperations.get("workspace:" + workspaceId, "id"));
        logger.info("retrieving workspace: " + workspaceId);
        String name = hashOperations.get("workspace:" + workspaceId, "name");
        String ws = hashOperations.get("workspace:" + workspaceId, "workspace_state");
        Workspace workspace = new Workspace();
        workspace.setWorkspaceId(id);
        workspace.setName(name);
        WorkspaceState workspaceState = null;
        try {
            ObjectMapper mapper = new ObjectMapper();
            workspaceState = mapper.readValue(ws, WorkspaceState.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        workspace.setWorkspaceState(workspaceState);
        logger.info("returing workspace: " + workspace.getName());
        return workspace;
    }

    @Override
    public Workspace retrieveWorkspace(String workspaceName) throws ServiceRuntimeException {
        logger.info("retrieving workspaceName" + workspaceName);
        Set<String> keys = redisTemplate.keys("*");
        ObjectMapper mapper = new ObjectMapper();
        for (String key : keys) {
            logger.info("retrieving workspace with key: " + key);
            if (hashOperations.get(key, "id") == null || key == null || !(key.length() > 0))
                return null;
            
            String name = hashOperations.get(key, "name");
            Workspace workspace = new Workspace();
            if (name.equals(workspaceName)) {
                Long id = Long.valueOf(hashOperations.get(key, "id"));
                String ws = hashOperations.get(key, "workspace_state");
                workspace.setWorkspaceId(id);
                workspace.setName(name);
                WorkspaceState workspaceState = null;
                try {
                    workspaceState = mapper.readValue(ws, WorkspaceState.class);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                workspace.setWorkspaceState(workspaceState);
                logger.info("returing workspace: " + workspace.getName());
                return workspace;                
            }
        }
        return null;
    }
    
    @Override
    public List<Workspace> retrieveWorkspaces() throws ServiceRuntimeException {
        logger.info("retrieving all workspaces");
        List<Workspace> workspaces = new ArrayList<>();
        Set<String> keys = redisTemplate.keys("*");
        ObjectMapper mapper = new ObjectMapper();
        for (String key : keys) {
            logger.info("retrieving workspace with key: " + key);
            if (hashOperations.get(key, "id") == null || key == null || !(key.length() > 0))
                return workspaces;
            
            Long id = Long.valueOf(hashOperations.get(key, "id"));
            String name = hashOperations.get(key, "name");
            String ws = hashOperations.get(key, "workspace_state");
            Workspace workspace = new Workspace();
            workspace.setWorkspaceId(id);
            workspace.setName(name);
            WorkspaceState workspaceState = null;
            try {
                workspaceState = mapper.readValue(ws, WorkspaceState.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
            workspace.setWorkspaceState(workspaceState);
            workspaces.add(workspace);
        }
        logger.info("returning all workspaces of length: " + workspaces.size());
        return workspaces;
    }

    @Override
    public int updateWorkspace(Workspace workspace) throws ServiceRuntimeException {
        try {
            ObjectMapper mapper = new ObjectMapper();
            String workspaceState = mapper.writeValueAsString(workspace.getWorkspaceState());
            Map<String, String> workspaceMap = new HashMap<>();
            workspaceMap.put("id", String.valueOf(workspace.getWorkspaceId()));
            workspaceMap.put("name", workspace.getName());
            workspaceMap.put("workspace_state", workspaceState);
            hashOperations.putAll("workspace:" + workspace.getWorkspaceId(), workspaceMap);
            return 1;
        } catch (Exception ex) { 
            throw new StoreRuntimeException("updating Workspace", ex);
        }
    }

    @Override
    public int deleteWorkspace(long workspaceId) throws ServiceRuntimeException {
        hashOperations.delete("workspace:" + workspaceId, "id", "name", "workspace_state");
        return 0;
    }
    
    /**
     * Get a long sequence value.
     * 
     * @return a random long value
     */
    protected long getLongSequence() {
        return RandomizedSequencer.nextLongValue();
    }
}
