// pricing-admin.js poc

var microserviceInstanceCounter = 0;
var topicInstanceCounter = 0;
var datastoreInstanceCounter = 0;
var lineInstanceCounter = 0;
var arrowInstanceCounter = 0;
var partitionInstanceCounter = 0;
var serviceInstanceCounter = 0;
var textInstanceCounter = 0;
var queueInstanceCounter = 0;
var redisInstanceCounter = 0;
var vaultInstanceCounter = 0;
var fileInstanceCounter = 0;
var zIndex = 10;
var lastElement;
var lastHealthInd;
var deg = 0;
var modalFlag = false;
var modalType;
var modalId;
var textSpan;
var serviceName;
var healthEndpoint;
var workspaceId;
var workspaceFlag = false;
var loggedIn = false;
var token = "";

window.onload = function() {
	loadWorkspace();
	loginCheck();
	checkIfLoggedIn();
	getToken();
;}

browserCheck();


function keyDownTextField(e) {
	var keyCode = e.keyCode;
	
	if (keyCode == 13) {
		// enter key
		if (modalType == "service") {
			modalType = "";
			updateService();
		}
		if (modalType == "text") {
			modalType = "";
			updateText();
		}
		if (modalType == "login") {
			modalType = "";
			login();
		}
	}

	if(keyCode == 32) {
		// copy to clipboard
		if (typeof lastElement !== 'undefined') {
			if(lastElement.id.includes("microservice-instance")) {
				navigator.clipboard.writeText(lastElement.children[0].title);
				// alert("Health Check information copied to clipboard!");
			}
		}
	}
	
	// Note: any key codes evaluated below will be ignored of modal flag is set.
	// If you want them to always be triggered, include them above this condition.
	if (modalFlag) {
		return;
	}

	if (keyCode == 82) {
		// r key for rotate
		if (lastElement) {
			if (deg == 360) {
				deg = 45;
			} else {
				deg += 45;
			}
			lastElement.style.webkitTransform = 'rotate(' + deg + 'deg)';
			lastElement.style.mozTransform = 'rotate(' + deg + 'deg)';
			lastElement.style.msTransform = 'rotate(' + deg + 'deg)';
			lastElement.style.oTransform = 'rotate(' + deg + 'deg)';
			lastElement.style.transform = 'rotate(' + deg + 'deg)';
		}
	}
	if (keyCode == 37) {
		// left arrow
		lastElement.style.left = (parseInt(lastElement.style.left) - 1) + "px";
		if (lastHealthInd) {
			lastHealthInd.style.left = (parseInt(lastHealthInd.style.left) - 1)
					+ "px";
		}
	}
	if (keyCode == 39) {
		// right arrow
		lastElement.style.left = (parseInt(lastElement.style.left) + 1) + "px";
		if (lastHealthInd) {
			lastHealthInd.style.left = (parseInt(lastHealthInd.style.left) + 1)
					+ "px";
		}
	}
	if (keyCode == 38) {
		// up arrow
		lastElement.style.top = (parseInt(lastElement.style.top) - 1) + "px";
		if (lastHealthInd) {
			lastHealthInd.style.top = (parseInt(lastHealthInd.style.top) - 1)
					+ "px";
		}
	}
	if (keyCode == 40) {
		// down arrow
		lastElement.style.top = (parseInt(lastElement.style.top) + 1) + "px";
		if (lastHealthInd) {
			lastHealthInd.style.top = (parseInt(lastHealthInd.style.top) + 1)
					+ "px";
		}
	}
	if (keyCode == 187) {
		// plus
		lastElement.style.width = (parseInt(lastElement.offsetWidth) + 6)
				+ "px";
	}
	if (keyCode == 189) {
		// minus
		lastElement.style.width = (parseInt(lastElement.offsetWidth) - 6)
				+ "px";
	}
	if (keyCode == 221) {
		// right bracket
		lastElement.style.height = (parseInt(lastElement.offsetHeight) + 6)
		+ "px";
	}
	if (keyCode == 219) {
		// left bracket
		lastElement.style.height = (parseInt(lastElement.offsetHeight) - 6)
		+ "px";
	}
	if (keyCode == 68 || keyCode == 46) {
		// d key or delete	
		var result = confirm("Are you sure you wish to remove selected instance '"
				+ lastElement.id + "'?");
		if (result) {
			lastElement.parentElement.removeChild(lastElement);
			if (lastHealthInd) {
				lastHealthInd.parentElement.removeChild(lastHealthInd);
				var pos = lastHealthInd.id.replace('health-ind', '');
				var hiddenHealthEndpoint = document
						.getElementById('health-endpoint' + pos);
				hiddenHealthEndpoint.parentElement
						.removeChild(hiddenHealthEndpoint);
			}
			
//			if(lastElement.id.includes("microservice-instance")) {
//				microserviceInstanceCounter--;
//			}
//			if(lastElement.id.includes("topic-instance")) {
//				topicInstanceCounter--;
//			}
//			if(lastElement.id.includes("datastore-instance")) {
//				alert();
//				datastoreInstanceCounter--;
//			}
//			if(lastElement.id.includes("line-instance")) {
//				lineInstanceCounter--;
//			}
//			if(lastElement.id.includes("arrow-instance")) {
//				arrowInstanceCounter--;
//			}
//			if(lastElement.id.includes("partition-instance")) {
//				partitionInstanceCounter--;
//			}
//			if(lastElement.id.includes("service-instance")) {
//				serviceInstanceCounter--;
//			}
//			if(lastElement.id.includes("text-instance")) {
//				textInstanceCounter--;
//			}
//			if(lastElement.id.includes("queue-instance")) {
//				queueInstanceCounter--;
//			}
//			if(lastElement.id.includes("redis-instance")) {
//				redisInstanceCounter--;
//			}
//			if(lastElement.id.includes("vault-instance")) {
//				vaultInstanceCounter--;
//			}
//			if(lastElement.id.includes("file-instance")) {
//				fileInstanceCounter--;
//			}
		}
	}
	if(keyCode == 66) {
		// send to back
		lastElement.style.zIndex = -1;
	}
	if(keyCode == 70) {
		// send to front
		lastElement.style.zIndex = zIndex + 1;
	}
}

setInterval(sessionAliveCheck, 1000);
function sessionAliveCheck() {
	var thisdate = new Date();
	var serverPage = "isSessionAlive?time=" + thisdate.getTime();
	var xmlhttp1 = getxmlhttp();
	xmlhttp1.open("GET", serverPage);
	xmlhttp1.onreadystatechange = function() {
		sessionAliveCheckHandler(xmlhttp1);
	}
	xmlhttp1.send(null);
}

function sessionAliveCheckHandler(xmlhttp1) {
	try {
		if (xmlhttp1.readyState == 4 && xmlhttp1.status == 200) {
			var response = xmlhttp1.responseText;
			if (response == "Session Alive") {
				// console.log("session is alive");
			} else {
				if(window.location.href.includes("workspace=")) {
					console.log("Rendering workspace");
				}
				else if(!window.location.href.includes("login=true")) {
					console.log("Re-directing to login page");
					window.location = "index.html?login=true";
				} else {
					console.log("Already at login page");
				}
			}
		}
	}
	catch(error) {
		return;
	}
}

var pollingInterval = setInterval(doPoll, 1000);
function doPoll() {
	var x = document.getElementsByClassName("health-endpoint");
	if (x.length > 0) {
		var isWorkspaceHealthy = true;
		for (var i = 0; i < x.length; i++) {
			(function(i) {
				var healthcheckEndpoint = x[i];
				if (healthcheckEndpoint.value != null
						&& healthcheckEndpoint.value.length > 0) {
					var thisdate = new Date();
					var serverPage = "healthcheck?time=" + thisdate.getTime()
							+ "&endpoint=" + btoa(healthcheckEndpoint.value);

					var xmlhttp1 = getxmlhttp();
					xmlhttp1.open("GET", serverPage);
					var pos = x[i].id.replace('health-endpoint', '');
					xmlhttp1.onreadystatechange = function() {						
						if(doPollAjaxHandler(xmlhttp1, pos) === false) {
							isWorkspaceHealthy = false;
							document.getElementById('title').style.color = 'red';
							document.getElementById('title').style.textShadow = '1px 1px 2px red, 0 0 30px red, 0 0 20px red';
						}
					}
					xmlhttp1.setRequestHeader("_csrf", token);
					xmlhttp1.send(null);
				}
			})(i);
		}
		if(isWorkspaceHealthy) {
			document.getElementById('title').style.color = 'lightgreen';
			document.getElementById('title').style.textShadow = '';
		}
	}
}

function doPollAjaxHandler(xmlhttp1, i) {
	try {
		if (xmlhttp1.readyState == 4 && xmlhttp1.status == 200) {
			var response = xmlhttp1.responseText;
			if (response.length > 0 && response.indexOf("status") != -1) {
				var healthResponse = JSON.parse(response);
				document.getElementById('microservice-instance' + i + '-header').title = JSON.stringify(healthResponse, null, 2);
				if('core' in healthResponse && typeof healthResponse !== 'undefined' && typeof healthResponse.core !== 'undefined') {
					if (document.getElementById('microservice-instance-version' + i)) {
						if(typeof healthResponse.core.version !== 'undefined'){
							var version = healthResponse.core.version;
							document.getElementById('microservice-instance-version' + i).innerHTML = version;
						}
					}
					if (document.getElementById('microservice-instance-dateTime' + i)) {
						if(typeof healthResponse.core.dateTime !== 'undefined'){
							var dateTime = healthResponse.core.dateTime;
							document.getElementById('microservice-instance-dateTime' + i).innerHTML = dateTime;
						} else {
							var dateTime = healthResponse.components.core.details.dateTime;
							document.getElementById('microservice-instance-dateTime' + i).innerHTML = new Date().toLocaleString();;
						}
					}
					if (document.getElementById('microservice-instance-log' + i)) {
						if(typeof healthResponse.core.applicationId !== 'undefined') {
							if(getEnv() == "GCC") {
								document.getElementById('microservice-instance-log' + i).href = 'https://metrics.sys.scc.pcf.fg.rbc.com/apps/' + healthResponse.core.applicationId + '/dashboard';
							} else if(getEnv() == "SCC") {
								document.getElementById('microservice-instance-log' + i).href = 'https://metrics.sys.gcc.pcf.fg.rbc.com/apps/' + healthResponse.core.applicationId + '/dashboard';
							} else {
								document.getElementById('microservice-instance-log' + i).href = 'https://metrics.sys.pcf.devfg.rbc.com/apps/' + healthResponse.core.applicationId + '/dashboard';
							}
						}
					}
					if (typeof healthResponse.core.status !== 'undefined' && healthResponse.core.status == "UP") {
						document.getElementById('health-ind' + i).src = "images/healthy-ind-trans.png";
						if (document.getElementById('health-ind-clone' + i)) {
							document.getElementById('health-ind-clone' + i).src = "images/healthy.png";
						}
						return true;
					}
					return false;
				}
				else if('details' in healthResponse && typeof healthResponse !== 'undefined' && typeof healthResponse.details.core !== 'undefined') {
					if (document.getElementById('microservice-instance-version' + i)) {
						if(typeof healthResponse.details.core.details.version !== 'undefined'){
							var version = healthResponse.details.core.details.version;
							document.getElementById('microservice-instance-version' + i).innerHTML = version;
						}
					}
					if (document.getElementById('microservice-instance-dateTime' + i)) {
						if(typeof healthResponse.details.core.details.dateTime !== 'undefined'){
							var dateTime = healthResponse.details.core.details.dateTime;
							document.getElementById('microservice-instance-dateTime' + i).innerHTML = dateTime;
						} else {
							var dateTime = healthResponse.components.core.details.dateTime;
							document.getElementById('microservice-instance-dateTime' + i).innerHTML = new Date().toLocaleString();;
						}
					}
					if (document.getElementById('microservice-instance-log' + i)) {
						if(typeof healthResponse.details.core.details.applicationId !== 'undefined') {
							if(getEnv() == "GCC") {
								document.getElementById('microservice-instance-log' + i).href = 'https://metrics.sys.scc.pcf.fg.rbc.com/apps/' + healthResponse.details.core.details.applicationId + '/dashboard';
							} else if(getEnv() == "SCC") {
								document.getElementById('microservice-instance-log' + i).href = 'https://metrics.sys.gcc.pcf.fg.rbc.com/apps/' + healthResponse.details.core.details.applicationId + '/dashboard';
							} else {
								document.getElementById('microservice-instance-log' + i).href = 'https://metrics.sys.pcf.devfg.rbc.com/apps/' + healthResponse.details.core.details.applicationId + '/dashboard';
							}
						}
					}
					if (typeof healthResponse.details.core.status !== 'undefined' && healthResponse.details.core.status == "UP") {
						document.getElementById('health-ind' + i).src = "images/healthy-ind-trans.png";
						if (document.getElementById('health-ind-clone' + i)) {
							document.getElementById('health-ind-clone' + i).src = "images/healthy.png";
						}
						return true;
					}
					return false;
				}
				else if('components' in healthResponse && typeof healthResponse !== 'undefined' && typeof healthResponse.components.core !== 'undefined') {
					if (document.getElementById('microservice-instance-version' + i)) {
						if(typeof healthResponse.components.core.details.version !== 'undefined'){
							var version = healthResponse.components.core.details.version;
							document.getElementById('microservice-instance-version' + i).innerHTML = version;
						}
					}
					if (document.getElementById('microservice-instance-dateTime' + i)) {
						if(typeof healthResponse.components.core.details.dateTime !== 'undefined'){
							var dateTime = healthResponse.components.core.details.dateTime;
							document.getElementById('microservice-instance-dateTime' + i).innerHTML = dateTime;
						} else {
							var dateTime = healthResponse.components.core.details.dateTime;
							document.getElementById('microservice-instance-dateTime' + i).innerHTML = new Date().toLocaleString();;
						}
					}
					if (document.getElementById('microservice-instance-log' + i)) {
						if(typeof healthResponse.components.core.details.applicationId !== 'undefined') {
							if(getEnv() == "GCC") {
								document.getElementById('microservice-instance-log' + i).href = 'https://metrics.sys.scc.pcf.fg.rbc.com/apps/' + healthResponse.components.core.details.applicationId + '/dashboard';
							} else if(getEnv() == "SCC") {
								document.getElementById('microservice-instance-log' + i).href = 'https://metrics.sys.gcc.pcf.fg.rbc.com/apps/' + healthResponse.components.core.details.applicationId + '/dashboard';
							} else {
								document.getElementById('microservice-instance-log' + i).href = 'https://metrics.sys.pcf.devfg.rbc.com/apps/' + healthResponse.components.core.details.applicationId + '/dashboard';
							}
						}
					}
					if (typeof healthResponse.components.core.status !== 'undefined' && healthResponse.components.core.status == "UP") {
						document.getElementById('health-ind' + i).src = "images/healthy-ind-trans.png";
						if (document.getElementById('health-ind-clone' + i)) {
							document.getElementById('health-ind-clone' + i).src = "images/healthy.png";
						}
						return true;
					}
					return false;
				}
			}	
			// If the above checks are unsuccessful than set indicator as unhealthy
			document.getElementById('health-ind' + i).src = "images/unhealthy-ind-trans.png";
			if (document.getElementById('health-ind-clone' + i)) {
				document.getElementById('health-ind-clone' + i).src = "images/unhealthy-bright.png";
			}
			return false;
		} else if (xmlhttp1.status == 403) {
			loggedIn = false;
			loginCheck();
		}
	}
	catch(error) {
		return;
	}
}

function getEnv() {
	var url = window.location.href;
	if (url.indexOf("-dev") != -1) {
		return "DEV";
	} else if (url.indexOf("-qat") != -1) {
		return "QAT";
	} else if (url.indexOf("-uat") != -1) {
		return "UAT";
	} else if (url.indexOf("scc") != -1) {
		return "SCC";
	} else if (url.indexOf("gcc") != -1) {
		return "GCC";
	} else {
		return "LCL";
	}
}

function createMicroserviceInstance() {
	document.getElementById('workspace').innerHTML += "<div ondblclick=\"updateServiceModal("
			+ microserviceInstanceCounter
			+ ");\" class=\"microservice-instance\" id=\"microservice-instance"
			+ microserviceInstanceCounter
			+ "\" onmouseover=\"dragElement(document.getElementById('microservice-instance"
			+ microserviceInstanceCounter
			+ "'), "
			+ microserviceInstanceCounter
			+ ");\"><div class=\"microservice-instance-header\" id='microservice-instance"
			+ microserviceInstanceCounter
			+ "-header'\" align=\"right\"><img ondblclick=\"cloneIndicator(event, " + microserviceInstanceCounter + ");\" id = \"health-ind"
			+ microserviceInstanceCounter
			+ "\" src=\"images/unhealthy-ind-trans.png\" width=\"20\" height=\"19\"></div><span id='microservice-instance-name"
			+ microserviceInstanceCounter
			+ "'\" ondblclick=\"updateServiceModal("
			+ microserviceInstanceCounter + ");\">[service name]</span><br/><span id='microservice-instance-version"
			+ microserviceInstanceCounter
			+ "'>version = (version)</span><br/><span id='microservice-instance-dateTime"
			+ microserviceInstanceCounter
			+ "'>dateTime = (dateTime)</span><br/><span><a href='#' id='microservice-instance-log"
			+ microserviceInstanceCounter
			+ "' target='_blank'>logs</a></span></div>";
	document.getElementById('workspace').innerHTML += "<input class = \"health-endpoint\" id=\"health-endpoint"
			+ microserviceInstanceCounter + "\" type=\"hidden\" value=\"\" />";
	dragElement(document.getElementById("microservice-instance"
			+ microserviceInstanceCounter), microserviceInstanceCounter);
	document.getElementById('microservice-instance'
			+ microserviceInstanceCounter).style.top = "30px";
	document.getElementById('microservice-instance'
			+ microserviceInstanceCounter).style.left = "70px";
	document.getElementById('health-ind' + microserviceInstanceCounter).style.top = "148px";
	document.getElementById('health-ind' + microserviceInstanceCounter).style.left = "460px";
	microserviceInstanceCounter++;
}

function createTopicInstance() {
	document.getElementById('workspace').innerHTML += "<div class=\"topic-instance\" id=\"topic-instance"
			+ topicInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('topic-instance"
			+ topicInstanceCounter
			+ "'));\"><img src=\"images/topic.png\" width=\"100%\" height=\"100%\" alt=\"Topic\" title=\"Topic\"></div>";
	dragElement(document
			.getElementById("topic-instance" + topicInstanceCounter));
	document.getElementById('topic-instance' + topicInstanceCounter).style.top = "30px";
	document.getElementById('topic-instance' + topicInstanceCounter).style.left = "70px";
	document.getElementById('topic-instance' + topicInstanceCounter).style.width = "101px";
	document.getElementById('topic-instance' + topicInstanceCounter).style.height = "39px";
	topicInstanceCounter++;
}

function createQueueInstance() {
	if (typeof queueInstanceCounter == 'undefined') {
		queueInstanceCounter = 0;
	}
	
	document.getElementById('workspace').innerHTML += "<div class=\"queue-instance\" id=\"queue-instance"
			+ queueInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('queue-instance"
			+ queueInstanceCounter
			+ "'));\"><img src=\"images/queue.png\" width=\"100%\" height=\"100%\" alt=\"Queue\" title=\"Queue\"></div>";
	dragElement(document
			.getElementById("queue-instance" + queueInstanceCounter));
	document.getElementById("queue-instance" + queueInstanceCounter).style.top = "30px";
	document.getElementById("queue-instance" + queueInstanceCounter).style.left = "70px";
	document.getElementById("queue-instance" + queueInstanceCounter).style.width = "101px";
	document.getElementById("queue-instance" + queueInstanceCounter).style.height = "39px";
	queueInstanceCounter++;
}

function createRedisInstance() {
	if (typeof redisInstanceCounter == 'undefined') {
		redisInstanceCounter = 0;
	}
	
	document.getElementById('workspace').innerHTML += "<div class=\"redis-instance\" id=\"redis-instance"
			+ redisInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('redis-instance"
			+ redisInstanceCounter
			+ "'));\"><img src=\"images/redis-cache.png\" width=\"100%\" height=\"100%\" alt=\"Redis\" title=\"Redis\"></div>";
	dragElement(document
			.getElementById("redis-instance" + redisInstanceCounter));
	document.getElementById("redis-instance" + redisInstanceCounter).style.top = "30px";
	document.getElementById("redis-instance" + redisInstanceCounter).style.left = "70px";
	document.getElementById("redis-instance" + redisInstanceCounter).style.width = "82px";
	document.getElementById("redis-instance" + redisInstanceCounter).style.height = "101px";
	redisInstanceCounter++;
}

function createVaultInstance() {
	if (typeof vaultInstanceCounter == 'undefined') {
		vaultInstanceCounter = 0;
	}
	
	document.getElementById('workspace').innerHTML += "<div class=\"vault-instance\" id=\"vault-instance"
			+ vaultInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('vault-instance"
			+ vaultInstanceCounter
			+ "'));\"><img src=\"images/vault.png\" width=\"100%\" height=\"100%\" alt=\"vault\" title=\"vault\"></div>";
	dragElement(document
			.getElementById("vault-instance" + vaultInstanceCounter));
	document.getElementById("vault-instance" + vaultInstanceCounter).style.top = "30px";
	document.getElementById("vault-instance" + vaultInstanceCounter).style.left = "70px";
	document.getElementById("vault-instance" + vaultInstanceCounter).style.width = "82px";
	document.getElementById("vault-instance" + vaultInstanceCounter).style.height = "101px";
	vaultInstanceCounter++;
}

function createFileInstance() {
	if (typeof fileInstanceCounter == 'undefined') {
		fileInstanceCounter = 0;
	}
	
	document.getElementById('workspace').innerHTML += "<div class=\"file-instance\" id=\"file-instance"
			+ fileInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('file-instance"
			+ fileInstanceCounter
			+ "'));\"><img src=\"images/file.png\" width=\"100%\" height=\"100%\" alt=\"file\" title=\"file\"></div>";
	dragElement(document
			.getElementById("file-instance" + fileInstanceCounter));
	document.getElementById("file-instance" + fileInstanceCounter).style.top = "30px";
	document.getElementById("file-instance" + fileInstanceCounter).style.left = "70px";
	document.getElementById("file-instance" + fileInstanceCounter).style.width = "82px";
	document.getElementById("file-instance" + fileInstanceCounter).style.height = "101px";
	fileInstanceCounter++;
}

function createDatastoreInstance() {
	document.getElementById('workspace').innerHTML += "<div class=\"datastore-instance\" id=\"datastore-instance"
			+ datastoreInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('datastore-instance"
			+ datastoreInstanceCounter
			+ "'));\"><img src=\"images/datastore.png\" width=\"100%\" height=\"100%\" alt=\"Database/Datastore\" title=\"Database/Datastore\"></div>";
	dragElement(document.getElementById("datastore-instance"
			+ datastoreInstanceCounter));
	document.getElementById('datastore-instance' + datastoreInstanceCounter).style.top = "30px";
	document.getElementById('datastore-instance' + datastoreInstanceCounter).style.left = "70px";
	document.getElementById('datastore-instance' + datastoreInstanceCounter).style.width = "81px";
	document.getElementById('datastore-instance' + datastoreInstanceCounter).style.height = "81px";
	datastoreInstanceCounter++;
}

function createLineInstance() {
	document.getElementById('workspace').innerHTML += "<div class=\"line-instance\" id=\"line-instance"
			+ lineInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('line-instance"
			+ lineInstanceCounter
			+ "'));\"><img src=\"images/line.png\" width=\"100%\" height=\"100%\" alt=\"Connector Line\" title=\"Connector Line\"></div>";
	dragElement(document.getElementById("line-instance" + lineInstanceCounter));
	document.getElementById('line-instance' + lineInstanceCounter).style.top = "30px";
	document.getElementById('line-instance' + lineInstanceCounter).style.left = "70px";
	lineInstanceCounter++;
}

function createArrowInstance() {
	document.getElementById('workspace').innerHTML += "<div class=\"arrow-instance\" id=\"arrow-instance"
			+ arrowInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('arrow-instance"
			+ arrowInstanceCounter
			+ "'));\"><img src=\"images/arrow.png\" width=\"100%\" height=\"100%\" alt=\"Arrow Head\" title=\"Arrow Head\"></div>";
	dragElement(document
			.getElementById("arrow-instance" + arrowInstanceCounter));
	document.getElementById('arrow-instance' + arrowInstanceCounter).style.top = "30px";
	document.getElementById('arrow-instance' + arrowInstanceCounter).style.left = "70px";
	arrowInstanceCounter++;
}

function createPartitionInstance() {
	document.getElementById('workspace').innerHTML += "<div class=\"partition-instance\" id=\"partition-instance"
			+ partitionInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('partition-instance"
			+ partitionInstanceCounter
			+ "'));\"><img src=\"images/partition.png\" width=\"100%\" height=\"100%\" alt=\"Partition\" title=\"Partition\"></div>";
	dragElement(document.getElementById("partition-instance"
			+ partitionInstanceCounter));
	document.getElementById('partition-instance' + partitionInstanceCounter).style.top = "30px";
	document.getElementById('partition-instance' + partitionInstanceCounter).style.left = "70px";
	partitionInstanceCounter++;
}

function createServiceInstance() {
	document.getElementById('workspace').innerHTML += "<div class=\"service-instance\" id=\"service-instance"
			+ serviceInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('service-instance"
			+ serviceInstanceCounter
			+ "'));\"><img src=\"images/service.png\" width=\"100%\" height=\"100%\" alt=\"Service/System\" title=\"Service/System\"></div>";
	dragElement(document.getElementById("service-instance"
			+ serviceInstanceCounter));
	document.getElementById('service-instance' + serviceInstanceCounter).style.top = "30px";
	document.getElementById('service-instance' + serviceInstanceCounter).style.left = "70px";
	serviceInstanceCounter++;
}

function createTextInstance() {
	document.getElementById('workspace').innerHTML += "<div class=\"text-instance\" id=\"text-instance"
			+ textInstanceCounter
			+ "\"onmouseover=\"dragElement(document.getElementById('text-instance"
			+ textInstanceCounter
			+ "'));\"><span id=\"text-span"
			+ textInstanceCounter
			+ "\" ondblclick=\"updateTextModal(this);\">text</></div>";
	dragElement(document.getElementById("text-instance" + textInstanceCounter));
	document.getElementById('text-instance' + textInstanceCounter).style.top = "30px";
	document.getElementById('text-instance' + textInstanceCounter).style.left = "70px";
	textInstanceCounter++;
}

function dragElement(elmnt, id) {
	var healthInd;

	if (id > -1) {
		healthInd = document.getElementById('health-ind' + id);
	}

	var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
	if (document.getElementById(elmnt.id + "header")) {
		document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
	} else {
		elmnt.onmousedown = dragMouseDown;
	}

	function dragMouseDown(e) {
		lastElement = elmnt;

		if (workspaceFlag) {
			return;
		}
		e = e || window.event;
		e.preventDefault();
		pos3 = e.clientX;
		pos4 = e.clientY;
		document.onmouseup = closeDragElement;
		document.onmousemove = elementDrag;
	}

	function elementDrag(e) {
		elmnt.style.zIndex = zIndex + 1;
		e = e || window.event;
		e.preventDefault();
		pos1 = pos3 - e.clientX;
		pos2 = pos4 - e.clientY;
		pos3 = e.clientX;
		pos4 = e.clientY;
		elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
		elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
		if (healthInd) {
			healthInd.style.top = (elmnt.offsetTop - pos2 - 52) + "px";
			healthInd.style.left = (elmnt.offsetLeft - pos1 + 140) + "px";
		}
		if (document.getElementById(elmnt.id + "-xy")) {
			document.getElementById(elmnt.id + "-xy").innerHTML = "X = "
					+ elmnt.style.top + ", Y = " + elmnt.style.left;
		}
	}

	function closeDragElement() {
		document.onmouseup = null;
		document.onmousemove = null;
		zIndex++;
		lastElement = elmnt;

		if (healthInd) {
			lastHealthInd = healthInd;
		} else {
			lastHealthInd = null;
		}
	}
}

function upScroll() {
	var elmnt = document.getElementById("microservice-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("topic-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("queue-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("datastore-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("line-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("arrow-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("partition-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("service-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("text-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("redis-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("vault-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
	var elmnt = document.getElementById("file-template");
	elmnt.style.top = (elmnt.offsetTop + 20) + "px";
}

function downScroll() {
	var elmnt = document.getElementById("microservice-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("topic-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("queue-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("datastore-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("line-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("arrow-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("partition-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("service-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("text-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("redis-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("vault-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
	var elmnt = document.getElementById("file-template");
	elmnt.style.top = (elmnt.offsetTop - 80) + "px";
}

function updateTextModal(textSpan) {
	if (workspaceFlag) {
		return;
	}
	this.textSpan = textSpan;
	modalFlag = true;
	modalType = "text";
	var modal = document.getElementById('textModal');
	modal.style.display = "block";
	var textInput = document.getElementById('text-input');
	textInput.value = textSpan.innerHTML;
	textInput.focus();
	textInput.select();
}

function closeTextModel() {
	var modal = document.getElementById('textModal');
	modal.style.display = "none";
	modalFlag = false;
}

function updateText() {
	textSpan.innerHTML = document.getElementById("text-input").value;
	var modal = document.getElementById('textModal');
	modal.style.display = "none";
	modalFlag = false;
}

function updateServiceModal(id) {
	if (workspaceFlag) {
		return;
	}
	this.serviceName = document.getElementById('microservice-instance-name'
			+ id);
	healthEndpoint = document.getElementById('health-endpoint' + id);
	modalFlag = true;
	modalType = "service";
	modalId = id;
	var modal = document.getElementById('serviceModal');
	modal.style.display = "block";
	var nameInput = document.getElementById('name-input');
	nameInput.value = serviceName.innerHTML;
	nameInput.focus();
	nameInput.select();
	var healthInput = document.getElementById('health-endpoint-input');
	healthInput.value = healthEndpoint.value;
}

function closeServiceModel() {
	var modal = document.getElementById('serviceModal');
	modal.style.display = "none";
	modalFlag = false;
}

function updateService() {
	serviceName.innerHTML = document.getElementById("name-input").value;
	healthEndpoint.value = document.getElementById("health-endpoint-input").value;
	var modal = document.getElementById('serviceModal');
	modal.style.display = "none";
	modalFlag = false;
}

function expandShortcutsModel() {
	var modal = document.getElementById('shortcutsModal');
	modal.style.display = "block";
	modalFlag = true;
}

function closeShortcutsModel() {
	var modal = document.getElementById('shortcutsModal');
	modal.style.display = "none";
	modalFlag = false;
}

function cloneIndicator(event, id) {
	event.stopPropagation();
	document.getElementById('workspace').innerHTML += "<img onmouseover=\"dragElement(document.getElementById('health-ind-clone"
			+ id
			+ "'))\" class=\"healthcheck-clone-instance\" id = \"health-ind-clone"
			+ id
			+ "\" src=\"images/unhealthy-bright.png\" title = \"Healthcheck Indicator\" alt = \"Healthcheck Indicator\">";
	document.getElementById('health-ind-clone' + id).style.top = "180px";
	document.getElementById('health-ind-clone' + id).style.left = "400px";
	dragElement(document.getElementById('health-ind-clone' + id));
}

function explore() {
	modalFlag = true;
	modalType = "explorer";
	var modal = document.getElementById('explorerModal');
	modal.style.display = "block";
	fetchWorkspaces();
}

function fetchWorkspaces() {
	var thisdate = new Date();
	var serverPage = "workspaces?time=" + thisdate.getTime();

	var xmlhttp1 = getxmlhttp();
	xmlhttp1.open("GET", serverPage);
	xmlhttp1.onreadystatechange = function() {
		fetchWorkspacesAjaxHandler(xmlhttp1);
	}
	xmlhttp1.setRequestHeader("_csrf", token);
	xmlhttp1.send(null);
}

function fetchWorkspacesAjaxHandler(xmlhttp1) {
	try {
		if (xmlhttp1.readyState == 4 && xmlhttp1.status == 200) {
			var response = xmlhttp1.responseText;
			var workspaces = JSON.parse(response);
			workspaces.sort(compare);
	
			var workspacesSelect = document.getElementById("workspaces");
			workspacesSelect.innerHTML = "";
	
			for (var i = 0; i < workspaces.length; i++) {
				var option = document.createElement("option");
				option.text = workspaces[i].name;
				option.value = workspaces[i].workspaceId;
				workspacesSelect.add(option);
			}
		} else if (xmlhttp1.status == 403) {
			var modal = document.getElementById('explorerModal');
			modal.style.display = "none";
			modalFlag = false;
			loggedIn = false;
			loginCheck();
		}
	}
	catch(error) {
		return;
	}
}

function closeExplorerModel() {
	var modal = document.getElementById('explorerModal');
	modal.style.display = "none";
	modalFlag = false;
}

function saveAsNew() {
	if (document.getElementById('workspace-name').value.length <= 0 || document.getElementById('workspace-name').value.indexOf(' ') >= 0) {
		alert("Please ensure you specify a new name for your new workspace and that it doesn't contain spaces.");
		return;
	}
	
	var result = confirm("Are you sure you wish to save " + document.getElementById('workspace-name').value + " workspace?");
	if (!result) {
		return;
	}

	var dom = document.getElementById("workspace").innerHTML;
	var workspace = {};
	workspace["workspaceId"] = 0;
	workspace["name"] = document.getElementById('workspace-name').value;
	workspace["workspaceState"] = {};
	workspace.workspaceState["dom"] = btoa(dom);
	workspace.workspaceState["zIndex"] = zIndex;
	workspace.workspaceState["microserviceInstanceCounter"] = microserviceInstanceCounter;
	workspace.workspaceState["topicInstanceCounter"] = topicInstanceCounter;
	workspace.workspaceState["queueInstanceCounter"] = queueInstanceCounter;
	workspace.workspaceState["datastoreInstanceCounter"] = datastoreInstanceCounter;
	workspace.workspaceState["lineInstanceCounter"] = lineInstanceCounter;
	workspace.workspaceState["arrowInstanceCounter"] = arrowInstanceCounter;
	workspace.workspaceState["partitionInstanceCounter"] = partitionInstanceCounter;
	workspace.workspaceState["serviceInstanceCounter"] = serviceInstanceCounter;
	workspace.workspaceState["textInstanceCounter"] = textInstanceCounter;
	workspace.workspaceState["redisInstanceCounter"] = redisInstanceCounter;
	workspace.workspaceState["vaultInstanceCounter"] = vaultInstanceCounter;
	workspace.workspaceState["fileInstanceCounter"] = fileInstanceCounter;
	console.log(JSON.stringify(workspace));
	
	document.getElementById("workspace_in").value = JSON.stringify(workspace);

	var xmlhttp1 = getxmlhttp();
	xmlhttp1.onreadystatechange = function() {
		if (xmlhttp1.readyState == 4 && xmlhttp1.status == 201) {
			var response = xmlhttp1.responseText;
			var modal = document.getElementById('explorerModal');
			modal.style.display = "none";
			modalFlag = false;
			var location = xmlhttp1.getResponseHeader("Location");
			workspaceId = location.replace('/workspaces/', '');
		} else if (xmlhttp1.status == 403) {
			var modal = document.getElementById('explorerModal');
			modal.style.display = "none";
			modalFlag = false;
			loggedIn = false;
			loginCheck();
		}
	}
	xmlhttp1.open (document.getElementById("login").method, "/workspaces", true);
	xmlhttp1.send (new FormData (document.getElementById("login")));
}

function openWorkspace() {
	var workspaces = document.getElementById('workspaces');
	var workspaceId = workspaces.options[workspaces.selectedIndex].value;
	
	var thisdate = new Date();
	var serverPage = "workspaces/" + workspaceId + "?time=" + thisdate.getTime();

	var xmlhttp1 = getxmlhttp();
	xmlhttp1.open("GET", serverPage);
	xmlhttp1.onreadystatechange = function() {
		openWorkspaceAjaxHandler(xmlhttp1);
	}
	xmlhttp1.setRequestHeader("_csrf", token);
	xmlhttp1.send(null);
}

function openWorkspaceAjaxHandler(xmlhttp1, workspaceFlag) {
	try {
		if (xmlhttp1.readyState == 4 && xmlhttp1.status == 200) {
			var response = xmlhttp1.responseText;
			var workspace = JSON.parse(response);
			document.getElementById("workspace").innerHTML = atob(workspace.workspaceState.dom);
			zIndex = workspace.workspaceState.zIndex;
			console.log("microserviceInstanceCounter: " + workspace.workspaceState.microserviceInstanceCounter);
			
			if(document.querySelectorAll('.microservice-instance').length > 0) {
				microserviceInstanceCounter = parseInt(document.querySelectorAll('.microservice-instance')[document.querySelectorAll('.microservice-instance').length - 1].id.replace("microservice-instance", "")) + 1;
			}
			if(document.querySelectorAll('.topic-instance').length > 0) {
				topicInstanceCounter = parseInt(document.querySelectorAll('.topic-instance')[document.querySelectorAll('.topic-instance').length - 1].id.replace("topic-instance", "")) + 1;
			}
			if(document.querySelectorAll('.queue-instance').length > 0) {
				queueInstanceCounter = parseInt(document.querySelectorAll('.queue-instance')[document.querySelectorAll('.queue-instance').length - 1].id.replace("queue-instance", "")) + 1;
			}
			if(document.querySelectorAll('.datastore-instance').length > 0) {
				datastoreInstanceCounter = parseInt(document.querySelectorAll('.datastore-instance')[document.querySelectorAll('.datastore-instance').length - 1].id.replace("datastore-instance", "")) + 1;
			}
			if(document.querySelectorAll('.line-instance').length > 0) {
				lineInstanceCounter = parseInt(document.querySelectorAll('.line-instance')[document.querySelectorAll('.line-instance').length - 1].id.replace("line-instance", "")) + 1;
			}
			if(document.querySelectorAll('.arrow-instance').length > 0) {
				arrowInstanceCounter = parseInt(document.querySelectorAll('.arrow-instance')[document.querySelectorAll('.arrow-instance').length - 1].id.replace("arrow-instance", "")) + 1;
			}
			if(document.querySelectorAll('.partition-instance').length > 0) {
				partitionInstanceCounter = parseInt(document.querySelectorAll('.partition-instance')[document.querySelectorAll('.partition-instance').length - 1].id.replace("partition-instance", "")) + 1;
			}
			if(document.querySelectorAll('.service-instance').length > 0) {
				serviceInstanceCounter = parseInt(document.querySelectorAll('.service-instance')[document.querySelectorAll('.service-instance').length - 1].id.replace("service-instance", "")) + 1;
			}
			if(document.querySelectorAll('.text-instance').length > 0) {
				textInstanceCounter = parseInt(document.querySelectorAll('.text-instance')[document.querySelectorAll('.text-instance').length - 1].id.replace("text-instance", "")) + 1;
			}
			if(document.querySelectorAll('.redis-instance').length > 0) {
				redisInstanceCounter = parseInt(document.querySelectorAll('.redis-instance')[document.querySelectorAll('.redis-instance').length - 1].id.replace("redis-instance", "")) + 1;
			}
			if(document.querySelectorAll('.vault-instance').length > 0) {
				vaultInstanceCounter = parseInt(document.querySelectorAll('.vault-instance')[document.querySelectorAll('.vault-instance').length - 1].id.replace("vault-instance", "")) + 1;
			}
			if(document.querySelectorAll('.file-instance').length > 0) {
				fileInstanceCounter = parseInt(document.querySelectorAll('.file-instance')[document.querySelectorAll('.file-instance').length - 1].id.replace("file-instance", "")) + 1;
			}
			
//			microserviceInstanceCounter = workspace.workspaceState.microserviceInstanceCounter;
//			topicInstanceCounter = workspace.workspaceState.topicInstanceCounter;
//			queueInstanceCounter = workspace.workspaceState.queueInstanceCounter;
//			datastoreInstanceCounter = workspace.workspaceState.datastoreInstanceCounter;
//			lineInstanceCounter = workspace.workspaceState.lineInstanceCounter;
//			arrowInstanceCounter = workspace.workspaceState.arrowInstanceCounter;
//			partitionInstanceCounter = workspace.workspaceState.partitionInstanceCounter;
//			serviceInstanceCounter = workspace.workspaceState.serviceInstanceCounter;
//			textInstanceCounter = workspace.workspaceState.textInstanceCounter;
//			redisInstanceCounter = workspace.workspaceState.redisInstanceCounter;
//			vaultInstanceCounter = workspace.workspaceState.vaultInstanceCounter;
//			fileInstanceCounter = workspace.workspaceState.fileInstanceCounter;
			
			workspaceId = workspace.workspaceId;
			document.getElementById('workspace-label').innerHTML = workspace.name;
			document.getElementById('workspace-label-export').innerHTML = workspace.name;
			document.getElementById('saveButton').disabled = false;
			
			var url = window.location.href;
			if (url.indexOf("-dev") != -1) {
				document.getElementById('title').innerHTML = workspace.name + " (DEV)";
			} else if (url.indexOf("-qat") != -1) {
				document.getElementById('title').innerHTML = workspace.name + " (QAT)";
			} else if (url.indexOf("-uat") != -1) {
				document.getElementById('title').innerHTML = workspace.name + " (UAT)";
			} else if (url.indexOf("pcf.fg.rbc.com") != -1) {
				document.getElementById('title').innerHTML = workspace.name + " (PROD)";
			} else {
				document.getElementById('title').innerHTML = workspace.name + " (local)";
			}
			
			var modal = document.getElementById('explorerModal');
			modal.style.display = "none";
			modalFlag = false;
			
			if (workspaceFlag) {
				expandCollapse();
				document.getElementById("up-scroll").style.display = "none";
				document.getElementById("down-scroll").style.display = "none";
				document.getElementById("explorer").style.display = "none";
				document.getElementById("new").style.display = "none";
				document.getElementById("expand-collapse").style.display = "none";
				document.getElementById("save").style.display = "none";
			}
			
//			microserviceInstanceCounter = document.querySelectorAll('.microservice-instance').length;
//			topicInstanceCounter = document.querySelectorAll('.topic-instance').length;
//			queueInstanceCounter = document.querySelectorAll('.queue-instance').length;
//			datastoreInstanceCounter = document.querySelectorAll('.datastore-instance').length;
//			lineInstanceCounter = document.querySelectorAll('.line-instance').length;
//			arrowInstanceCounter = document.querySelectorAll('.arrow-instance').length;
//			partitionInstanceCounter = document.querySelectorAll('.partition-instance').length;
//			serviceInstanceCounter = document.querySelectorAll('.service-instance').length;
//			textInstanceCounter = document.querySelectorAll('.text-instance').length;
//			redisInstanceCounter = document.querySelectorAll('.redis-instance').length;
//			vaultInstanceCounter = document.querySelectorAll('.vault-instance').length;
//			fileInstanceCounter = document.querySelectorAll('.file-instance').length;
			
		} else if (xmlhttp1.status == 403) {
			var modal = document.getElementById('explorerModal');
			modal.style.display = "none";
			modalFlag = false;
			loggedIn = false;
			loginCheck();
		}
	}
	catch(error) {
		return;
	}
}

function save() {
	var result = confirm("Are you sure you wish to save " + document.getElementById('workspace-label').innerHTML + " workspace?");
	if (!result) {
		return;
	}
	
//	microserviceInstanceCounter = document.querySelectorAll('.microservice-instance').length;
//	topicInstanceCounter = document.querySelectorAll('.topic-instance').length;
//	queueInstanceCounter = document.querySelectorAll('.queue-instance').length;
//	datastoreInstanceCounter = document.querySelectorAll('.datastore-instance').length;
//	lineInstanceCounter = document.querySelectorAll('.line-instance').length;
//	arrowInstanceCounter = document.querySelectorAll('.arrow-instance').length;
//	partitionInstanceCounter = document.querySelectorAll('.partition-instance').length;
//	serviceInstanceCounter = document.querySelectorAll('.service-instance').length;
//	textInstanceCounter = document.querySelectorAll('.text-instance').length;
//	redisInstanceCounter = document.querySelectorAll('.redis-instance').length;
//	vaultInstanceCounter = document.querySelectorAll('.vault-instance').length;
//	fileInstanceCounter = document.querySelectorAll('.file-instance').length;
	
	var dom = document.getElementById("workspace").innerHTML;
	var workspace = {};
	workspace["workspaceId"] = workspaceId;
	workspace["name"] = document.getElementById('workspace-label').innerHTML;
	workspace["workspaceState"] = {};
	workspace.workspaceState["dom"] = btoa(dom);
	workspace.workspaceState["zIndex"] = zIndex;
	workspace.workspaceState["microserviceInstanceCounter"] = microserviceInstanceCounter;
	workspace.workspaceState["topicInstanceCounter"] = topicInstanceCounter;
	workspace.workspaceState["queueInstanceCounter"] = queueInstanceCounter;
	workspace.workspaceState["datastoreInstanceCounter"] = datastoreInstanceCounter;
	workspace.workspaceState["lineInstanceCounter"] = lineInstanceCounter;
	workspace.workspaceState["arrowInstanceCounter"] = arrowInstanceCounter;
	workspace.workspaceState["partitionInstanceCounter"] = partitionInstanceCounter;
	workspace.workspaceState["serviceInstanceCounter"] = serviceInstanceCounter;
	workspace.workspaceState["textInstanceCounter"] = textInstanceCounter;
	workspace.workspaceState["redisInstanceCounter"] = redisInstanceCounter;
	workspace.workspaceState["vaultInstanceCounter"] = vaultInstanceCounter;
	workspace.workspaceState["fileInstanceCounter"] = fileInstanceCounter;
	console.log(JSON.stringify(workspace));

	var thisdate = new Date();
	var serverPage = "workspaces/" + workspaceId + "?time=" + thisdate.getTime();

	var xmlhttp1 = getxmlhttp();
	xmlhttp1.open("PUT", serverPage);
	xmlhttp1.setRequestHeader("Content-Type", "application/json");
	xmlhttp1.onreadystatechange = function() {
		saveAjaxHandler(xmlhttp1);
	}
	xmlhttp1.setRequestHeader("x-csrf-token", token);
	xmlhttp1.send(JSON.stringify(workspace));
}

function saveAjaxHandler(xmlhttp1) {
	if (xmlhttp1.readyState == 4 && xmlhttp1.status == 204) {
		var response = xmlhttp1.responseText;
		var modal = document.getElementById('explorerModal');
		modal.style.display = "none";
		modalFlag = false;
		alert("Workspace saved");
	} else if (xmlhttp1.status == 403) {
		var modal = document.getElementById('explorerModal');
		modal.style.display = "none";
		modalFlag = false;
		loggedIn = false;
		loginCheck();
	}
}

function compare(a, b) {
	var comparison = 0;

	if (a.name > b.name) {
		comparison = 1;
	} else if (b.name > a.name) {
		comparison = -1;
	}

	return comparison;
}

function newWorkspace() {
	console.log(document.body.innerHTML);
	var result = confirm("Click OK if you are sure you wish to create a new workspace - your current workspace will be lost.");
	if(result) {
		window.location = window.location.protocol + "//" + window.location.hostname + ":" + window.location.port;
	}
}

function loadWorkspace() {
	var workspaceParams = window.location.search.substr(1);
	var id = workspaceParams.substr(0, workspaceParams.indexOf("="));
	if (id == "workspace") {
		workspaceFlag = true;
		var workspaceName = workspaceParams.substr(workspaceParams.indexOf("=") + 1, workspaceParams.length);
		openWorkspaceByName(workspaceName);
		document.getElementById("help").style.display = "none";
		document.getElementById("log-link").innerHTML = "login";
	}
	
	if (document.addEventListener){
		document.addEventListener("keydown", keyDownTextField, false); 
	} else if (document.attachEvent){
		document.attachEvent("keydown", keyDownTextField);
	}
}

function openWorkspaceByName(workspaceName) {
	var thisdate = new Date();
	var serverPage = "workspaces/name/" + workspaceName;

	var xmlhttp1 = getxmlhttp();
	xmlhttp1.open("GET", serverPage);
	xmlhttp1.onreadystatechange = function() {
		openWorkspaceAjaxHandler(xmlhttp1, true);
	}
	xmlhttp1.setRequestHeader("_csrf", token);
	xmlhttp1.send(null);
}

function checkIfLoggedIn() {
	var workspaceParams = window.location.search.substr(1);
	var login = workspaceParams.substr(0, workspaceParams.indexOf("="));
	if(login != "login") {
		closeLogin();
		document.getElementById('help-icon').style.display = "block";
	} else {
		document.getElementById('help-icon').style.display = "none";
	}
	if (workspaceParams.indexOf("error") > 0) {
		alert("Please ensure that username and password are correct and try again");
	}
}

function expandCollapse() {
	if(document.getElementById('toolbar').style.display === "block" || document.getElementById('toolbar').style.display === "") {
		document.getElementById('toolbar').style.display = "none";
		document.getElementById('mini-toolbar').style.left = "2px";
		document.getElementById('workspace').style.left = "0px";
	} else {
		document.getElementById('toolbar').style.display = "block";
		document.getElementById('mini-toolbar').style.left = "260px";
		document.getElementById('workspace').style.left = "260px";
	}
}

function browserCheck() {
    //Check if browser is IE
    if (navigator.userAgent.search("MSIE") >= 0) {
        alert("You appear to be using Microsoft Internet Explorer.\n\nThis app was targeted for Google Chrome");
    }
    //Check if browser is Chrome
    else if (navigator.userAgent.search("Chrome") >= 0) {
        // insert conditional Chrome code here
    }
    //Check if browser is Firefox 
    else if (navigator.userAgent.search("Firefox") >= 0) {
        alert("You appear to be using Firefox.\n\nThis app was targeted for Google Chrome");
    }
    //Check if browser is Safari
    else if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
        alert("You appear to be using Safari.\n\nThis app was targeted for Google Chrome");
    }
    //Check if browser is Opera
    else if (navigator.userAgent.search("Opera") >= 0) {
        alert("You appear to be using Opera.\n\nThis app was targeted for Google Chrome");
    }
//    else {
//    	alert("You appear to be using an un-supported browser.\n\nThis app was targeted for Google Chrome");
//    }
}

function loginCheck() {
	if (!loggedIn) {
		modalFlag = true;
		modalType = "login";
		var modal = document.getElementById('loginModal');
		modal.style.display = "block";
		var username = document.getElementById('username');
		username.focus();
		username.select();
	} else {
	}
}

function closeLogin() {
	var modal = document.getElementById('loginModal');
	modal.style.display = "none";
	modalFlag = false;
}

function getToken() {
	var thisdate = new Date();
	var serverPage = "token";

	var xmlhttp1 = getxmlhttp();
	xmlhttp1.open("GET", serverPage);
	xmlhttp1.onreadystatechange = function() {
		getTokenAjaxHandler(xmlhttp1);
	}
	xmlhttp1.send(null);
}

function getTokenAjaxHandler(xmlhttp1) {
	if (xmlhttp1.readyState == 4 && xmlhttp1.status == 200) {
		var response = xmlhttp1.responseText;
		token = response;
		document.getElementById('_csrf').value = token;
	}
}

function logout() {
	document.getElementById('_csrf_logout').value = token;
	document.getElementById('logout').submit();	
}

function login() {
	document.getElementById('login').submit();
}

function exportWorkspace(data, filename, type) {
	var workspace = document.getElementById("workspace").innerHTML;
    var file = new Blob([workspace], {type: type});
    if (window.navigator.msSaveOrOpenBlob) // IE10+
        window.navigator.msSaveOrOpenBlob(file, filename);
    else {
        var a = document.createElement("a"),
                url = URL.createObjectURL(file);
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(function() {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);  
        }, 0); 
    }
	var modal = document.getElementById('explorerModal');
	modal.style.display = "none";
	alert("File exported!");
}

function importWorkspace() {
	var fileInput = document.getElementById('file-input');
	var file = fileInput.files[0];
	  if (!file) {
	    alert("no file selected");
	    return;
	  } else {
		  var reader = new FileReader();
		  reader.onload = function(fileInput) {
			    var contents = fileInput.target.result;
			    document.getElementById("workspace").innerHTML = contents;
			    alert("File imported!");
		  };
		  reader.readAsText(file);
	  }
		var modal = document.getElementById('explorerModal');
		modal.style.display = "none";
}

function deleteWorkspace() {
	var workspaces = document.getElementById('workspaces');
	var workspaceId = workspaces.options[workspaces.selectedIndex].value;
	var workspaceName = workspaces.options[workspaces.selectedIndex].innerHTML;
	var deleteFlag = confirm('Click OK if you are you sure you wish to delete workspace:\n\n' + workspaceName);
	
	if (deleteFlag) {
		var thisdate = new Date();
		var serverPage = "workspaces/" + workspaceId + "?time=" + thisdate.getTime();

		var xmlhttp1 = getxmlhttp();
		xmlhttp1.open("DELETE", serverPage);
		xmlhttp1.onreadystatechange = function() {
			deleteWorkspaceAjaxHandler(xmlhttp1);
		}
		xmlhttp1.setRequestHeader("x-csrf-token", token);
		xmlhttp1.send(null);
	}
}

function deleteWorkspaceAjaxHandler(xmlhttp1, workspaceFlag) {
	try {
		if (xmlhttp1.readyState == 4 && xmlhttp1.status == 204) {
			var response = xmlhttp1.responseText;
			alert("Workspace deleted successfully");
			var modal = document.getElementById('explorerModal');
			modal.style.display = "none";
			modalFlag = false;
		}
	}
	catch(error) {
		return;
	}
}

function saveWorkspace() {
	workspaceName = document.getElementById('workspace-label').innerHTML;
	if(workspaceName == "no workspace selected") {
		explore();
	} else {
		save();
	}
}