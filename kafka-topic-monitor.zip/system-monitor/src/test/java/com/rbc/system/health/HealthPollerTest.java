package com.rbc.system.health;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.rbc.deposits.rest.client.ClientException;
import com.rbc.deposits.rest.client.ClientResponse;
import com.rbc.deposits.rest.client.handlers.GetHandler;

public class HealthPollerTest {

    @Before
    public void setup() {
        HealthPoller.cache = new HashMap<>();
    }

    @Test
    public void testCache() {
        HealthPoller.cache.put("a", new HashMap<>());
        HealthPoller.cache.get("a").put(HealthPoller.HEALTH_PAYLOAD_KEY, "a");
        HealthPoller.cache.put("b", new HashMap<>());
        HealthPoller.cache.get("b").put(HealthPoller.HEALTH_PAYLOAD_KEY, "b");
        HealthPoller.cache.put("c", new HashMap<>());
        HealthPoller.cache.get("c").put(HealthPoller.HEALTH_PAYLOAD_KEY, "c");

        assertEquals("a", HealthPoller.cache.get("a").get(HealthPoller.HEALTH_PAYLOAD_KEY));
        assertEquals("b", HealthPoller.cache.get("b").get(HealthPoller.HEALTH_PAYLOAD_KEY));
        assertEquals("c", HealthPoller.cache.get("c").get(HealthPoller.HEALTH_PAYLOAD_KEY));

        assertEquals(null, HealthPoller.cache.get("d"));

        HealthPoller.cache.put("d", new HashMap<>());
        HealthPoller.cache.get("d").put(HealthPoller.HEALTH_PAYLOAD_KEY, "d");

        assertEquals("d", HealthPoller.cache.get("d").get(HealthPoller.HEALTH_PAYLOAD_KEY));
    }

    @Test
    public void testRemoveFromCache() {
        HealthPoller.cache.put("a", new HashMap<>());
        HealthPoller.cache.put("b", new HashMap<>());
        HealthPoller.cache.put("c", new HashMap<>());
        HealthPoller.cache.put("d", new HashMap<>());

        Map<String, Map<String, String>> tempCache = new HashMap<>();
        tempCache.put("a", new HashMap<>());
        tempCache.put("b", new HashMap<>());
        tempCache.put("d", new HashMap<>());

        Iterator<String> it = HealthPoller.cache.keySet().iterator();
        while (it.hasNext()) {
            String key = it.next();
            if (tempCache.get(key) == null) {
                it.remove();
                System.out.println("Entry " + key + " removed");
            }
        }
        assertEquals(null, HealthPoller.cache.get("c"));
    }


    @Test
    @Ignore
    public void testRestClient() throws ClientException {
        GetHandler<String> getHander = new GetHandler<>();
        System.out.println("*** - about to invoke the get handler");
        ClientResponse<String> clientResponse = getHander.exec("http://localhost:8088/health", String.class);
        String json = clientResponse.getValue();
        System.out.println("clientResponse - we get here...: " + json);
    }

}
