# kafka-monitor
A 'Fully-Packaged Single Page Application' (FPSPA) project for monitoring Kafka Topics

Simply navigate to: http://localhost:8090/