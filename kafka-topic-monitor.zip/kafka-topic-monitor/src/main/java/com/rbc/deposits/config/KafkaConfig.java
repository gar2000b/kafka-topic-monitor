package com.rbc.deposits.config;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rbc.deposits.model.TopicConfiguration;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;

@Component
public class KafkaConfig {

    private static final String SEPARATOR = "/";

    /**
     * The following configuration constants are for testing locally (DEV VM version of Kafka). All other configurations will be read from UPS.
     */
    public static final String IT_TEST_TOPIC_LOCAL = "zgv0-d-i-test";
    public static final String DEV_BDA_RAW_INTRADAY_NON_FIN_TOPIC_LOCAL = "zgv0-d-bda-raw-intraday-non-fin-txn";
    public static final String DEV_PDA_RAW_INTRADAY_NON_FIN_TOPIC_LOCAL = "zgv0-d-pda-raw-intraday-non-fin-txn";
    public static final String DEV_BDA_ACCOUNT_STATUS_CHANGE_LOCAL = "zgv0-d-bda-account-status-change-event";
    public static final String DEV_PDA_ACCOUNT_STATUS_CHANGE_LOCAL = "zgv0-d-pda-account-status-change-event";

    public static final String IT_TEST_TOPIC_LOCAL_CONFIGURATION = "{\"topic\":\"zgv0-d-i-test\", \"consumerGroup\":\"zgv0-d-i-test-monitor\", "
                    + "\"environment\":\"IT\", \"jaasConsumerConf\":\"NA\", " + "\"keytabFilename\":\"NA\", \"keytab\":\"NA\"}";
    public static final String DEV_BDA_RAW_INTRADAY_NON_FIN_TOPIC_LOCAL_CONFIGURATION = "{\"topic\":\"zgv0-d-bda-raw-intraday-non-fin-txn\", \"consumerGroup\":\"zgv0-d-bda-raw-intraday-non-fin-txn-monitor\", "
                    + "\"environment\":\"DEV\", \"jaasConsumerConf\":\"NA\", " + "\"keytabFilename\":\"NA\", \"keytab\":\"NA\"}";
    public static final String DEV_PDA_RAW_INTRADAY_NON_FIN_TOPIC_LOCAL_CONFIGURATION = "{\"topic\":\"zgv0-d-pda-raw-intraday-non-fin-txn\", \"consumerGroup\":\"zgv0-d-pda-raw-intraday-non-fin-txn-monitor\", "
                    + "\"environment\":\"DEV\", \"jaasConsumerConf\":\"NA\", " + "\"keytabFilename\":\"NA\", \"keytab\":\"NA\"}";
    public static final String DEV_BDA_ACCOUNT_STATUS_CHANGE_LOCAL_CONFIGURATION = "{\"topic\":\"zgv0-d-bda-account-status-change-event\", \"consumerGroup\":\"zgv0-d-bda-account-status-change-event-monitor\", "
                    + "\"environment\":\"DEV\", \"jaasConsumerConf\":\"NA\", " + "\"keytabFilename\":\"NA\", \"keytab\":\"NA\"}";
    public static final String DEV_PDA_ACCOUNT_STATUS_CHANGE_LOCAL_CONFIGURATION = "{\"topic\":\"zgv0-d-pda-account-status-change-event\", \"consumerGroup\":\"zgv0-d-pda-account-status-change-event-monitor\", "
                    + "\"environment\":\"DEV\", \"jaasConsumerConf\":\"NA\", " + "\"keytabFilename\":\"NA\", \"keytab\":\"NA\"}";

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private File userDirectory = org.apache.commons.io.FileUtils.getUserDirectory();

    @Autowired
    ApplicationProperties applicationProperties;

    public Properties buildConsumerProperties(TopicConfiguration topicConfiguration) {
        Properties properties = new Properties();

        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, applicationProperties.getBootstrapServers());
        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class);
        properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        properties.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "200");
        properties.put("schema.registry.url", applicationProperties.getSchemaRegistryUrl());
        properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        logger.info("^^^ " + applicationProperties.getBootstrapServers());
        logger.info("^^^ " + topicConfiguration.getConsumerGroup());

        if (StringUtils.isNotBlank(topicConfiguration.getConsumerGroup())) {
            properties.put("group.id", topicConfiguration.getConsumerGroup());
        }

        if (applicationProperties.getApplicationEnvCode().equals("l")) {
            return properties;
        }

        String trustStoreFile = "kafka-security.jks";
        String trustStoreJarPath = "security" + SEPARATOR + trustStoreFile;

        try {
            copyBinaryFile(getClass().getClassLoader().getResource(trustStoreJarPath),
                            new File(userDirectory.getPath().toString() + SEPARATOR + trustStoreFile));
            logger.info("^^^ truststore copied to: " + userDirectory.getPath().toString() + SEPARATOR + trustStoreFile);
        } catch (Exception e) {
            e.printStackTrace();
        }

        byte[] keytab = Base64.getMimeDecoder().decode(topicConfiguration.getKeytab());

        String securityPath = userDirectory.getPath().toString() + SEPARATOR;

        String keytabLocation = securityPath + topicConfiguration.getKeytabFilename();
        keytabLocation = keytabLocation.replace("\\", SEPARATOR);

        logger.info("^^^ keytab encoded: " + topicConfiguration.getKeytab());
        logger.info("^^^ keytab: " + keytab);
        logger.info("^^^ keytab location: " + keytabLocation);

        try {
            Path keytabPath = Paths.get(keytabLocation);
            Files.createDirectories(keytabPath.getParent());
            File keytabFile = keytabPath.toFile();
            if (keytabFile.exists()) {
                keytabFile.delete();
            }
            keytabFile.createNewFile();
            Files.write(keytabFile.toPath(), keytab);
        } catch (IOException e) {
            e.printStackTrace();
        }

        String jaasConsumerConf = topicConfiguration.getJaasConsumerConf();
        jaasConsumerConf = jaasConsumerConf.replace("{keytabFile}", keytabLocation);

        properties.put("security.protocol", "SASL_SSL");
        properties.put("sasl.kerberos.service.name", "kafka");
        properties.put("sasl.jaas.config", jaasConsumerConf);

        logger.info("^^^ jaas config: " + jaasConsumerConf);

        System.setProperty("java.security.krb5.realm", applicationProperties.getKrb5Realm());
        System.setProperty("java.security.krb5.kdc", applicationProperties.getKrb5Kdc());
        System.setProperty("sun.security.krb5.debug", applicationProperties.getKrb5Debug());

        properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, securityPath + trustStoreFile);
        properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, "certsaloha!2");

        String topic = topicConfiguration.getTopic();
        logger.info("Target Kafka Topic for consumption [{}]", topic);

        return properties;
    }

    private void copyBinaryFile(URL from, File to) throws Exception {
        try {
            FileUtils.copyURLToFile(from, to);
        } catch (Exception e) {
            logger.info(e.getMessage());
        }
    }
}
