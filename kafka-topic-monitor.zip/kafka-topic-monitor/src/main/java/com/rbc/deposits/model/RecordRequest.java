package com.rbc.deposits.model;

import org.springframework.messaging.simp.SimpMessagingTemplate;

/**
 * Kafka Record Request generated from Client request indicating to backing service to lookup a record at a specific offset.
 * 
 * @author 330885096
 *
 */
public class RecordRequest {

    private String topicName;
    private int offset;
    private String timestamp;
    private String uuid;
    private SimpMessagingTemplate template;

    public RecordRequest(String topicName, int offset, String timestamp, String uuid, SimpMessagingTemplate template) {
        super();
        this.topicName = topicName;
        this.offset = offset;
        this.timestamp = timestamp;
        this.uuid = uuid;
        this.template = template;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public SimpMessagingTemplate getTemplate() {
        return template;
    }

    public void setTemplate(SimpMessagingTemplate template) {
        this.template = template;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    
}
