package com.rbc.deposits;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.rbc.deposits.logger.client.console.ConsoleWriter;

@SpringBootApplication(scanBasePackages = "com.rbc.deposits")
public class KafkaTopicMonitorApp {

    public static void main(String[] args) {
        ConsoleWriter.isInfo();

        SpringApplication.run(KafkaTopicMonitorApp.class, args);
    }
}
