package com.rbc.deposits.rest;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rbc.deposits.kafka.Processor;
import com.rbc.deposits.model.TopicRecord;

@RestController
@RequestMapping(value = UriTemplates.API_PATH)
public class KafkatTopicMonitorRest {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    KafkaController controller;

    @Autowired
    Processor kafkaConsumer;

    @RequestMapping(value = UriTemplates.V1_FETCH_RECORDS, method = RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE})
    public List<TopicRecord> fetchRecords(@RequestHeader("topicName") String topicName) {
        String recordLimit = "100";
        String uuid = UUID.randomUUID().toString();

        logger.info("fetchRecords for topic : [{}], recordLimit: [{}], uuid: [{}]", topicName, recordLimit, uuid);

        if (StringUtils.isNotBlank(topicName) && kafkaConsumer.topicConfigurations.get(topicName) != null) {
            List<TopicRecord> records = controller.populateRecords(topicName, recordLimit, uuid);

            return records.stream().map(t -> t).sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        }

        return null;
    }

}
