package com.rbc.deposits.model;

import java.util.Map;

public class TopicRecord implements Comparable<TopicRecord> {

    String topicName;
    int partition;
    Long offset;
    String key;
    String value;
    String offsetTimestamp;
    Map<String, String> headers;

    public TopicRecord(String topicName, int partition, long offset, String key, String value, String offsetTimeStmap) {
        super();
        this.topicName = topicName;
        this.partition = partition;
        this.offset = offset;
        this.key = key;
        this.value = value;
        this.offsetTimestamp = offsetTimeStmap;
    }

    public TopicRecord(String topicName, int partition, long offset, String key, String value, String string, Map<String, String> headers) {
        super();
        this.topicName = topicName;
        this.partition = partition;
        this.offset = offset;
        this.key = key;
        this.value = value;
        this.offsetTimestamp = string;
        this.headers = headers;
    }

    public String getTopicName() {
        return topicName;
    }

    public int getPartition() {
        return partition;
    }

    public Long getOffset() {
        return offset;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public String getOffsetTimestamp() {
        return offsetTimestamp;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public void setPartition(int partition) {
        this.partition = partition;
    }

    public void setOffset(Long offset) {
        this.offset = offset;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setOffsetTimestamp(String offsetTimestamp) {
        this.offsetTimestamp = offsetTimestamp;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }


    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("[partition=");
        builder.append(partition);
        builder.append(", time=");
        builder.append(offsetTimestamp);
        builder.append(", offset=");
        builder.append(offset);
        builder.append(", value=");
        builder.append(value);
        builder.append("]");
        return builder.toString();
    }

    @Override
    public int compareTo(TopicRecord o) {
        return getOffset().compareTo(o.getOffset());
    }

}
