package com.rbc.deposits.rest;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbc.deposits.config.KafkaConfig;
import com.rbc.deposits.kafka.Processor;
import com.rbc.deposits.model.RecordRequest;
import com.rbc.deposits.model.TopicDetail;
import com.rbc.deposits.model.TopicRecord;

/**
 * Service to handle Kafka Topic Monitoring requests.
 * 
 * @author 330885096
 *
 */
@Controller
@EnableAutoConfiguration
@EnableScheduling
public class KafkaController {
    private static final int FETCH_TOPIC_DETAIL_INTERVAL = 500;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String GLOBAL_TOPIC_DETAILS_TOPIC = "/topic/topicDetails";

    @Autowired
    private SimpMessagingTemplate template;

    @Autowired
    KafkaConfig kafkaConfig;

    @Autowired
    Processor processor;

    @RequestMapping(method = RequestMethod.GET, produces = "application/json", value = "/token")
    @ResponseBody
    public String token(HttpServletRequest request, HttpServletResponse response) {
        logger.info("**** session timeout = " + request.getSession().getMaxInactiveInterval());
        // request.getSession().setMaxInactiveInterval(20);

        CsrfToken token = (CsrfToken) request.getAttribute("_csrf");

        response.setHeader("X-CSRF-HEADER", token.getHeaderName());
        response.setHeader("X-CSRF-PARAM", token.getParameterName());
        response.setHeader("X-CSRF-TOKEN", token.getToken());

        return token.getToken();
    }

    @RequestMapping(method = RequestMethod.GET, produces = "application/json", value = "/session-timeout")
    @ResponseBody
    public String sessionTimeout(HttpServletRequest request, HttpServletResponse response) {
        logger.info("**** session timeout = " + request.getSession().getMaxInactiveInterval());

        return String.valueOf(request.getSession().getMaxInactiveInterval());
    }

    @RequestMapping(method = RequestMethod.POST, value = "/reset-consumers")
    @ResponseBody
    public void resetConsumers(HttpServletRequest request, HttpServletResponse response) throws InterruptedException {
        logger.info("resetConsumers() entry");

        processor.shutdownConsumers();

        Thread.sleep(4000);

        Processor.topics.clear();
        Processor.recordRequests.clear();
        processor.startConsumers();

        response.setStatus(HttpStatus.OK.value());

        logger.info("resetConsumers() exit");
    }

    /**
     * Fetch record details on a given topic/offset.
     * 
     * @param uuid the unique id from the client
     * @param request with topic info
     * @throws JsonProcessingException JsonProcessingException
     * @throws InterruptedException InterruptedException
     */
    @MessageMapping("/fetchRecord/{uuid}")
    public void fetchRecord(@DestinationVariable String uuid, Map<String, String> request) throws JsonProcessingException, InterruptedException {
        if (logger.isDebugEnabled()) {
            logger.debug("uuid: " + uuid);
        }

        RecordRequest recordRequest = new RecordRequest(request.get("topicName"), Integer.valueOf(request.get("offset")), request.get("timestamp"), uuid, template);

        Processor.recordRequests.add(recordRequest);
    }

    /**
     * Fetch all topic details and broadcast to all clients.
     * 
     * @throws JsonProcessingException JsonProcessingException
     */
    @Scheduled(fixedRate = FETCH_TOPIC_DETAIL_INTERVAL)
    public void fetchTopicDetails() throws JsonProcessingException {
        // logger.info("**** scheduler ****");
        try {
            ObjectMapper mapper = new ObjectMapper();

            Processor.topics.sort(Comparator.comparing(TopicDetail::getEnvironment).thenComparing(TopicDetail::getName));

            String record = mapper.writeValueAsString(Processor.topics);

            this.template.convertAndSend(GLOBAL_TOPIC_DETAILS_TOPIC, record);
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage());
        }
    }


    @RequestMapping(path = "/download/{topicName}/{recordsize}/{uuid}/{offset}", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<Resource> download(@PathVariable String topicName, @PathVariable String recordsize, @PathVariable String uuid, @PathVariable String offset) throws IOException {
        List<TopicRecord> eventcharSequence = populateRecords(topicName, recordsize, uuid);

        logger.info("eventcharSequence size=" + eventcharSequence.size());

        Path path = Files.write(Paths.get("", topicName), eventcharSequence.stream().map(t -> t.toString()).collect(Collectors.toList()), StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                        StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);

        ByteArrayResource resource = new ByteArrayResource(Files.readAllBytes(path));

        long size = Files.size(path);

        Files.delete(path);

        eventcharSequence.clear();

        return ResponseEntity.ok()
                        .contentLength(size)
                        .header("Content-Disposition", "attachment;filename=" + topicName + ".txt")
                        .contentType(MediaType.parseMediaType(MediaType.APPLICATION_OCTET_STREAM_VALUE))
                        .body(resource);

    }


    List<TopicRecord> populateRecords(String topicName, String recordsize, String uuid) {
        logger.info("populateRecords started.");

        Processor.isDownloadRequest.set(true);
        Processor.isDownloadReady.set(false);
        Processor.MAXIMUM_LIMIT_OF_RECORD = recordsize;

        RecordRequest recordRequest = new RecordRequest(topicName, 0, null, uuid, null);

        String key = recordRequest.getUuid() + "-" + recordRequest.getTopicName();

        Processor.topicRequestMap.put(key, recordRequest);

        List<TopicRecord> records = new ArrayList<>();

        do {
            if (Processor.isDownloadReady.get()) {
                // logger.info("Records are ready and in size of -" + Processor.downloadableRecordMap);
                records = Processor.downloadableRecordMap.get(key).stream().map(t -> t).sorted().collect(Collectors.toList());

                Processor.downloadableRecordMap.remove(key);

                break;
            }
        } while (true);

        return records;
    }

}
