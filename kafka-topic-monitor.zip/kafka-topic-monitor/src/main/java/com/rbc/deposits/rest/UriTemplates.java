package com.rbc.deposits.rest;

public class UriTemplates {

    public static final String API_PATH = "/api/topicmonitor";

    public static final String V1_FETCH_RECORDS = "/v1/fetch/records";

}
