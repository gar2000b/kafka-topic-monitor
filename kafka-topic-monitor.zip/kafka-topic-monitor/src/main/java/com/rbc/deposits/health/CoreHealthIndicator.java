package com.rbc.deposits.health;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.info.BuildProperties;
import org.springframework.stereotype.Component;

import com.rbc.deposits.config.ApplicationProperties;
import com.rbc.deposits.config.vcap.VcapUtil;

@Component
public class CoreHealthIndicator implements HealthIndicator {

    @Autowired
    private BuildProperties buildProperties;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private CoreHealthStatus coreHealthStatus;

    @Override
    public Health health() {
        String envCode = applicationProperties.getApplicationEnvCode();

        if (envCode.equals("l") || envCode.equals("i") || envCode.equals("di")) {
            return Health.up()
                            .withDetail("app", "Alive and Kicking")
                            .withDetail("version", buildProperties.getVersion())
                            .withDetail("dateTime", coreHealthStatus.getFormatedDateTime())
                            .build();
        } else {
            return Health.up()
                            .withDetail("app", "Alive and Kicking")
                            .withDetail("version", buildProperties.getVersion())
                            .withDetail("dateTime", coreHealthStatus.getFormatedDateTime())
                            .withDetail("applicationId", VcapUtil.getApplicationId())
                            .build();
        }
    }
}
