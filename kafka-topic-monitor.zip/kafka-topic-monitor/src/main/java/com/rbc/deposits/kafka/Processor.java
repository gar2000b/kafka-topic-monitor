package com.rbc.deposits.kafka;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.avro.generic.GenericData.Record;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndTimestamp;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbc.deposits.config.ApplicationProperties;
import com.rbc.deposits.config.KafkaConfig;
import com.rbc.deposits.config.vcap.VcapUtil;
import com.rbc.deposits.config.vcap.model.UserProvidedService;
import com.rbc.deposits.model.RecordRequest;
import com.rbc.deposits.model.TopicConfiguration;
import com.rbc.deposits.model.TopicDetail;
import com.rbc.deposits.model.TopicRecord;

@SuppressWarnings("deprecation")
@Component("consumer")
public class Processor {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String EMPTY = "";
    private static final String TOPIC_REGISTRATION_UPS = "topic-registration";

    private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private static final String OUT_OF_RANGE_MSG = "The offset requested appears to be out of range or there was an issue, "
                    + "please ensure you are requesting a record within the last 7 days or try again.";
    private static final String DATE_FORMAT_MSG = "Please ensure you are requesting a record with the date time format of " + DATE_FORMAT;
    private static final String INITIAL_DATE = "2018-01-01 00:00:00";
    private static final String LOCAL_ENV = "l";
    private static final String READY = "READY";
    private static final String EXECUTING = "EXECUTING";

    @SuppressWarnings("unused")
    private static final String SEPARATOR = "/";

    public static final String LOCAL_PATH = "/src/main/resources/security/";
    public static final String CLOUD_PATH = "/app/BOOT-INF/classes/security/";

    private AtomicBoolean runningFlag = new AtomicBoolean(true);

    SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

    private UserProvidedService topicRegistrationUps;

    public static int counter = 0;
    public static String lastValue = EMPTY;
    public static String lastValueTime = EMPTY;
    public static List<TopicDetail> topics = new ArrayList<>();
    public static List<RecordRequest> recordRequests = new ArrayList<>();
    public static Map<String, RecordRequest> topicRequestMap = new HashMap<String, RecordRequest>();
    public static List<Thread> threads = new ArrayList<>();

    @Autowired
    ApplicationProperties applicationProperties;

    public static Map<String, List<TopicRecord>> downloadableRecordMap = new HashMap<>();

    public static AtomicBoolean isDownloadRequest = new AtomicBoolean(false);
    public static AtomicBoolean isDownloadReady = new AtomicBoolean(false);

    public static String MAXIMUM_LIMIT_OF_RECORD = StringUtils.EMPTY;

    @Autowired
    KafkaConfig kafkaConfig;

    public Map<String, String> topicConfigurations = new HashMap<>();

    /**
     * Startup all Consumers.
     */
    @PostConstruct
    public void startConsumers() {
        runningFlag = new AtomicBoolean(true);
        if (!applicationProperties.getApplicationEnvCode().equals(LOCAL_ENV)) {
            topicRegistrationUps = VcapUtil.getUserProvidedService(TOPIC_REGISTRATION_UPS);
        }
        createAndExecuteConsumers();
    }

    /**
     * Create and execute consumers for each and every topic configuration set.<br>
     * If running locally, predefined topic configurations specified in the constants above will be used.<br>
     * If running on any cloud environment,the topic configurations will be obtained from UPS.
     */
    private void createAndExecuteConsumers() {
        if (applicationProperties.getApplicationEnvCode().equals(LOCAL_ENV)) {
            topicConfigurations.put(KafkaConfig.IT_TEST_TOPIC_LOCAL, KafkaConfig.IT_TEST_TOPIC_LOCAL_CONFIGURATION);
            topicConfigurations.put(KafkaConfig.DEV_BDA_RAW_INTRADAY_NON_FIN_TOPIC_LOCAL, KafkaConfig.DEV_BDA_RAW_INTRADAY_NON_FIN_TOPIC_LOCAL_CONFIGURATION);
            topicConfigurations.put(KafkaConfig.DEV_PDA_RAW_INTRADAY_NON_FIN_TOPIC_LOCAL, KafkaConfig.DEV_PDA_RAW_INTRADAY_NON_FIN_TOPIC_LOCAL_CONFIGURATION);
            topicConfigurations.put(KafkaConfig.DEV_BDA_ACCOUNT_STATUS_CHANGE_LOCAL, KafkaConfig.DEV_BDA_ACCOUNT_STATUS_CHANGE_LOCAL_CONFIGURATION);
            topicConfigurations.put(KafkaConfig.DEV_PDA_ACCOUNT_STATUS_CHANGE_LOCAL, KafkaConfig.DEV_PDA_ACCOUNT_STATUS_CHANGE_LOCAL_CONFIGURATION);
        } else {
            Set<String> keySet = topicRegistrationUps.getCredentials().keySet();
            if (logger.isDebugEnabled()) {
                logger.debug("**** keyset length is: [{}] ****", keySet.size());
            }
            for (String key : keySet) {
                topicConfigurations.put(key, topicRegistrationUps.getCredentials().get(key));
            }
        }

        logger.info("**** topicConfigurations length is: [{}] ****", topicConfigurations.size());
        for (Map.Entry<String, String> entry : topicConfigurations.entrySet()) {
            logger.info("**** registering topic construct ****");
            TopicConfiguration topicConfiguration = null;
            ObjectMapper mapper = new ObjectMapper();
            try {
                topicConfiguration = mapper.readValue(entry.getValue(), TopicConfiguration.class);
                if (logger.isDebugEnabled()) {
                    logger.debug("**** mapper called, yielding: [{}] ****", topicConfiguration.getTopic());
                }

                logger.debug(entry.getKey());
                Properties buildProperties = kafkaConfig.buildConsumerProperties(topicConfiguration);

                KafkaConsumer<String, Record> consumer = new KafkaConsumer<>(buildProperties);
                consumer.subscribe(Arrays.asList(entry.getKey()));
                registerTopics(topicConfiguration.getTopic(), topicConfiguration.getConsumerGroup(), topicConfiguration.getEnvironment(), 0, EMPTY, INITIAL_DATE);
                logger.info("*** registering topic - [{}]", topicConfiguration.getTopic());
                processRecords(topicConfiguration, consumer);
            } catch (Exception e) {
                logger.error("Topic Configuration error occured ", e);
            }
        }
    }

    /**
     * All topics (with initial settings) are registered/set against the local topics cache for future reference.
     * 
     * @param topic topic
     * @param consumerGroup consumerGroup
     * @param environment environment
     * @param offset offset
     * @param payload payload
     * @param latestPayloadDateTime latestPayloadDateTime
     */
    private void registerTopics(String topic, String consumerGroup, String environment, long offset, String payload, String latestPayloadDateTime) {
        TopicDetail topicDetail = constructTopicDetail(topic, consumerGroup, environment, offset, payload, latestPayloadDateTime);
        topics.add(topicDetail);
    }

    /**
     * Processes each each consumer in parallel.<br>
     * 1. fetches the records.<br>
     * 2. gets timestamp + payload for each record.<br>
     * 3. Updates the local topic cache with the latest information.
     * 
     * @param topicConfiguration topicConfiguration
     * @param consumer consumer
     */
    private void processRecords(TopicConfiguration topicConfiguration, KafkaConsumer<String, Record> consumer) {
        if (logger.isDebugEnabled()) {
            logger.debug("polling [{}] [{}] download flag= [{}]", topicConfiguration.getTopic(), runningFlag, isDownloadRequest);
        }

        Thread thread = new Thread(() -> {
            boolean fetchLatestFlag = false;
            Long startTime = 0L;
            Long endTime = 0L;
            Long emptyCount = 0L;
            Long totRecords = 0L;
            String status = READY;

            while (runningFlag.get()) {
                try {
                    fetchRecords(consumer, topicConfiguration, isDownloadRequest);
                    ConsumerRecords<String, Record> records = consumer.poll(100);
                    if (records.count() > 0) {
                        emptyCount = 0L;
                        totRecords = totRecords + records.count();
                        for (ConsumerRecord<String, Record> consumerRecord : records) {
                            if (READY.equals(status)) {
                                startTime = System.currentTimeMillis();
                                status = EXECUTING;
                            }
                            if (logger.isDebugEnabled()) {
                                logger.debug("Processing record at offset: [{}]", consumerRecord.offset());
                            }
                            long timestamp = consumerRecord.timestamp();
                            String payload = EMPTY;
                            payload = consumerRecord.value().toString();
                            if (logger.isDebugEnabled()) {
                                logger.debug("Constructing topic detail for record at offset: [{}]", consumerRecord.offset());
                            }
                            TopicDetail topicDetail =
                                            constructTopicDetail(topicConfiguration.getTopic(), topicConfiguration.getConsumerGroup(), topicConfiguration.getEnvironment(), consumerRecord.offset(),
                                                            payload, sdf.format(timestamp));
                            endTime = System.currentTimeMillis();
                            double diff = endTime.doubleValue() - startTime.doubleValue();
                            Double tps = (totRecords / diff) * 1000;
                            BigDecimal tpsBd = new BigDecimal(tps).setScale(5, RoundingMode.HALF_EVEN);
                            if (logger.isDebugEnabled()) {
                                logger.debug("tps for count [{}], diff [{}], tps [{}], Topic [{}]", totRecords, diff, tpsBd.doubleValue(), topicConfiguration.getTopic());
                            }
                            topicDetail.setTps(tpsBd.doubleValue());
                            updateTopic(topicDetail);
                            if (logger.isDebugEnabled()) {
                                logger.debug("* Kafka Record Topic: [{}], record at offset: [{}], at timestamp: [{}], the record is: [{}]", topicConfiguration.getTopic(), consumerRecord.offset(),
                                                consumerRecord.timestamp(), consumerRecord.value());

                            }
                        }
                    } else {
                        emptyCount++;
                    }
                    // 3000 polls is 5 minutes
                    if (emptyCount > 3000) {
                        status = READY;
                        totRecords = 0L;
                    }
                    if (!fetchLatestFlag) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("Fetching latest record entry for topic [{}]", topicConfiguration.getTopic());
                        }
                        fetchLatestRecord(consumer, topicConfiguration);
                        if (logger.isDebugEnabled()) {
                            logger.debug("Fetching latest record exit");
                        }
                        fetchLatestFlag = !fetchLatestFlag;
                    }
                } catch (Exception e) {
                    logger.error("Problem Processing Records: " + e.getMessage());
                }
            }

            consumer.unsubscribe();
            consumer.close();
            // shutdownConsumers();
        });
        threads.add(thread);
        thread.start();
    }

    /**
     * Checks for fetch-record requests from the client and returns the record value detail if it finds it based on offset.
     * 
     * @param consumer kafka consumer
     * @param topicConfiguration configuration
     * @param isFileDownloadRequest boolean
     */
    private void fetchRecords(KafkaConsumer<String, Record> consumer, TopicConfiguration topicConfiguration, AtomicBoolean isFileDownloadRequest) {
        if (recordRequests.size() > 0) {
            logger.info("fetching records, recordsRequests size: [{}] isFileDownloadRequest=[{}]", recordRequests.size(), isFileDownloadRequest);
        }

        if (isFileDownloadRequest.get()) {
            traverseFrowardAndPopulateSizeBasedRecords(consumer, topicConfiguration);
        } else {
            for (int i = recordRequests.size() - 1; i > -1; i--) {
                RecordRequest recordRequest = recordRequests.get(i);

                if (recordRequest.getTopicName().equals(topicConfiguration.getTopic())) {

                    ObjectMapper mapper = new ObjectMapper();
                    TopicDetail topicDetail = new TopicDetail();
                    topicDetail.setOffset(recordRequest.getOffset());
                    topicDetail.setLatestPayloadDateTime(recordRequest.getTimestamp());
                    Set<TopicPartition> topicPartitions = consumer.assignment();
                    String record = "";

                    try {
                        Map<TopicPartition, Long> timestampMap = new HashMap<>();

                        String timestamp = recordRequest.getTimestamp();
                        Long epochTimestamp = null;
                        if (StringUtils.isNotBlank(timestamp)) {
                            LocalDateTime dateTime = LocalDateTime.parse(timestamp, DateTimeFormatter.ofPattern(DATE_FORMAT));
                            ZoneId zoneId = ZoneId.systemDefault();
                            epochTimestamp = dateTime.atZone(zoneId).toEpochSecond();
                        }

                        for (TopicPartition topicPartition : topicPartitions) {
                            if (null != epochTimestamp) {
                                timestampMap.put(topicPartition, epochTimestamp);
                            } else {
                                if (recordRequest.getOffset() >= 0) {
                                    consumer.seek(topicPartition, recordRequest.getOffset());
                                } else {
                                    consumer.seek(topicPartition, 0);
                                }
                            }
                        }

                        if (null != epochTimestamp && null != timestamp) {
                            Map<TopicPartition, OffsetAndTimestamp> offsetForTimeMap = consumer.offsetsForTimes(timestampMap);
                            Set<Entry<TopicPartition, OffsetAndTimestamp>> entrySet = offsetForTimeMap.entrySet();
                            for (Entry<TopicPartition, OffsetAndTimestamp> entry : entrySet) {
                                if (logger.isDebugEnabled()) {
                                    logger.debug("Seek to offset [{}] based on timestamp [{}] on the partition [{}]", entry.getValue().offset(), timestamp, entry.getKey().partition());
                                }
                                consumer.seek(entry.getKey(), entry.getValue().offset());
                            }
                        }

                        ConsumerRecords<String, Record> customerRecords = consumer.poll(750);
                        if (customerRecords.iterator().hasNext()) {
                            ConsumerRecord<String, Record> consumerRecord = customerRecords.iterator().next();
                            if (logger.isDebugEnabled()) {
                                logger.debug("**** record fetched for topic: [{}] is: [{}] at offset: [{}] inserted at time: [{}] ****", topicConfiguration.getTopic(), record, consumerRecord.offset(),
                                                consumerRecord.timestamp());

                            }
                            topicDetail.setOffset(consumerRecord.offset());
                            topicDetail.setLatestPayloadDateTime(sdf.format(consumerRecord.timestamp()));
                            topicDetail.setPayload(consumerRecord.value().toString());
                            record = mapper.writeValueAsString(topicDetail);
                        } else {
                            topicDetail.setPayload(OUT_OF_RANGE_MSG);
                            record = mapper.writeValueAsString(topicDetail);
                        }
                    } catch (DateTimeParseException e) {
                        try {
                            logger.warn("Date parsing exception for timestamp");
                            topicDetail.setPayload(DATE_FORMAT_MSG);
                            record = mapper.writeValueAsString(topicDetail);
                        } catch (JsonProcessingException e1) {
                            logger.warn("json parse exception.");
                        }
                    } catch (Exception e) {
                        logger.info(e.getMessage());
                    }
                    consumer.seekToEnd(topicPartitions);

                    recordRequest.getTemplate().convertAndSend("/topic/record/" + recordRequest.getUuid(), record);
                    recordRequests.remove(i);
                }
            }
        }
    }



    private void fetchLatestRecord(KafkaConsumer<String, Record> consumer, TopicConfiguration topicConfiguration) {
        Set<TopicPartition> topicPartitions = consumer.assignment();
        consumer.seekToEnd(topicPartitions);
        for (TopicPartition topicPartition : topicPartitions) {
            long lastOffset = consumer.position(topicPartition) - 1;
            if (lastOffset >= 0)
                consumer.seek(topicPartition, lastOffset);
        }

        ConsumerRecords<String, Record> customerRecords = consumer.poll(750);
        String record = "";
        ConsumerRecord<String, Record> consumerRecord = null;
        try {
            if (customerRecords.iterator().hasNext()) {
                consumerRecord = customerRecords.iterator().next();
                record = consumerRecord.value().toString();
                if (logger.isDebugEnabled()) {
                    logger.debug("**** record fetched for topic: [{}] is: [{}] at offset: [{}] inserted at time: [{}] ****", topicConfiguration.getTopic(), record, consumerRecord.offset(),
                                    consumerRecord.timestamp());

                }
            } else {
                record = OUT_OF_RANGE_MSG;
            }
        } catch (Exception e) {
            logger.info(e.getMessage());
        }
        TopicDetail topicDetail = null;
        if (consumerRecord != null) {
            topicDetail = constructTopicDetail(topicConfiguration.getTopic(), topicConfiguration.getConsumerGroup(), topicConfiguration.getEnvironment(), consumerRecord.offset(),
                            record, sdf.format(consumerRecord.timestamp()));
            updateTopic(topicDetail);
        }
        consumer.seekToEnd(topicPartitions);
    }


    /**
     * Updates the specified topic (contained within the topic detail) in the local topic cache with the latest response detail.
     * 
     * @param topicDetail topicDetail
     */
    private synchronized void updateTopic(TopicDetail topicDetail) {
        for (TopicDetail td : topics) {
            if (td.getName().equals(topicDetail.getName())) {
                td.setLatestPayloadDateTime(topicDetail.getLatestPayloadDateTime());
                td.setOffset(topicDetail.getOffset());
                td.setPayload(topicDetail.getPayload());
                td.setTps(topicDetail.getTps());
            }
        }
    }

    /**
     * Constructs topic detail type with details passed in.
     * 
     * @param topic topic
     * @param consumerGroup consumerGroup
     * @param environment environment
     * @param offset offset
     * @param payload payload
     * @param latestPayloadDateTime latestPayloadDateTime
     * @return topicDetail
     */
    private TopicDetail constructTopicDetail(String topic, String consumerGroup, String environment, long offset, String payload,
                    String latestPayloadDateTime) {
        TopicDetail topicDetail = new TopicDetail();
        topicDetail.setName(topic);
        topicDetail.setConsumerGroup(consumerGroup);
        topicDetail.setEnvironment(environment);
        topicDetail.setOffset(offset);
        topicDetail.setLatestPayloadDateTime(latestPayloadDateTime);
        topicDetail.setPayload(payload);
        return topicDetail;
    }

    @PreDestroy
    public void shutdownConsumers() {
        logger.info("*** consumers shutting down");
        runningFlag = new AtomicBoolean(false);
        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                logger.warn("Error encountered while joining ", e);
                thread.interrupt();
            }
        });
        threads.clear();
    }



    private void traverseFrowardAndPopulateSizeBasedRecords(KafkaConsumer<String, Record> consumer, TopicConfiguration topicConfiguration) {
        KafkaConsumer<String, Record> topicConsumer = consumer;
        int downloadSize = calculateRecordsToBeDownloaded();
        List<TopicRecord> recordList = new ArrayList<>();
        for (Entry<String, RecordRequest> entry : topicRequestMap.entrySet()) {
            RecordRequest downloadRecordRequest = entry.getValue();
            if (downloadRecordRequest.getTopicName().equals(topicConfiguration.getTopic())) {
                // Get assigned partitions
                Set<TopicPartition> partitions = topicConsumer.assignment();
                int partitionSize = partitions.size();
                logger.info("total partitions are [{}]", partitionSize);
                logger.info("Number of records requested for download is [{}]", downloadSize);
                final Map<TopicPartition, Long> beginningOffsets = topicConsumer.beginningOffsets(partitions);
                final Map<TopicPartition, Long> endOffsets = topicConsumer.endOffsets(partitions);
                long recordsPerTopics = 0L;
                for (TopicPartition partition : partitions) {
                    long lastOffset = topicConsumer.position(partition);
                    long position = lastOffset - downloadSize;
                    // seek back to endOffsets-100 record
                    position = (position > 0 ? position : 0);
                    long startOffset = beginningOffsets.get(partition).longValue();
                    // check if startOffset is bigger than the calculated one.
                    position = (startOffset > position ? startOffset : position);

                    long endOffset = endOffsets.get(partition).longValue();
                    recordsPerTopics = recordsPerTopics + (endOffset - position);
                    logger.info("recordsPerTopic [{}]", recordsPerTopics);
                    logger.info("seek back [{}] at position[{}]", partition, position);
                    topicConsumer.seek(partition, position);
                }
                int limit = (partitionSize * downloadSize);
                long totalTopicRecords = getTotalCountSinceBegining(topicConsumer);
                totalTopicRecords = (recordsPerTopics < totalTopicRecords ? recordsPerTopics : totalTopicRecords);
                logger.info("limit[{}],totalTopicRecords[{}]", limit, totalTopicRecords);
                boolean keepOnReading = true;
                while (keepOnReading) {
                    ConsumerRecords<String, Record> customerRecords = topicConsumer.poll(750);
                    for (ConsumerRecord<String, Record> record : customerRecords) {
                        TopicRecord topicRecord = new TopicRecord(record.topic(), record.partition(), record.offset(),
                                        record.key(), record.value().toString(), sdf.format(record.timestamp()), populateHeaders(record.headers()));
                        recordList.add(topicRecord);
                        // logger.info("record#[{}] ,partition[{}], offset[{}]", recordList.size(), record.partition(), record.offset());
                        if (recordList.size() == totalTopicRecords || recordList.size() >= limit) {
                            keepOnReading = false;
                            break;
                        }
                    }
                }
                Processor.downloadableRecordMap.put(entry.getKey(), recordList);
                topicConsumer.seekToEnd(partitions);
                topicRequestMap.remove(entry.getKey());
                Processor.isDownloadRequest.set(false);
                Processor.isDownloadReady.set(true);
            }
        }

    }

    private Long getTotalCountSinceBegining(KafkaConsumer<String, Record> downloadConsumer) {
        Set<TopicPartition> partitions;
        while ((partitions = downloadConsumer.assignment()).isEmpty()) {
            downloadConsumer.poll(100);
        }
        final Map<TopicPartition, Long> beginningOffsets = downloadConsumer.beginningOffsets(partitions);
        logger.info("beginningOffsets[{}]", beginningOffsets);
        final Map<TopicPartition, Long> endOffsets = downloadConsumer.endOffsets(partitions);
        logger.info("endOffsets[{}]", endOffsets);
        Long totalCountSinceBegining = beginningOffsets.entrySet().stream().mapToLong(e -> {
            TopicPartition tp = e.getKey();
            Long beginningOffset = e.getValue();
            Long endOffset = endOffsets.get(tp);
            return endOffset - beginningOffset;
        }).sum();
        logger.info("TotalCountSinceBegining [{}]", totalCountSinceBegining);
        return totalCountSinceBegining;
    }

    private int calculateRecordsToBeDownloaded() {
        switch (MAXIMUM_LIMIT_OF_RECORD) {
            case "50":
                return 50;// seek back to last 50 offset
            case "100":
                return 100;// seek back to last 100 offset
            case "5000":
                return 5000;// seek back to last 5000 offset
            case "10000":
                return 10000;// seek back to last 10000 offset
            case "all":
                return Integer.MAX_VALUE;// seek back to beginning offset
            default:
                return 0;// seek back to beginning offset
        }
    }

    private Map<String, String> populateHeaders(Headers headers) {
        if (null != headers && headers.toArray().length > 0) {
            return generateHeadersMap(headers);
        }
        return null;
    }

    private Map<String, String> generateHeadersMap(Headers source) {
        Map<String, String> types = new ConcurrentHashMap<>();
        Iterator<Header> iterator = source.iterator();
        while (iterator.hasNext()) {
            Header next = iterator.next();
            // avoid NPE
            if (next.value() != null) {
                types.put(next.key(), new String(next.value(), StandardCharsets.UTF_8));
            } else {
                types.put((null != next.key() ? next.key() : StringUtils.EMPTY), StringUtils.EMPTY);
            }

        }
        return types;
    }

    @SuppressWarnings("unused")
    private void traverseBackwardsAndPopulateRecords(KafkaConsumer<String, Record> consumer, TopicConfiguration topicConfiguration) {
        KafkaConsumer<String, Record> downloadConsumer = consumer;
        List<TopicRecord> recordList = new ArrayList<TopicRecord>();
        int numberOfRecordsRequestedForDownload = calculateRecordsToBeDownloaded();
        for (Entry<String, RecordRequest> entry : topicRequestMap.entrySet()) {
            RecordRequest topicRecordRequest = entry.getValue();
            if (topicRecordRequest.getTopicName().equals(topicConfiguration.getTopic())) {
                // logger.info(entry.getKey() + ":" + entry.getValue());
                Set<TopicPartition> downloadTopicPartitions = downloadConsumer.assignment();
                boolean isOffsetPresentOrLimitReached = true;
                int previousOffsetCounter = 1;
                final Map<TopicPartition, Long> endOffsets = downloadConsumer.endOffsets(downloadTopicPartitions);
                if (logger.isDebugEnabled()) {
                    logger.debug("endOffsets=[{}]", endOffsets);
                }
                TopicPartition leadPartition = endOffsets.entrySet().stream().max(Comparator.comparing(Map.Entry::getValue)).get()
                                .getKey();
                do {
                    if (logger.isDebugEnabled()) {
                        logger.debug("leadPartition=[{}], offset=[{}]", leadPartition, endOffsets.get(leadPartition));
                    }
                    downloadConsumer.seek(leadPartition, endOffsets.get(leadPartition) - previousOffsetCounter);
                    ConsumerRecords<String, Record> customerRecords = downloadConsumer.poll(750);
                    if (logger.isDebugEnabled()) {
                        logger.debug("counts. [{}]", customerRecords.count());
                    }
                    try {
                        if (customerRecords.iterator().hasNext()) {
                            ConsumerRecord<String, Record> record = customerRecords.iterator().next();
                            TopicRecord topicRecord = new TopicRecord(record.topic(), record.partition(),
                                            record.offset(), null, record.value().toString(), sdf.format(record.timestamp()),
                                            populateHeaders(record.headers()));
                            recordList.add(topicRecord);
                            if (logger.isDebugEnabled()) {
                                logger.debug("Reading topic[{}] at partition[{}] at offset[{}]", topicRecord.getTopicName(), topicRecord.getPartition(), topicRecord.getOffset());
                            }
                        } else {
                            logger.info("No more offset exists...");
                            isOffsetPresentOrLimitReached = false;
                        }
                    } catch (Exception e) {
                        logger.info(e.getMessage());
                    }
                    if (previousOffsetCounter >= numberOfRecordsRequestedForDownload) {
                        isOffsetPresentOrLimitReached = false;
                    }
                    previousOffsetCounter++;
                } while (isOffsetPresentOrLimitReached);
                Processor.downloadableRecordMap.put(entry.getKey(), recordList);
                downloadConsumer.seekToEnd(downloadTopicPartitions);
                topicRequestMap.remove(entry.getKey());
                Processor.isDownloadRequest.set(false);
                Processor.isDownloadReady.set(true);
            }
        }
    }


}
