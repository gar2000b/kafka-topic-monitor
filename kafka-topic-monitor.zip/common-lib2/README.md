# common-lib2
Common Library of reusable capabilities for all Springboot 2 applications.

It includes the following:

* vcap - support for accessign vcap servies in PCF
* email - support for an integrated email client
* environment - standard application environment definitions
* exceptions - common exception throwable by REST services 
* health - health check client for HTML and Actuator endpoints
* ims - IMS Utility functions
* interceptor - Spring interceptor for logging request and response activity
* json - json support functions
* oauth2 - oauth2 token support
* queue - polling message queue implementation
* rest - REST support functions
* sftp - SFTP session and client framework
* util - common reusable utilities

Note - for SFTP support the following dependency is scoped as provided so must be included in the application POM.

		<dependency>
			<groupId>com.jcraft</groupId>
			<artifactId>jsch</artifactId>
			<version>0.1.55</version>
			<scope>provided</scope>
		</dependency>

