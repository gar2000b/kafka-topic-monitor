package com.rbc.deposits;

/**
 * Sample test Pojo.
 * 
 * @author 316746874
 *
 */
public class Pojo {
    private String name;
    private int age;
    private String gender;

    /**
     * Geet the name.
     * 
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the name.
     * 
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Get the age.
     * 
     * @return the age
     */
    public int getAge() {
        return age;
    }

    /**
     * Set the age.
     * 
     * @param age the age to set
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * Get the gender.
     * 
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * Set the gender.
     * 
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Pojo [name=");
        builder.append(name);
        builder.append(", age=");
        builder.append(age);
        builder.append(", gender=");
        builder.append(gender);
        builder.append("]");
        return builder.toString();
    }

}
