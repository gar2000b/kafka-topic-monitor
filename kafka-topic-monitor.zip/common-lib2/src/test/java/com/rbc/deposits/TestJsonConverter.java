package com.rbc.deposits;

import java.util.Map;

import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rbc.deposits.json.JsonMessageConverter;

public class TestJsonConverter {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private JsonMessageConverter jsonMessageConverter;

    @Ignore
    @Test
    public void test() {
        jsonMessageConverter = new JsonMessageConverter().setPretty(true);

        Pojo pojo = new Pojo();
        pojo.setName("Tomo");
        pojo.setAge(29);
        pojo.setGender("male");

        try {
            logger.info("Pojo in\n{}", pojo.toString());
            String json = jsonMessageConverter.marshal(pojo);

            pojo = jsonMessageConverter.unmarshal(json, Pojo.class);
            logger.info("Pojo out\n{}", pojo.toString());

            pojo.setGender("alien");
            json = jsonMessageConverter.marshal(pojo);
            Map<String, Object> map = jsonMessageConverter.toMap(json);
            logger.info("Map out\n{}", map.toString());

        } catch (Exception e) {
            logger.info("Oops!", e);
        }
    }

    int numThreads = 100;
    int numIterations = 100;

    // --------------------------------------------------
    // enable the following for a threaded test
    // --------------------------------------------------
    // @Test
    public void threadTest() {
        jsonMessageConverter = new JsonMessageConverter().setPretty(true);

        int numThreads = 100;
        Thread[] threads = new Thread[numThreads];

        try {
            for (int i = 0; i < numThreads; i++) {
                Worker worker = new Worker("worker-" + i);
                threads[i] = new Thread(worker);
            }

            for (int i = 0; i < numThreads; i++) {
                threads[i].start();
            }

            for (int i = 0; i < numThreads; i++) {
                threads[i].join();
            }
        } catch (Exception e) {
            logger.info("Oops!", e);
        }
    }

    class Worker implements Runnable {
        String name;

        public Worker(String name) {
            this.name = name;
        }

        @Override
        public void run() {
            for (int i = 0; i < numIterations; i++) {
                try {
                    Pojo pojo = new Pojo();
                    pojo.setName(name);
                    pojo.setAge(29);
                    pojo.setGender("male");

                    logger.info("Pojo in\n{}", pojo.toString());
                    String json = jsonMessageConverter.marshal(pojo);

                    pojo = jsonMessageConverter.unmarshal(json, Pojo.class);
                    logger.info("Pojo out\n{}", pojo.toString());

                    pojo.setGender("alien");
                    json = jsonMessageConverter.marshal(pojo);
                    Map<String, Object> map = jsonMessageConverter.toMap(json);
                    logger.info("Map out\n{}", map.toString());

                } catch (Exception e) {
                    logger.info("Oops!", e);
                }
            }
        }
    }

}
