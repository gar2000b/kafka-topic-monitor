package com.rbc.deposits;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Test Application Properties.
 * 
 * @author 316746874
 *
 */
@Configuration
public class TestApplicationProperties {

    @Value("${authentication.username}")
    private String authenticationUsername;

    @Value("${authentication.password}")
    private String authenticationPassword;

    /**
     * Get the authenticationUsername.
     * 
     * @return the authenticationUsername
     */
    public String getAuthenticationUsername() {
        return authenticationUsername;
    }

    /**
     * Get the authenticationPassword.
     * 
     * @return the authenticationPassword
     */
    public String getAuthenticationPassword() {
        return authenticationPassword;
    }

}
