package com.rbc.deposits.rest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.junit4.SpringRunner;
import com.rbc.deposits.rest.client.ClientResponse;
import com.rbc.deposits.rest.client.handlers.GetHandler;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {RestClientTimeoutTest.class, SimpleService.class}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration(exclude = SecurityAutoConfiguration.class)
public class RestClientTimeoutTest {
    private static final Logger logger = LoggerFactory.getLogger(RestClientTimeoutTest.class);

    private static final int READ_TIMEOUT_SECONDS = 5;
    private static final int SERVICE_DELAY_SECONDS = 10;

    public static final String SERVICE_HOST = "http://localhost:";

    @LocalServerPort
    private int port;

    @Test
    public void testApi() {
        pause(1);

        String url = SERVICE_HOST + port + SimpleService.SERVICE_URI;
        logger.info("service url [{}]", url);
        try {
            GetHandler.setReadTimeoutSeconds(READ_TIMEOUT_SECONDS);
            SimpleService.setPauseSeconds(SERVICE_DELAY_SECONDS);

            logger.info("sending request with read timeout [{}] seconds and service delay [{}] seconds", READ_TIMEOUT_SECONDS, SERVICE_DELAY_SECONDS);

            GetHandler<String> getHandler = new GetHandler<>();

            ClientResponse<String> response = getHandler.exec(url, String.class);
            logger.info(response.toString());
        } catch (Exception e) {
            logger.error("client error {}", ExceptionUtils.getRootCauseMessage(e));
            // logger.error("client error", e);
        }

        pause(1);
    }

    private void pause(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            ;
        }
    }
}
