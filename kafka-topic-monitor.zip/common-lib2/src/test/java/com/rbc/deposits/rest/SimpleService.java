package com.rbc.deposits.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SimpleService {
    public static final String SERVICE_URI = "/test-service";

    public static int pauseSeconds;

    public static void setPauseSeconds(int pauseSeconds) {
        SimpleService.pauseSeconds = pauseSeconds;
    }

    @RequestMapping(value = SERVICE_URI, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String get(HttpServletRequest request, HttpServletResponse response) {
        // pause to test the timeout
        pause(pauseSeconds);

        response.setStatus(HttpStatus.SC_OK);
        return "test-response";
    }

    private void pause(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            ;
        }
    }
}
