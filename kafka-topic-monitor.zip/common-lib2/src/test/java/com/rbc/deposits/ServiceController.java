package com.rbc.deposits;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String RESOURCE = "/resource";
    private static final String RESOURCE_ID = "/resource/{identity}";

    @RequestMapping(value = RESOURCE, method = RequestMethod.POST)
    public void doPost(
                    @RequestBody Pojo pojo,
                    HttpServletRequest request,
                    HttpServletResponse response) throws Exception {

        logger.info("POST called with pojo {}", pojo.toString());
        response.setHeader(HttpHeaders.LOCATION, "/resource/1");
        response.setStatus(HttpStatus.CREATED.value());
    }

    @RequestMapping(value = RESOURCE_ID, method = RequestMethod.GET)
    public Pojo doGet(
                    @PathVariable("identity") int identity,
                    HttpServletRequest request,
                    HttpServletResponse response) throws Exception {
        logger.info("GET called with identity [{}]", identity);

        response.setStatus(HttpStatus.OK.value());

        Pojo pojo = new Pojo();
        pojo.setName("Tom");
        pojo.setAge(29);

        logger.info("returning pojo {}", pojo.toString());
        return pojo;
    }

    @RequestMapping(value = RESOURCE_ID, method = RequestMethod.PUT)
    public void doPut(
                    @RequestBody Pojo pojo,
                    @PathVariable("identity") int identity,
                    HttpServletRequest request,
                    HttpServletResponse response) throws Exception {
        logger.info("PUT called with identity [{}] pojo {}", identity, pojo.toString());

        response.setStatus(HttpStatus.NO_CONTENT.value());
    }

    @RequestMapping(value = RESOURCE_ID, method = RequestMethod.PATCH)
    public void doPatch(
                    @RequestBody Pojo pojo,
                    @PathVariable("identity") int identity,
                    HttpServletRequest request,
                    HttpServletResponse response) throws Exception {
        logger.info("PATCH called with identity [{}] pojo {}", identity, pojo.toString());

        response.setStatus(HttpStatus.NO_CONTENT.value());
    }

    @RequestMapping(value = RESOURCE_ID, method = RequestMethod.DELETE)
    public void doDelete(
                    @PathVariable("identity") int identity,
                    HttpServletRequest request,
                    HttpServletResponse response) throws Exception {
        logger.info("DELETE called with identity [{}]", identity);

        response.setStatus(HttpStatus.NO_CONTENT.value());
    }
}
