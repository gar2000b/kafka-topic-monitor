package com.rbc.deposits.rest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.rbc.deposits.rest.client.ClientResponse;
import com.rbc.deposits.rest.client.fibrs.FibrsRestClient;

/**
 * FibrsRestClient tests.
 * 
 * @author 316746874
 *
 */
public class TestFibrsRestClient {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    // ------------------------------
    // target host and URL
    // ------------------------------
    private static String FIBRS_HOST = "https://fibrs-lab.saifg.rbc.com";
    private static String REQUEST_URI = "/api/UNIT(unt_id={transit})?$select=proc_ctr";
    private static String REQUEST_URL = FIBRS_HOST + REQUEST_URI;
    // private static String REQUEST_URL = "https://fibrs-lab.saifg.rbc.com/api/UNIT(unt_id={transit})?$select=proc_ctr";

    // ------------------------------
    // NTLM credentials
    // ------------------------------
    private String ntlmUsername = "SZGV0SRVFIBRS";
    private String ntlmPassword = "Password#422257";
    @SuppressWarnings("unused")
    private String workstation = null;
    private String domain = "SAIMAPLE.SAIFG.RBC.COM";

    @Ignore
    @Test
    public void test() {
        try {
            testFibrsRestClientLocal();
            testFibrsRestClientNonLocal();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Test the FibrsRestClient with a bypass enabled and preemptive authentication enabled.
     * 
     * @throws Exception on any errors
     */
    private void testFibrsRestClientLocal() throws Exception {
        // ------------------------------------------------------------
        // bypass is only supported for local testing - and is only
        // required when client certificates are not installed locally
        // ------------------------------------------------------------
        FibrsRestClient fibrsRestClient = new FibrsRestClient(FIBRS_HOST, ntlmUsername, ntlmPassword, domain)
                        // .setHeader(HttpHeaders.ACCEPT, MediaType.TEXT_PLAIN_VALUE)
                        .preemptive(true)
                        .buildNoSslValidation("l");

        ClientResponse<String> response = fibrsRestClient.get(REQUEST_URL, String.class, "59");
        logger.info("response: {}", response.toString());
        logger.info("----------------------------------------------------------------------------------------------------");

        response = fibrsRestClient.get(REQUEST_URL, String.class, "60");
        logger.info("response: {}", response.toString());
        logger.info("----------------------------------------------------------------------------------------------------");

        fibrsRestClient.preemptive(false);

        response = fibrsRestClient.get(REQUEST_URL, String.class, "61");
        logger.info("response: {}", response.toString());
        logger.info("----------------------------------------------------------------------------------------------------");
    }

    /**
     * Test the FibrsRestClient and fail in a non-local environment when no client certificates installed.
     * 
     * @throws Exception on any errors
     */
    private void testFibrsRestClientNonLocal() throws Exception {
        FibrsRestClient fibrsRestClient = new FibrsRestClient(FIBRS_HOST, ntlmUsername, ntlmPassword, domain)
                        .build();
        logger.info("EXPECTING CERTIFICATE FAILURE...");
        try {
            ClientResponse<String> response = fibrsRestClient.get(REQUEST_URL, String.class, "59");
            logger.info("response: {}", response.toString());
        } catch (Exception e) {
            logger.info("failure: {}", ExceptionUtils.getRootCauseMessage(e));
        }

    }

}
