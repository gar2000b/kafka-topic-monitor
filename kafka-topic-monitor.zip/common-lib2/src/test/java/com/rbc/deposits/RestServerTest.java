package com.rbc.deposits;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.rbc.deposits.rest.client.ClientException;
import com.rbc.deposits.rest.client.ClientResponse;
import com.rbc.deposits.rest.client.handlers.DeleteHandler;
import com.rbc.deposits.rest.client.handlers.GetHandler;
import com.rbc.deposits.rest.client.handlers.PatchHandler;
import com.rbc.deposits.rest.client.handlers.PostHandler;
import com.rbc.deposits.rest.client.handlers.PutHandler;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT, properties = "application.properties", classes = {
                TestApplicationProperties.class,
                ServiceController.class,
                WebSecurityConfig.class,
})
@ContextConfiguration(initializers = RestServerTest.class)
@EnableAutoConfiguration
public class RestServerTest implements ApplicationContextInitializer<ConfigurableApplicationContext> {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final String resource = "http://localhost:8888/resource";
    private final String resourceId = "http://localhost:8888/resource/{identity}";

    private String username;
    private String password;

    @Autowired
    private TestApplicationProperties applicationProperties;

    @Override
    public void initialize(ConfigurableApplicationContext applicationContext) {
        logger.info("initialize");
    }

    @Ignore
    @Before
    public void setup() throws Exception {
        logger.info("setup");
        username = applicationProperties.getAuthenticationUsername();
        password = applicationProperties.getAuthenticationPassword();
    }

    @Ignore
    @After
    public void cleanup() {
        logger.info("cleanup");
    }

    @Ignore
    @Test
    public void testAll() {
        logger.info("testAll");

        // ----------------------------------------
        // positive tests
        // ----------------------------------------
        this.postTest();
        this.getTest();
        this.putTest();
        this.patchTest();
        this.deleteTest();

        // ----------------------------------------
        // authentication failure tests
        // ----------------------------------------
        username += "x";

        this.postTest();
        this.getTest();
        this.putTest();
        this.patchTest();
        this.deleteTest();
    }

    private void postTest() {
        logger.info("postTest");

        Pojo pojo = new Pojo();
        pojo.setName("Tom");
        pojo.setAge(29);

        PostHandler<Pojo> postHander = new PostHandler<>(null);
        postHander.setBasicAuthentication(username, password);

        try {
            ClientResponse<Void> clientResponse = postHander.exec(resource, pojo);
            logger.info("clientResponse {}", clientResponse);
        } catch (ClientException e) {
            e.printStackTrace();
        }
    }

    private void getTest() {
        logger.info("getTest");

        GetHandler<Pojo> getHander = new GetHandler<Pojo>(null);
        getHander.setBasicAuthentication(username, password);

        try {
            ClientResponse<Pojo> clientResponse = getHander.exec(resourceId, Pojo.class, 1);
            logger.info("clientResponse {}", clientResponse);
        } catch (ClientException e) {
            e.printStackTrace();
        }
    }

    private void putTest() {
        logger.info("putTest");

        Pojo pojo = new Pojo();
        pojo.setName("Tom");
        pojo.setAge(29);

        PutHandler<Pojo> putHander = new PutHandler<>(null);
        putHander.setBasicAuthentication(username, password);

        try {
            ClientResponse<Void> clientResponse = putHander.exec(resourceId, pojo, 1);
            logger.info("clientResponse {}", clientResponse);
        } catch (ClientException e) {
            e.printStackTrace();
        }
    }

    private void patchTest() {
        logger.info("patchTest");

        Pojo pojo = new Pojo();
        pojo.setName("Tom");
        pojo.setAge(29);

        PatchHandler<Pojo> patchHander = new PatchHandler<>(null);
        patchHander.setBasicAuthentication(username, password);

        try {
            ClientResponse<Void> clientResponse = patchHander.exec(resourceId, pojo, 1);
            logger.info("clientResponse {}", clientResponse);
        } catch (ClientException e) {
            e.printStackTrace();
        }
    }

    private void deleteTest() {
        logger.info("deleteTest");

        DeleteHandler deleteHander = new DeleteHandler(null);
        deleteHander.setBasicAuthentication(username, password);

        try {
            ClientResponse<Void> clientResponse = deleteHander.exec(resourceId, 1);
            logger.info("clientResponse {}", clientResponse);
        } catch (ClientException e) {
            e.printStackTrace();
        }
    }
}
