package com.rbc.deposits;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;

/**
 * Security Configuration.
 * 
 * @author thomas
 *
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Order(SecurityProperties.BASIC_AUTH_ORDER)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    private final Logger logger = LoggerFactory.getLogger(WebSecurityConfig.class);

    @Autowired
    private TestApplicationProperties applicationProperties;

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        this.authenticationUserDetails(auth);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        this.authorizationBasic(http);
    }

    /**
     * Authenticate via Custom userDetailsService.
     * 
     * @param auth the AuthenticationManagerBuilder
     * @throws Exception on any errors
     */
    private void authenticationUserDetails(AuthenticationManagerBuilder auth) throws Exception {
        String username = applicationProperties.getAuthenticationUsername();
        String password = applicationProperties.getAuthenticationPassword();

        auth.inMemoryAuthentication()
                        .withUser(username).password(password)
                        .authorities("ROLE_USER");
    }

    /**
     * Use HTTP Basic Request Authorization.
     * 
     * @param http the HttpSecurity
     * @throws Exception on any errors
     */
    private void authorizationBasic(HttpSecurity http) throws Exception {
        String realm = null;
        logger.info("authentication realm [{}]", realm);

        http.httpBasic()
                        .and().csrf().disable()
                        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                        .and().authorizeRequests()
                        // secure controller end-points
                        .antMatchers("/resource").authenticated()
                        .antMatchers("/resource/**").authenticated();
    }
}
