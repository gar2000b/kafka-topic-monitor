package com.rbc.deposits.sftp;

import java.util.Vector;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.Session;

@Ignore
public class TestSftpConnectorMulti {
    private Logger logger = LoggerFactory.getLogger(TestSftpConnectorMulti.class);

    String sftpHostname = "sshgcc.fg.rbc.com";
    String sftpLocationShare = "/appshare/ck00/eod_file";
    int sftpPort = 22;

    String username = "PZGVSRVA";
    String password = "Y1nMmced";

    int numClients = 5;
    int iterations = 5;
    AtomicInteger attempts = new AtomicInteger();
    AtomicInteger passed = new AtomicInteger();
    AtomicInteger failed = new AtomicInteger();

    Session session;

    @Test
    public void testSftpConnectorMulti() {
        try {
            test();
        } catch (Exception e) {
            logger.error("Oops - {}", ExceptionUtils.getRootCauseMessage(e));
        }
    }

    void test() throws JSchException {
        Client[] clients = new Client[numClients];
        Thread[] threads = new Thread[numClients];

        for (int i = 0; i < numClients; i++) {
            clients[i] = new Client(i);
            threads[i] = new Thread(clients[i]);
        }
        for (int i = 0; i < numClients; i++) {
            threads[i].start();
        }
        for (int i = 0; i < numClients; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        logger.info("attempts [{}] passed [{}] failed [{}]", attempts, passed.get(), failed.get());
    }

    private class Client implements Runnable {
        private int clientId;
        private SftpConnector sftpConnector;
        private Session session;

        public Client(int clientId) {
            this.clientId = clientId;
            sftpConnector = new SftpConnector("TEST", sftpHostname, sftpPort, username, password);
        }

        @Override
        public void run() {
            logger.info("client [{}] starting", clientId);

            try {
                session = sftpConnector.openSession();
            } catch (JSchException e) {
                logger.error("Oops...", e);
                return;
            }

            int pass = 0;
            int fail = 0;
            for (int i = 0; i < iterations; i++) {
                try {
                    ChannelSftp channelSftp = sftpConnector.openChannel(session);
                    @SuppressWarnings("unchecked")
                    Vector<ChannelSftp.LsEntry> lsEntries = channelSftp.ls(sftpLocationShare);
                    for (LsEntry lsEntry : lsEntries) {
                        logger.info("client [{}] file [{}]", clientId, lsEntry.getFilename());
                    }

                    pause(500);
                    sftpConnector.closeChannel(channelSftp);;
                    logger.info("client [{}] done!", clientId);
                    pass++;
                } catch (Exception e) {
                    logger.error("Oops...", e);
                    fail++;
                }
                attempts.incrementAndGet();
            }
            logger.info("client [{}] attempts [{}] passed [{}] failed [{}]", clientId, iterations, pass, fail);
            passed.addAndGet(pass);
            failed.addAndGet(fail);
        }
    }

    void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            //
        }
    }

}
