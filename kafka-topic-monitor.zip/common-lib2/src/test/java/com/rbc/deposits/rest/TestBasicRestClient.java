package com.rbc.deposits.rest;

import org.apache.http.HttpHeaders;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;

import com.rbc.deposits.rest.client.ClientResponse;
import com.rbc.deposits.rest.client.handlers.GetHandler;

/**
 * FibrsRestClient tests.
 * 
 * @author 316746874
 *
 */
public class TestBasicRestClient {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private static String CENTER_LOOKUP_URL = "https://center-lookup-service-dev.apps.pcf.devfg.rbc.com/v1/transit/{transitNumber}";
    private String basicUsername = "thegrid";
    private String basicPassword = "gr33t1ngsPr0gr4ms";

    @Ignore
    @Test
    public void test() {
        try {
            testBasicRestClientLocal();
            // testBasicRestClientNonLocal();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Test the Basic handler with a bypass enabled and preemptive authentication enabled.
     * 
     * @throws Exception on any errors
     */
    private void testBasicRestClientLocal() throws Exception {
        logger.info("Basic Authentication test");
        logger.info("url {}", CENTER_LOOKUP_URL);
        GetHandler<String> getHandler = new GetHandler<String>(CENTER_LOOKUP_URL);
        getHandler.setBasicAuthentication(basicUsername, basicPassword);
        getHandler.addSslValidationBypass();
        getHandler.setHeader(HttpHeaders.ACCEPT, MediaType.TEXT_PLAIN_VALUE);

        ClientResponse<String> response = getHandler.exec(CENTER_LOOKUP_URL, String.class, "59");
        logger.info("response: {}", response.toString());
        logger.info("----------------------------------------------------------------------------------------------------");

        response = getHandler.exec(CENTER_LOOKUP_URL, String.class, "60");
        logger.info("response: {}", response.toString());
        logger.info("----------------------------------------------------------------------------------------------------");

        response = getHandler.exec(CENTER_LOOKUP_URL, String.class, "61");
        logger.info("response: {}", response.toString());
        logger.info("----------------------------------------------------------------------------------------------------");
    }

    /**
     * Test the Basic handler and fail in a non-local environment when no client certificates installed.
     * 
     * @throws Exception on any errors
     */
    @SuppressWarnings("unused")
    private void testBasicRestClientNonLocal() throws Exception {
        logger.info("Basic Authentication test");
        logger.info("url {}", CENTER_LOOKUP_URL);
        GetHandler<String> getHandler = new GetHandler<String>("l");
        getHandler.setBasicAuthentication(basicUsername, basicPassword);

        ClientResponse<String> clientResponse = getHandler.exec(CENTER_LOOKUP_URL, String.class, "59");
        logger.info("clientResponse {}\n", clientResponse);
    }

}
