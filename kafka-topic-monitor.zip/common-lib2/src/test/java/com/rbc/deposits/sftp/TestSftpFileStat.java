package com.rbc.deposits.sftp;

import java.util.Vector;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

@Ignore
public class TestSftpFileStat {
    private Logger logger = LoggerFactory.getLogger(TestSftpFileStat.class);

    String sftpHostname = "sshgcc.fg.rbc.com";
    String sftpLocationShare = "/appshare/ck00/eod_file";
    int sftpPort = 22;

    String username = "PZGVSRVA";
    String password = "Y1nMmced";

    SftpConnector sftpConnector;
    Session session;

    @Test
    public void testSftpConnector() {
        try {
            sftpConnector = new SftpConnector("TEST", sftpHostname, sftpPort, username, password);
            session = sftpConnector.openSession();
            test();
            sftpConnector.closeSession(session);
        } catch (Exception e) {
            logger.error("Oops - {}", ExceptionUtils.getRootCauseMessage(e));
        }
    }

    void test() throws JSchException {
        try {
            ChannelSftp channelSftp = sftpConnector.openChannel(session);
            @SuppressWarnings("unchecked")
            Vector<ChannelSftp.LsEntry> lsEntries = channelSftp.ls(sftpLocationShare);
            logger.info("found [{}] entries", lsEntries.size());
            for (LsEntry lsEntry : lsEntries) {
                this.stat(channelSftp, lsEntry);
            }
            pause(1000);
            sftpConnector.closeChannel(channelSftp);
            logger.info("Done!");
            // try a not found file
            String filename = sftpLocationShare + '/' + "invalid.filename";
            SftpATTRS sftpAttrs = this.getAttributes(channelSftp, filename + "-bad");
            logger.info("file [{}] stats [{}]", filename, sftpAttrs);
        } catch (Exception e) {
            logger.error("Oops...", e);
        }
    }

    void stat(ChannelSftp channelSftp, LsEntry lsEntry) throws JSchException, SftpException {
        String filename = sftpLocationShare + '/' + lsEntry.getFilename();
        try {
            SftpATTRS sftpAttrs = channelSftp.stat(filename);
            if (!sftpAttrs.isDir()) {
                logger.info("file [{}]", lsEntry.getFilename());
                logger.info("- file size       [{}]", sftpAttrs.getSize());
                logger.info("- permissions     [{}]", sftpAttrs.getPermissions());
                logger.info("- UTC access time [{}]", sftpAttrs.getATime());
                logger.info("- UTC access time [{}]", sftpAttrs.getAtimeString());
                logger.info("- UTC modify time [{}]", sftpAttrs.getMTime());
                logger.info("- UTC modify time [{}]", sftpAttrs.getMtimeString());
            }
        } catch (Exception e) {
            logger.error("stat failed for [{}]", filename);
        }
    }

    SftpATTRS getAttributes(ChannelSftp channelSftp, String filename) throws JSchException, SftpException {
        SftpATTRS sftpAttrs = null;
        try {
            sftpAttrs = channelSftp.stat(filename);
            logger.info("file [{}]", filename);
            logger.info("- file size       [{}]", sftpAttrs.getSize());
            logger.info("- permissions     [{}]", sftpAttrs.getPermissions());
            logger.info("- UTC access time [{}]", sftpAttrs.getATime());
            logger.info("- UTC access time [{}]", sftpAttrs.getAtimeString());
            logger.info("- UTC modify time [{}]", sftpAttrs.getMTime());
            logger.info("- UTC modify time [{}]", sftpAttrs.getMtimeString());
        } catch (Exception e) {
            logger.error("stat failed for [{}]", filename);
        }
        return sftpAttrs;
    }

    void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            //
        }
    }

}
