package com.rbc.deposits.sftp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

@Ignore
public class TestSftpFile1Sort {
    private Logger logger = LoggerFactory.getLogger(TestSftpFile1Sort.class);

    public static final String APP_REGEX = "(.+_)(\\d+)(\\..+)";
    public static final Pattern APP_PATTERN = Pattern.compile(APP_REGEX);
    public static final String APP_DATE_FORMAT = "yyyyMMddHHmmssSSS";

    String center = "DEV";
    String sftpHostname = "sshgcc.fg.rbc.com";
    String sftpLocationShare = "/appshare/ck00/eod_file";
    int sftpPort = 22;

    String username = "PZGVSRVA";
    String password = "Y1nMmced";

    SftpConnector sftpConnector;
    Session session;

    String[] prefixes = {"pda_oleod_"};

    @Test
    public void testSftpConnector() {
        try {
            sftpConnector = new SftpConnector(center, sftpHostname, sftpPort, username, password);
            session = sftpConnector.openSession();
            test();
            sftpConnector.closeSession(session);
        } catch (Exception e) {
            logger.error("Oops - {}", ExceptionUtils.getRootCauseMessage(e));
        }
    }

    void test() throws JSchException {
        try {
            ChannelSftp channelSftp = sftpConnector.openChannel(session);
            List<LsEntry> lsEntries = getFilteredRemoteFileList(prefixes);

            logger.info("found [{}] entries", lsEntries.size());
            for (LsEntry lsEntry : lsEntries) {
                logger.info("file [{}]", lsEntry.getFilename());
            }
            sftpConnector.closeChannel(channelSftp);
            logger.info("Done!");
        } catch (Exception e) {
            logger.error("Oops...", e);
        }
    }

    List<LsEntry> getFilteredRemoteFileList(String[] prefixes) throws JSchException {
        if (logger.isDebugEnabled()) {
            logger.debug("center [{}] retrieve file list from [{}] for prefixes {}", center, sftpLocationShare, Arrays.asList(prefixes));
        }

        List<LsEntry> fileList = new ArrayList<>();
        ChannelSftp channelSftp = sftpConnector.openChannel(session);
        try {
            @SuppressWarnings("unchecked")
            Vector<LsEntry> remoteFileList = channelSftp.ls(sftpLocationShare); // NOSONAR
            for (LsEntry lsEntry : remoteFileList) {
                lsEntry.getAttrs().getMTime();
                String filename = lsEntry.getFilename();
                for (String prefix : prefixes) {
                    if (filename.startsWith(prefix)) {
                        fileList.add(lsEntry);
                        break;
                    }
                }
            }
        } catch (SftpException e) {
            logger.error("center [{}] retrieve file list from [{}] for prefixes {} - {}",
                            center, sftpLocationShare, Arrays.asList(prefixes), ExceptionUtils.getRootCauseMessage(e));
        } finally {
            sftpConnector.closeChannel(channelSftp);
        }

        // ----------------------------------------
        // sort by age ascending
        // ----------------------------------------
        Comparator<LsEntry> comparator = new Compare();
        fileList.sort(comparator);

        if (logger.isDebugEnabled()) {
            for (LsEntry lsEntry : fileList) {
                logger.debug("center [{}] retrieved file [{}] mtime [{}]", center, lsEntry.getFilename(), lsEntry.getAttrs().getMTime());
            }
        }

        logger.info("center [{}] retrieved [{}] files from [{}] for prefixes {}",
                        center, fileList.size(), sftpLocationShare, Arrays.asList(prefixes));

        return fileList;
    }

    class Compare implements Comparator<LsEntry> {

        @Override
        public int compare(LsEntry leftEntry, LsEntry rightEntry) {
            String left = leftEntry.getFilename();
            String right = rightEntry.getFilename();

            String leftDatetime = null;
            String rightDatetime = null;

            Matcher leftMatcher = APP_PATTERN.matcher(left);
            if (leftMatcher.matches()) {
                leftDatetime = leftMatcher.group(2);
            }

            Matcher rightMatcher = APP_PATTERN.matcher(right);
            if (rightMatcher.matches()) {
                rightDatetime = rightMatcher.group(2);
            }

            int result = 0;
            if (leftDatetime != null && rightDatetime != null) {
                result = leftDatetime.compareTo(rightDatetime);
            }
            return result;
        }
    }
}
