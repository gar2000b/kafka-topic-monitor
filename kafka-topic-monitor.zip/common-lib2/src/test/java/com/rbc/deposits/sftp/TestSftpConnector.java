package com.rbc.deposits.sftp;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

@Ignore
public class TestSftpConnector {
    private Logger logger = LoggerFactory.getLogger(TestSftpConnector.class);

    String sftpHostname = "sshgcc.fg.rbc.com";
    String sftpLocationShare = "/appshare/ck00/eod_file";
    int sftpPort = 22;

    String username = "PZGVSRVA";
    String password = "Y1nMmced";

    SftpConnector sftpConnector;
    Session session;

    @Test
    public void testSftpConnector() {
        try {
            sftpConnector = new SftpConnector("TEST", sftpHostname, sftpPort, username, password);
            session = sftpConnector.openSession();
            test();
            sftpConnector.closeSession(session);
        } catch (Exception e) {
            logger.error("Oops - {}", ExceptionUtils.getRootCauseMessage(e));
        }
    }

    void test() throws JSchException {
        int count = 25;
        int pass = 0;
        int fail = 0;
        for (int i = 0; i < count; i++) {
            try {
                ChannelSftp channelSftp = sftpConnector.openChannel(session);
                if (channelSftp != null) {
                    pause(250);
                    sftpConnector.closeChannel(channelSftp);
                    logger.info("Done!");
                    pass++;
                } else {
                    fail++;
                }
            } catch (Exception e) {
                logger.error("Oops...", e);
                fail++;
            }
        }
        logger.info("attempts [{}] passed [{}] failed [{}]", count, pass, fail);
    }
    
    void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            //
        }
    }

}
