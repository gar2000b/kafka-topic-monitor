package com.rbc.deposits.sftp;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

@Ignore
public class TestSftpConnections {
    private Logger logger = LoggerFactory.getLogger(TestSftpConnections.class);

    String hostname = "sshgcc.fg.rbc.com";
    String locationShare = "/appshare/ck00/eod_file";
    int port = 22;

    String username = "PZGVSRVA";
    String password = "Y1nMmced";

    @Test
    public void testSftp() throws JSchException {
        try {
            exec();
        } catch (Exception e) {
            logger.error("Oops... {}", ExceptionUtils.getRootCauseMessage(e));
        }
    }

    void exec() throws JSchException {
        int count = 5;
        ChannelSftp[] channels = new ChannelSftp[count];

        Session session = this.openSession();
        try {
            for (int i = 0; i < count; i++) {
                channels[i] = this.openChannel(session);
                pause(500);
            }
        } catch (JSchException e) {
            logger.error("cchannel error - {}", ExceptionUtils.getRootCauseMessage(e));
        } finally {
            for (int i = 0; i < count; i++) {
                if (channels[i] != null) {
                    logger.info("closing channel [{}]", channels[i].getId());
                    channels[i].disconnect();
                }
            }
        }
        session.disconnect();
    }

    JSch jsch = new JSch();

    private Session openSession() throws JSchException {

        Session session;
        try {
            session = jsch.getSession(username, hostname, port);
            if (password != null) {
                session.setPassword(password);
            }
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            logger.info("connected to sftp session - server version [{}]", session.getServerVersion());
        } catch (JSchException e) {
            logger.error("creating stfp session - {}", ExceptionUtils.getRootCauseMessage(e));
            throw e;
        }
        return session;
    }

    ChannelSftp openChannel(Session session) throws JSchException {
        Channel channel;
        try {
            channel = session.openChannel("sftp");
            channel.connect();
            logger.info("connected to sftp channel [{}]", channel.getId());
        } catch (JSchException e) {
            logger.error("connecting to sftp channel - {}", ExceptionUtils.getRootCauseMessage(e));
            throw e;
        }
        return (ChannelSftp) channel;
    }


    void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            //
        }
    }

}
