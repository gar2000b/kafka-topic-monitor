package com.rbc.deposits.sftp;

import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * Wrapper around jcraft.com - SFTP client implementation.
 * 
 * <p>
 * The underlying 'JCraft' library that provides SFTP services is not thread safe. Usage is as follows:
 * </p>
 * 
 * <ol>
 * <li>Open one (1) session per application (or thread)</li>
 * <li>Open one (1) channel per task to perform</li>
 * <li>Close the channel upon completion of the task</li>
 * <li>Close the session upon termination of the application (or thread)</li>
 * </ol>
 * 
 * <p>
 * If a session becomes invalid then simply open a new one.
 * </p>
 * 
 * @author 264289448
 *
 */
public class SftpConnector {
    private Logger logger = LoggerFactory.getLogger(SftpConnector.class);

    private static final long RETRY_MILLIS = 6000; // retry period = 1 minute

    private final String center;
    private final String hostname;
    private final int port;
    private final String username;
    private final String password;

    private JSch jsch;
    
    private Session session;

    static final AtomicInteger connectorId = new AtomicInteger();
    private final int id;

    /**
     * Construct an SftpConnector with a random id.
     * 
     * @param center the operating center
     * @param hostname the hostname
     * @param port the port
     * @param username the username
     * @param password the password
     */
    public SftpConnector(String center, String hostname, int port, String username, String password) {
        this.center = center;
        this.hostname = hostname;
        this.port = port;
        this.username = username;
        this.password = password;
        this.jsch = new JSch();
        id = connectorId.incrementAndGet();
    }

    /**
     * Get the connector id.
     * 
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * Open an SFTP server session.
     * 
     * @return a Session instance
     * @throws JSchException on any connection errors
     * @deprecated use openSession(SessionContext sessionContext)
     */
    public Session openSession() throws JSchException {
        if (logger.isDebugEnabled()) {
            logger.debug("center [{}] sftp connector [{}] opening session to [{}]", center, id, hostname);
        }
        try {
            session = jsch.getSession(username, hostname, port);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword(password);
            session.connect();
            // session.connect(15) // is this timeout in seconds or milliseconds?
            logger.info("center [{}] sftp connector [{}] session open to [{}] server version [{}]", center, id, session.getHost(), session.getServerVersion());
            return session;
        } catch (JSchException e) {
            logger.error("center [{}] sftp connector [{}] - opening session to [{}] - {}", center, id, hostname, ExceptionUtils.getRootCauseMessage(e));
            throw e;
        }
    }

    /**
     * Attempt to open an SFTP server session and retry until successful.
     * 
     * @param sessionContext the SessionContext that will hold the Session
     */
    public void openSession(SessionContext sessionContext) {
        // always check the SessionContext
        if (sessionContext == null) {
            raiseInvalidSessionContext();
        }
        while (!sessionContext.isConnected()) {
            connect(sessionContext);
            if (!sessionContext.isConnected()) {
                // pause and retry
                try {
                    Thread.sleep(RETRY_MILLIS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    /**
     * Close the SFTP server session.
     * 
     * @param session the owner Session
     * @deprecated use closeSession(SessionContext sessionContext)
     */
    public void closeSession(Session session) {
        if (session.isConnected()) {
            session.disconnect();
            if (logger.isDebugEnabled()) {
                logger.debug("center [{}] sftp connector [{}] - session to [{}] closed", center, id, session.getHost());
            }
        } else {
            logger.error("center [{}] sftp connector [{}] - session is not connected", center, id);
        }
    }

    /**
     * Close the SFTP server session.
     * 
     * @param sessionContext the SessionContext containing the Session
     */
    public void closeSession(SessionContext sessionContext) {
        // always check the SessionContext
        if (sessionContext == null || sessionContext.getSession() == null) {
            raiseInvalidSessionContext();
        }
        if (sessionContext.isConnected()) {
            sessionContext.getSession().disconnect();
            if (logger.isDebugEnabled()) {
                logger.debug("center [{}] sftp connector [{}] - session to [{}] closed", center, id, sessionContext.getSession().getHost());
            }
        } else {
            logger.error("center [{}] sftp connector [{}] - session is not connected", center, id);
        }
        sessionContext.reset();
    }

    /**
     * Opne a channel to the SFTP server.
     * 
     * @param sesson the owning Session
     * @return a ChannelSftp instance
     * @throws JSchException on any connection errors
     * @deprecated use openChannel(SessionContext sessionContext)
     */
    public ChannelSftp openChannel(Session sesson) throws JSchException {
        if (logger.isDebugEnabled()) {
            logger.debug("center [{}] sftp connector [{}] opening channel to [{}]", center, id, session.getHost());
        }
        try {
            ChannelSftp channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
            // is this timeout in seconds or milliseconds?
            // channelSftp.connect(15)
            logger.info("center [{}] sftp connector [{}] - channel [{}] open to [{}]", center, id, channelSftp.getId(), channelSftp.getSession().getHost());
            return channelSftp;
        } catch (JSchException e) {
            logger.error("center [{}] sftp connector [{}] - opening channel to [{}] - {}", center, id, session.getHost(), ExceptionUtils.getRootCauseMessage(e));
            throw e;
        }
    }

    /**
     * Opne a channel to the SFTP server.
     * 
     * @param sessionContext the SessionContext containing the Session
     * @return a ChannelSftp instance
     * @throws JSchException on any connection errors
     */
    public ChannelSftp openChannel(SessionContext sessionContext) throws JSchException {
        // always check the SessionContext
        if (sessionContext == null || sessionContext.getSession() == null) {
            raiseInvalidSessionContext();
        }
        if (!sessionContext.isConnected()) {
            openSession(sessionContext);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("center [{}] sftp connector [{}] opening channel to [{}]", center, id, sessionContext.getSession().getHost());
        }
        try {
            ChannelSftp channelSftp = (ChannelSftp) sessionContext.getSession().openChannel("sftp");
            channelSftp.connect();
            // is this timeout in seconds or milliseconds?
            // channelSftp.connect(15)
            logger.info("center [{}] sftp connector [{}] - channel [{}] open to [{}]", center, id, channelSftp.getId(), channelSftp.getSession().getHost());
            return channelSftp;
        } catch (JSchException e) {
            logger.error("center [{}] sftp connector [{}] - opening channel to [{}] - {}", center, id, sessionContext.getSession().getHost(), ExceptionUtils.getRootCauseMessage(e));
            throw e;
        }
    }

    /**
     * Close the connection to the SFTP server.
     * 
     * @param channelSftp the ChannelSftp to close
     */
    public void closeChannel(ChannelSftp channelSftp) {
        if (channelSftp != null && channelSftp.isConnected()) {
            channelSftp.disconnect();
            if (logger.isDebugEnabled()) {
                logger.debug("center [{}] sftp connector [{}] - channel [{}] closed", center, id, channelSftp.getId());
            }
        } else {
            logger.error("center [{}] sftp connector [{}] - channel is not connected", center, id);
        }
    }

    private void connect(SessionContext sessionContext) {
        sessionContext.reset();
        try {
            Session contextSession = jsch.getSession(username, hostname, port);
            contextSession.setConfig("StrictHostKeyChecking", "no");
            contextSession.setPassword(password);
            contextSession.connect();
            // contextSession.connect(15) // is this timeout in seconds or milliseconds?
            logger.info("center [{}] sftp connector [{}] session open to [{}] server version [{}]", center, id, contextSession.getHost(), contextSession.getServerVersion());
            sessionContext.setSession(contextSession);
        } catch (JSchException e) {
            sessionContext.reset();
            logger.error("center [{}] sftp connector [{}] - opening session to [{}] - {}", center, id, hostname, ExceptionUtils.getRootCauseMessage(e));
        }
    }

    private void raiseInvalidSessionContext() {
        throw new IllegalArgumentException("Invalid session context");
    }

}
