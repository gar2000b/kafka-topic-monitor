package com.rbc.deposits.config.vcap;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbc.deposits.config.vcap.model.UserProvidedService;
import com.rbc.deposits.config.vcap.model.VcapApplication;
import com.rbc.deposits.config.vcap.model.VcapServices;

/**
 * Utilities for accessing the Vcap (VMware's Cloud Application Platform) aka Cloud Foundry environment.
 * 
 * 
 * @author 316746874
 *
 */
public class VcapUtil {

    /**
     * The name of the environment variable containing UPS information. Defined by CF specification
     */
    public static final String ENV_VAR = "VCAP_SERVICES";
    public static final String ENV_VAR_APP = "VCAP_APPLICATION";

    private static Logger logger = LoggerFactory.getLogger(VcapUtil.class);

    public static List<UserProvidedService> getUserProvidedServices() {
        String value = System.getenv(ENV_VAR);
        if (value != null) {
            try {
                VcapServices vcapServices = new ObjectMapper().readValue(value, VcapServices.class);
                return vcapServices.getUserProvidedServices();
            } catch (IOException e) {
                logger.error(e.getMessage());
            }
        }
        return null;
    }

    public static UserProvidedService getUserProvidedService(String name) {
        List<UserProvidedService> userProvidedServices = getUserProvidedServices();
        if (userProvidedServices != null) {
            for (UserProvidedService userProvidedService : userProvidedServices) {
                if (userProvidedService.getName().equals(name)) {
                    return userProvidedService;
                }
            }
        }
        return null;
    }

    public static String getApplicationId() {
        String appId = "";
        try {
            VcapApplication vcapApplication = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false).readValue(System.getenv(ENV_VAR_APP), VcapApplication.class);
            appId = vcapApplication.getApplicationId();
        } catch (IOException e) {
            logger.error(e.getMessage());
        } catch (NullPointerException e) {
            logger.error(e.getMessage());
        }
        return appId;
    }
}
