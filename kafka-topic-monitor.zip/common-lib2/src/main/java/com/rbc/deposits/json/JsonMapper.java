package com.rbc.deposits.json;

import java.util.Map;

/**
 * JsonMapper traverses a Deserialized JSON Map and finds named values.
 *  
 * @author 316746874
 *
 * @param <T> the return type to cast the name value.
 */
public class JsonMapper<T> {

    /**
     * Recursively search a Map for the named value.
     * 
     * @param name the name to match
     * @param map the map to search
     * @return the value cast to T or null if not found
     */
    @SuppressWarnings("unchecked")
    public T find(String name, Map<String, Object> map) {
        T item = null;
        Object object = map.get(name);
        if (object == null) {
            for (String key : map.keySet()) {
                Object value = map.get(key);
                if (value instanceof Map) {
                    Map<String, Object> valueMap = (Map<String, Object>) value;
                    object = find(name, valueMap);
                    if (object != null) {
                        break;
                    }
                }
            }
        }
        if (object != null) {
            item = (T) object;
        }
        return item;
    }
}
