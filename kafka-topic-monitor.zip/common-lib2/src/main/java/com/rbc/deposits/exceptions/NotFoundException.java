package com.rbc.deposits.exceptions;

/**
 * Thrown when not found (404) is encountered.
 * 
 * @author 340340355
 * 
 */
public class NotFoundException extends AppRuntimeException {

    private static final long serialVersionUID = -3257024159771000179L;

    /**
     * Construct a new NotFoundException.
     * 
     * @param message the exception specific message
     * @param parameters optional parameters to message
     */
    public NotFoundException(String message, Object... parameters) {
        super(message, parameters);
    }

    /**
     * Construct a new NotFoundException.
     * 
     * @param message the exception specific message
     * @param cause the predecessor in the chain
     * @param parameters optional parameters to message
     */
    public NotFoundException(String message, Throwable cause, Object... parameters) {
        super(message, cause, parameters);
    }

    /**
     * Construct a new NotFoundException.
     * 
     * @param cause the predecessor in the chain
     * @param parameters optional parameters
     */
    public NotFoundException(Throwable cause, Object... parameters) {
        super(cause, parameters);
    }
}
