package com.rbc.deposits.rest.client.handlers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.rbc.deposits.rest.client.ClientException;
import com.rbc.deposits.rest.client.ClientResponse;

/**
 * GetHandler.
 * 
 * @author 316746874
 *
 * @param <T> the expected response type
 */
public class GetHandler<T> extends BaseHandler {
    
    public GetHandler() {
        super(null);
    }
    
    public GetHandler(String environment) {
        super(environment);
    }
    
    public GetHandler(String environment, boolean skipSsl) {
        super(environment, skipSsl);
    }

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Execute a GET request and return a {@link ClientResponse}.
     * 
     * @param url the target URL
     * @param responseType the expected response class type
     * @param uriVariables optional array of URI variables
     * @return a ClientResponse
     * @throws ClientException on any errors
     */
    public ClientResponse<T> exec(String url, Class<T> responseType, Object... uriVariables) throws ClientException {
        try {
            HttpHeaders requestHeaders = requestHeaders();

            // ------------------------------------------------------------
            // execute the request
            // ------------------------------------------------------------
            HttpEntity<Void> requestEntity = new HttpEntity<>(requestHeaders);
            ResponseEntity<T> responseEntity = restTemplate.exchange(url, HttpMethod.GET, requestEntity, responseType, uriVariables);
            HttpHeaders responseHeaders = responseEntity.getHeaders();

            // ------------------------------------------------------------
            // build a response
            // ------------------------------------------------------------
            HttpStatus httpStatus = responseEntity.getStatusCode();
            String warning = responseHeaders.getFirst(HttpHeaders.WARNING);
            T responseBody = responseEntity.getBody();
            ClientResponse<T> response = new ClientResponse<>(httpStatus, warning, null, responseBody);

            if (debugging && logger.isDebugEnabled()) {
                logger.debug("GET status [{}]", httpStatus);
            }
            return response;
        } catch (Throwable t) {
            throw new ClientException(t);
        }
    }
}

