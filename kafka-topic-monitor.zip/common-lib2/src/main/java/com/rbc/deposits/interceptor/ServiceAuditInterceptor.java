package com.rbc.deposits.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.rbc.deposits.util.GuidGenerator;

/**
 * ServiceAuditInterceptor is an audit capture point. It intercepts Spring Controller requests and responses and logs
 * the access information.
 * 
 * <p>
 * If there is an 'audit-logger' configured it will use that otherwise events are logged to the default logger.
 * </p>
 * 
 * @author 316746874
 * 
 */
public class ServiceAuditInterceptor extends HandlerInterceptorAdapter {

    private Logger auditLogger = LoggerFactory.getLogger("audit-logger");

    private final String requestFormat = "{}|{}|{}|{}|{}|{}";

    private final String responseFormat = "{}|{}|{}|{}|{}|{}";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        String guid = GuidGenerator.createGuid();
        String eventType = "REQUEST";
        String remoteAddress = request.getRemoteAddr();
        String method = request.getMethod();
        String requestUrl = request.getRequestURL().toString();
        String referer = request.getHeader(HttpHeaders.REFERER);

        AuditEventContext auditEventContext = new AuditEventContext(guid);
        AuditEventThreadLocal.set(auditEventContext);

        auditLogger.info(requestFormat, guid, remoteAddress, eventType, method, requestUrl, referer);

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
        AuditEventContext auditEventContext = AuditEventThreadLocal.get();
        String guid = auditEventContext.getGuid();
        String eventType = "RESPONSE";
        String remoteAddress = request.getRemoteAddr();
        String method = request.getMethod();
        String requestUrl = request.getRequestURL().toString();
        String responseStatus = String.valueOf(response.getStatus());

        auditLogger.info(responseFormat, guid, remoteAddress, eventType, method, requestUrl, responseStatus);

        AuditEventThreadLocal.unset();
    }

}
