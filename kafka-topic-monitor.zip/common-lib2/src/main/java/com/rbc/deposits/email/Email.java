package com.rbc.deposits.email;

import java.io.Serializable;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("serial")
public class Email implements Serializable {

    private String host;
    private String subject;
    private String from;
    private String replyTo;
    private String recipients;
    private String message;
    private String alt;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    // Constructor
    public Email(String host, String from, String replyTo, String recipients,
                    String subject, String message, String alt) {
        this.host = host;
        this.from = from;
        this.replyTo = replyTo;
        this.recipients = recipients;
        this.subject = subject;
        this.message = message;
        this.alt = alt;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getReplyTo() {
        return replyTo;
    }

    public void setReplyTo(String replyTo) {
        this.replyTo = replyTo;
    }

    public String getRecipients() {
        return recipients;
    }

    public void setRecipients(String recipients) {
        this.recipients = recipients;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAlt() {
        return alt;
    }

    public void setAlt(String alt) {
        this.alt = alt;
    }

    public void sendEmail() {
        try {
            Properties props = System.getProperties();
            props.put("mail.smtp.host", host);

            MimeBodyPart html = new MimeBodyPart();
            MimeBodyPart text = new MimeBodyPart();

            text.setText(alt);
            html.setContent(message, "text/html");

            MimeMultipart content = new MimeMultipart("alternative");
            content.addBodyPart(text);
            content.addBodyPart(html);

            Session session = Session.getDefaultInstance(props, null);
            MimeMessage msg = new MimeMessage(session);
            msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
            msg.addHeader("format", "flowed");
            msg.addHeader("Content-Transfer-Encoding", "8bit");
            msg.setSubject(subject);
            msg.setFrom(new InternetAddress(from));
            msg.setReplyTo(InternetAddress.parse(replyTo, false));
            msg.setSentDate(new Date());
            msg.setRecipients(Message.RecipientType.TO,
                            InternetAddress.parse(recipients, false));
            msg.setContent(content);

            Transport.send(msg);
            logger.info("*** email sent | " + subject + " | " + message + " | " + host + " | " + from + " | " + replyTo + " | " + recipients + " | " + alt + " ***");
        } catch (MessagingException e) {
            logger.error("*** Could not send Email To: " + recipients
                            + " - Reply to: " + replyTo + " at " + new Date());
            logger.error("Messaging Exception is " + e.getMessage());
            e.getCause();
        }
    }
}
