/**
 * 
 */
/**
 * Environment constants.
 * 
 * @author 316746874
 *
 */
package com.rbc.deposits.environment;
