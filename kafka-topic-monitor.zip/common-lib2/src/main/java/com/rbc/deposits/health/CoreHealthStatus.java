package com.rbc.deposits.health;

import java.time.LocalDateTime;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

@Component
public class CoreHealthStatus {

    private LocalDateTime formatedDateTime = null;


    public CoreHealthStatus() {
        super();
    }

    public String getFormatedDateTime() {
        if (formatedDateTime == null) {
            return " ";
        } else {
            return formatedDateTime.toString();
        }
    }

    @PostConstruct
    public void setFormatedDateTime() {
        if (formatedDateTime == null) {
            this.formatedDateTime = LocalDateTime.now();
        }

    }

    @Override
    public String toString() {
        return String.format("CoreHealthStatus [formatedDateTime=%s]", formatedDateTime);
    }



}
