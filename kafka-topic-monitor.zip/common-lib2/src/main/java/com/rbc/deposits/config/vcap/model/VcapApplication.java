package com.rbc.deposits.config.vcap.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VcapApplication {

    @JsonProperty("application_id")
    private String applicationId;

    @JsonProperty("application_name")
    private String applicationName;

    @JsonProperty("application_uris")
    private List<String> applicationUris;

    @JsonProperty("application_version")
    private String applicationVersion;

    @JsonProperty("cf_api")
    private String cfApi;

    @JsonProperty("host")
    private String host;

    @JsonProperty("instance_id")
    private String instanceId;

    @JsonProperty("name")
    private String name;

    @JsonProperty("port")
    private String port;

    @JsonProperty("space_id")
    private String spaceId;

    @JsonProperty("space_name")
    private String spaceName;

    @JsonProperty("uris")
    private List<String> uris;

    @JsonProperty("version")
    private String version;

    public VcapApplication() {}

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public List<String> getApplicationUris() {
        return applicationUris;
    }

    public void setApplicationUris(List<String> applicationUris) {
        this.applicationUris = applicationUris;
    }

    public String getApplicationVersion() {
        return applicationVersion;
    }

    public void setApplicationVersion(String applicationVersion) {
        this.applicationVersion = applicationVersion;
    }

    public String getCfApi() {
        return cfApi;
    }

    public void setCfApi(String cfApi) {
        this.cfApi = cfApi;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(String spaceId) {
        this.spaceId = spaceId;
    }

    public String getSpaceName() {
        return spaceName;
    }

    public void setSpaceName(String spaceName) {
        this.spaceName = spaceName;
    }

    public List<String> getUris() {
        return uris;
    }

    public void setUris(List<String> uris) {
        this.uris = uris;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
