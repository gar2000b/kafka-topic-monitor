package com.rbc.deposits.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.rbc.deposits.exceptions.AppRuntimeException;
import com.rbc.deposits.exceptions.BadRequestException;
import com.rbc.deposits.exceptions.NotFoundException;
import com.rbc.deposits.exceptions.ServiceUnavailableException;
import com.rbc.deposits.exceptions.UnauthorizedException;



/**
 * AdviceController that localizes exception handling for REST controllers.
 * 
 * <p>
 * Negative response information is returned in the Warning header. See the following resources for discussion on the
 * Warning header.
 * </p>
 * 
 * <ul>
 * <li>https://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html</li>
 * <li>https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Warning</li>
 * </ul>
 * 
 * @author 316746874
 */
@ControllerAdvice
public class AdviceController extends ResponseEntityExceptionHandler {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private boolean debugError = false;

    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
            HttpHeaders headers, HttpStatus status, WebRequest request) {
        StringBuilder sb = new StringBuilder("supported methods are:");
        for (HttpMethod method : ex.getSupportedHttpMethods()) {
            sb.append(" " + method.toString());
        }
        return AdviceControllerUtil.getWarningResponse(sb.toString(), headers, status, request);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex,
            HttpHeaders headers, HttpStatus status, WebRequest request) {
        StringBuilder sb = new StringBuilder("supported media types are:");
        for (MediaType mediaType : ex.getSupportedMediaTypes()) {
            sb.append(" " + mediaType.toString());
        }
        return AdviceControllerUtil.getWarningResponse(sb.toString(), headers, status, request);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
            HttpHeaders headers, HttpStatus status, WebRequest request) {
        String warningText = "input message is not readable";
        return AdviceControllerUtil.getWarningResponse(warningText, headers, status, request);
    }

    /**
     * Handles {@link BadRequestException}.
     * 
     * <p>
     * These always return 400 (bad request).
     * </p>
     * 
     * @param e the BadRequestException
     * @param request the HttpServletRequest
     * @param response the HttpServletResponse
     */
    @ExceptionHandler(BadRequestException.class)
    public void handleBadRequestException(BadRequestException e, HttpServletRequest request,
            HttpServletResponse response) {
        logger.warn("{}", ExceptionUtils.getRootCauseMessage(e));
        AdviceControllerUtil.processWarningResponse(e, HttpServletResponse.SC_BAD_REQUEST, request, response);
    }
    
    /**
     * Handles {@link NotFoundException}.
     * 
     * <p>
     * These always return 404 (Not Found).
     * </p>
     * 
     * @param e the NotFoundException
     * @param request the HttpServletRequest
     * @param response the HttpServletResponse
     */
    @ExceptionHandler(NotFoundException.class)
    public void handleBadRequestException(NotFoundException e, HttpServletRequest request,
            HttpServletResponse response) {
        logger.warn("{}", ExceptionUtils.getRootCauseMessage(e));
        AdviceControllerUtil.processWarningResponse(e, HttpServletResponse.SC_NOT_FOUND, request, response);
    }

    /**
     * Handles {@link UnauthorizedException}.
     * 
     * <p>
     * These always return 401 (unauthorized).
     * </p>
     * 
     * @param e the BadRequestException
     * @param request the HttpServletRequest
     * @param response the HttpServletResponse
     */
    @ExceptionHandler(UnauthorizedException.class)
    public void handleUnauthorizedException(UnauthorizedException e, HttpServletRequest request,
            HttpServletResponse response) {
        logger.warn("{}", ExceptionUtils.getRootCauseMessage(e));
        AdviceControllerUtil.processWarningResponse(e, HttpServletResponse.SC_UNAUTHORIZED, request, response);
    }

    /**
     * Handles {@link AppRuntimeException}.
     * 
     * <p>
     * These always return 500 (internal server error).
     * </p>
     * 
     * @param e the ApiException
     * @param request the HttpServletRequest
     * @param response the HttpServletResponse
     */
    @ExceptionHandler(AppRuntimeException.class)
    public void handleAppRuntimeException(AppRuntimeException e, HttpServletRequest request,
                    HttpServletResponse response) {
        // ------------------------------------------------------------
        // ensure we log the full stack trace for runtime exceptions
        // ------------------------------------------------------------
        logger.error("Internal Error\n", e);
        AdviceControllerUtil.processErrorResponse(e, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, request, response);
    }

    /**
     * Handles {@link ServiceUnavailableException}.
     * 
     * <p>
     * These always return 503 (service unavailable).
     * </p>
     * 
     * @param e the ApiException
     * @param request the HttpServletRequest
     * @param response the HttpServletResponse
     */
    @ExceptionHandler(ServiceUnavailableException.class)
    public void handleServiceUnavailableException(ServiceUnavailableException e, HttpServletRequest request,
                    HttpServletResponse response) {
        if (debugError) {
            logger.error("ServiceUnavailableException", e);
        } else {
            logger.error("{}", ExceptionUtils.getRootCauseMessage(e));
        }
        AdviceControllerUtil.processErrorResponse(e, HttpServletResponse.SC_SERVICE_UNAVAILABLE, request, response);
    }
}
