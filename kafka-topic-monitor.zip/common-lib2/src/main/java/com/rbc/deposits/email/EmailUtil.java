package com.rbc.deposits.email;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EmailUtil {

    private Logger logger = LoggerFactory.getLogger(getClass());

    private static EmailUtil _instance;

    private static Map<String, String> cache = new HashMap<String, String>();

    private EmailUtil() {}

    private EmailUtil(String host, String from, String replyTo, String recipients, String envCode, String notificationTimeElapsed) {
        this.host = host;
        this.from = from;
        this.replyTo = replyTo;
        this.recipients = recipients;
        this.envCode = envCode;
        this.notificationTimeElapsed = notificationTimeElapsed;
    }

    private String notificationTimeElapsed;
    private String host;
    private String from;
    private String replyTo;
    private String recipients;
    private String envCode;

    public static EmailUtil getInstance(EmailProperties emailProperties) {
        if (null == _instance) {
            synchronized (EmailUtil.class) {
                if (null == _instance) {
                    _instance = new EmailUtil(emailProperties.getHost(), emailProperties.getFrom(), emailProperties.getReplyTo(), emailProperties.getRecipients(), emailProperties.getEnvCode(),
                                    emailProperties.getNotificationElapsedTime());
                }
            }
        }
        return _instance;
    }

    /**
     * This method will send an email with the subject and message, based on the interval defined in configuration.
     * 
     * @param subject of the mail.
     * @param message of the mail, to be shown in the body.
     */
    public void sendPeriodicNotification(String subject, String message) {
        sendPeriodicNotification(subject, message, recipients);
    }

    /**
     * This method will send an email with the subject and message, based on the interval defined in configuration.
     * 
     * @param subject of the mail.
     * @param message of the mail, to be shown in the body.
     * @param recipients - override the recipients which were defined with configuration.
     */
    public void sendPeriodicNotification(String subject, String message, String recipients) {
        Long allowedElapsedTime = Long.parseLong(notificationTimeElapsed) * 60 * 1000;
        if (StringUtils.isNotBlank(cache.get(from))) {
            LocalDateTime lastSentTime = LocalDateTime.parse(cache.get(from), DateTimeFormatter.ISO_DATE_TIME);
            long minutesInMillis = Duration.between(lastSentTime, LocalDateTime.now()).toMillis();
            if (logger.isDebugEnabled()) {
                logger.debug("time since last email sent: [{}]", minutesInMillis);
            }
            if (minutesInMillis >= allowedElapsedTime) {
                fireEmail(subject, message, recipients);
                cache.put(from, LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
            } else {
                logger.info("Email won't be sent as it is within the lapse time defined from the last email.");
            }
        } else {
            fireEmail(subject, message, recipients);
            cache.put(from, LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        }
    }

    /**
     * This method will always send email with the subject and message defined.
     * 
     * @param subject of the mail.
     * @param message of the mail, to be shown in the body.
     */
    public void fireEmail(String subject, String message) {
        fireEmail(subject, message, recipients);
    }

    /**
     * This method will always send email with the subject and message defined.
     * 
     * @param subject of the mail.
     * @param message of the mail, to be shown in the body.
     * @param recipients - override the recipients which were defined with configuration.
     */
    public void fireEmail(String subject, String message, String recipients) {
        String alt = message;

        if (envCode.equals("l")) {
            logger.info("*** mock email sent | " + subject + " | " + message + " | " + host + " | " + from + " | " + replyTo + " | " + recipients + " | " + alt + " ***");
        } else {
            Email email = new Email(host, from, replyTo, recipients, subject, message, alt);
            email.sendEmail();
        }
    }

    @Override
    public String toString() {
        return String.format("EmailUtil [notificationTimeElapsed=%s, host=%s, from=%s, replyTo=%s, recipients=%s, envCode=%s]", notificationTimeElapsed, host, from, replyTo, recipients, envCode);
    }

}
