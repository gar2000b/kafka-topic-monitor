package com.rbc.deposits.oauth2.token;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.rbc.deposits.json.JsonMessageConverter;
import com.rbc.deposits.rest.client.ClientException;
import com.rbc.deposits.rest.client.ClientResponse;
import com.rbc.deposits.rest.client.handlers.PostHandler;

/**
 * Retrieve and Cache token.
 * 
 * @author 308816883
 */
@Configuration
public class Oauth2Token {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private Oauth2Properties oauth2Properties;

    private ConcurrentHashMap<String, CachedToken> cache = new ConcurrentHashMap<>();

    private JsonMessageConverter jsonMessageConverter = new JsonMessageConverter();

    /**
     * Method which uses the default key, to retrieve and store tokens in cache. 
     * 
     * @return Bearer token.
     * @throws Exception - In case of issues while connecting to downstream or retrieving the token from cache.
     */
    public String getCachedToken() throws Exception {
        return getCachedToken(Oauth2Constants.TOKEN_CACHE_KEY);
    }
    
    /**
     * Method which accepts a key to retrieve and store the token against. 
     * 
     * @param tokenKey - the key against which the token is stored in the cache.
     * @return Bearer token.
     * @throws Exception - In case of issues while connecting to downstream or retrieving the token from cache.
     */
    public String getCachedToken(String tokenKey) throws Exception {
        CachedToken cachedToken = cache.compute(tokenKey, (key, val) -> (val == null || System.currentTimeMillis() > val.getExpiresBy()) ? getToken() : val);
        return cachedToken.getToken();
    }

    /**
     * Generates the cache object with the token.
     * 
     * @return Cache Object.
     */
    private CachedToken getToken() {
        CachedToken cachedToken = new CachedToken();
        Map<String, Object> respMap = getTokenFromPingFed();
        if (null != respMap) {
            Integer expiresIn = (Integer) respMap.get(Oauth2Constants.EXPIRES_IN);
            Long expiresBy = System.currentTimeMillis() + (expiresIn - 3) * 1000;
            String bearerToken = respMap.get(Oauth2Constants.TOKEN_TYPE) + " " + respMap.get(Oauth2Constants.ACCESS_TOKEN);
            cachedToken.setToken(bearerToken);
            cachedToken.setExpiresIn(expiresIn);
            cachedToken.setExpiresBy(expiresBy);
            if (logger.isDebugEnabled()) {
                logger.debug("Caching token [{}]", cachedToken);
            }
            return cachedToken;
        } else {
            logger.warn("Downstream is messed up as well. :( ");
        }
        return null;
    }

    /**
     * Retrieves the token by calling PingFed with configured url and client_id/secret.
     * 
     * @return OAuth token object.
     */
    private Map<String, Object> getTokenFromPingFed() {
        try {
            PostHandler<MultiValueMap<String, String>> handler = new PostHandler<>(oauth2Properties.getApplicationEnvCode());
            handler.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);
            handler.setHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);

            MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<String, String>();
            requestBody.add(Oauth2Constants.CLIENT_ID, oauth2Properties.getClientId());
            requestBody.add(Oauth2Constants.CLIENT_SECRET, oauth2Properties.getClientSecret());
            requestBody.add(Oauth2Constants.GRANT_TYPE, Oauth2Constants.CLIENT_CREDENTIALS);
            requestBody.add(Oauth2Constants.SCOPE, Oauth2Constants.READ);

            ClientResponse<String> clientResponse = handler.exec(oauth2Properties.getPingFedUrl(), requestBody, String.class);
            String response = clientResponse.getValue();
            if (logger.isDebugEnabled()) {
                logger.debug("Called PingFed for new Access token. The response is: [{}]", response);
            }
            return jsonMessageConverter.toMap(response);
        } catch (ClientException e) {
            logger.error("Unable to retreive token from PingFed.");
        } catch (Exception e) {
            logger.error("Unable to parse PingFed response.");
        }

        return null;
    }
}
