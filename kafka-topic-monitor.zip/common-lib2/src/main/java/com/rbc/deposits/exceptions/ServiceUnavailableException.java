package com.rbc.deposits.exceptions;

/**
 * Thrown when service unavailable (503) is encountered.
 * 
 * @author 305967465
 * 
 */
public class ServiceUnavailableException extends AppRuntimeException {

    private static final long serialVersionUID = -310216255661597070L;

    /**
     * Construct a new ServiceUnavailableException.
     *
     * @param cause the predecessor in the chain
     * @param parameters optional parameters
     */
    public ServiceUnavailableException(Throwable cause, Object... parameters) {
        super(cause, parameters);
    }

    /**
     * Construct a new ServiceUnavailableException.
     *
     * @param message the exception specific message
     * @param parameters optional parameters to message
     */
    public ServiceUnavailableException(String message, Object... parameters) {
        super(message, parameters);
    }

    /**
     * Construct a new ServiceUnavailableException.
     *
     * @param message the exception specific message
     * @param cause the predecessor in the chain
     * @param parameters optional parameters to message
     */
    public ServiceUnavailableException(String message, Throwable cause, Object... parameters) {
        super(message, cause, parameters);
    }
}
