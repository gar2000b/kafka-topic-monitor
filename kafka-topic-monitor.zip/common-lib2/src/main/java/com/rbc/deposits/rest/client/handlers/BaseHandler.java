package com.rbc.deposits.rest.client.handlers;

import java.io.IOException;
import java.security.cert.X509Certificate;
import java.util.Base64;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import com.rbc.deposits.rest.client.ThreadLocalHeaders;

/**
 * BaseHandler implements common functionality required by all method handlers.
 * 
 * <p>
 * Read timeout has been enabled.
 * </p>
 * <p>
 * When a read timeout occurs, the handler will receive a 'java.net.SocketTimeoutException: Read timed out' - wrapped in a ClientException.
 * </p>
 * 
 * @author 316746874
 *
 */
public class BaseHandler {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * The default value for read timeouts.
     */
    public static final int DEFAULT_READ_TIMEOUT_SECONDS = 60;

    private static int readTimeoutSeconds = DEFAULT_READ_TIMEOUT_SECONDS;

    protected boolean debugging;

    /**
     * The RestTemplate.
     */
    protected RestTemplate restTemplate;

    /**
     * Get the current read timeout setting.
     * 
     * @return the readTimeoutSeconds
     */
    public static final int getReadTimeoutSeconds() {
        return readTimeoutSeconds;
    }

    /**
     * Set the readTimeoutSeconds.
     * 
     * <p>
     * This must be called prior to constructing a handler instance.
     * </p>
     * 
     * @param readTimeoutSeconds the new readTimeoutSeconds
     */
    public static final void setReadTimeoutSeconds(int readTimeoutSeconds) {
        BaseHandler.readTimeoutSeconds = readTimeoutSeconds;
    }

    /**
     * Set and encode the credentials to be used for Basic Authentication.
     * 
     * @param username the username
     * @param password the password
     */
    public final void setBasicAuthentication(String username, String password) {
        String plainCreds = username + ":" + password;
        byte[] plainCredsBytes = plainCreds.getBytes();
        byte[] base64CredsBytes = Base64.getEncoder().encode(plainCredsBytes);
        String base64Creds = new String(base64CredsBytes);
        String credentials = "Basic " + base64Creds;

        ThreadLocalHeaders.get().set(HttpHeaders.AUTHORIZATION, credentials);
    }

    /**
     * Set an additional request header.
     * 
     * @param headerName the header name
     * @param headerValue the header value
     */
    public final void setHeader(String headerName, String headerValue) {
        ThreadLocalHeaders.get().set(headerName, headerValue);
    }

    /**
     * Get the request Headers.
     * 
     * @return the HttpHeaders
     */
    protected final HttpHeaders requestHeaders() {
        return ThreadLocalHeaders.get();
    }

    /**
     * Constructor.
     * 
     * @param environment the environment
     */
    protected BaseHandler(String environment) {
        createTemplate(environment, false);
    }

    /**
     * Constructor for skipSsl.
     * 
     * @param environment - flag for environment.
     * @param skipSsl - flag for skip Ssl.
     */
    protected BaseHandler(String environment, boolean skipSsl) {
        createTemplate(environment, skipSsl);
    }

    protected void createTemplate(String environment, boolean skipSsl) {
        restTemplate = new RestTemplate();

        // --------------------------------------------------
        // override the default request factory to allow
        // support for PATCH operations
        // --------------------------------------------------
        if (skipSsl) {
            skipSsl();
        } else if (environment != null && (environment.equals("l")
                        || environment.equals("di")
                        || environment.equals("i"))) {
            addSslValidationBypass();
        } else {
            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
            requestFactory.setReadTimeout(readTimeoutSeconds * 1000);
            restTemplate.setRequestFactory(requestFactory);
        }

        // --------------------------------------------------
        // override the default error handler to allow the
        // request to return unimpeded with all data intact
        // --------------------------------------------------
        restTemplate.setErrorHandler(new ResponseErrorHandler() {

            @Override
            public boolean hasError(ClientHttpResponse response) throws IOException {
                return false;
            }

            @Override
            public void handleError(ClientHttpResponse response) throws IOException {}
        });

        // --------------------------------------------------
        // initialize the default headers
        // --------------------------------------------------
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        requestHeaders.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        ThreadLocalHeaders.set(requestHeaders);
    }

    /**
     * Add an SSL validation bypass.
     * 
     * <p>
     * Should be invoked for local development ONLY!
     * </p>
     */
    public final void addSslValidationBypass() {

        try {
            TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

            SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
                            .loadTrustMaterial(null, acceptingTrustStrategy)
                            .build();

            SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

            CloseableHttpClient httpClient = HttpClients.custom()
                            .setSSLSocketFactory(csf)
                            .build();

            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
            requestFactory.setReadTimeout(readTimeoutSeconds * 1000);

            requestFactory.setHttpClient(httpClient);
            restTemplate.setRequestFactory(requestFactory);
        } catch (Exception e) {
            logger.error("failed to add SSL Validation Bypass", e);
        }
        logger.warn("+--------------------------------------------+");
        logger.warn("| Running with SSL Validation Bypass enabled |");
        logger.warn("| Assuming we are running in local dev mode  |");
        logger.warn("+--------------------------------------------+");
    }

    /**
     * Method which configures the rest template to skip passing the ssl.
     */
    public final void skipSsl() {
        try {
            TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

            SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
                            .loadTrustMaterial(null, acceptingTrustStrategy)
                            .setKeyStoreType(null)
                            .build();

            SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

            CloseableHttpClient httpClient = HttpClients.custom()
                            .setSSLSocketFactory(csf)
                            .build();

            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
            requestFactory.setReadTimeout(readTimeoutSeconds * 1000);

            requestFactory.setHttpClient(httpClient);
            restTemplate.setRequestFactory(requestFactory);
        } catch (Exception e) {
            logger.error("failed to add SSL Validation Bypass", e);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("+-----------------------------------------------------+");
            logger.debug("| Running with SSL Skip SSL Validation Bypass enabled |");
            logger.debug("+-----------------------------------------------------+");
        }
    }

    public final boolean isDebugging() {
        return debugging;
    }

    public final void setDebugging(boolean debugging) {
        this.debugging = debugging;
    }
}
