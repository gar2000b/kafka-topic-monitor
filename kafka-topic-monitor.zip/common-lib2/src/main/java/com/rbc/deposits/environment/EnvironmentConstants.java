package com.rbc.deposits.environment;

/**
 * EnvironmentConstants defines constant values that identify the various execution environments.
 * 
 * @author 316746874
 *
 */
public class EnvironmentConstants {
    /** Indicates the local machine. */
    public static final String ENV_LOCAL = "l";

    /** Indicates the DEV in the pre-production cloud environment. */
    public static final String ENV_DEV = "d";
    
    /** Indicates the DEV Integration Testing in the pre-production cloud environment. */
    public static final String ENV_DEV_INTEGRATION_TEST = "di";
    
    public static final String ENV_INTEGRATION_TEST = "i";
    
    /** Indicates the QAT in the pre-production cloud environment. */
    public static final String ENV_QAT = "q";
    
    /** Indicates the UAT in the pre-production cloud environment. */
    public static final String ENV_UAT = "u";
    
    /** Indicates the Production cloud environment. */
    public static final String ENV_PROD = "p";
}
