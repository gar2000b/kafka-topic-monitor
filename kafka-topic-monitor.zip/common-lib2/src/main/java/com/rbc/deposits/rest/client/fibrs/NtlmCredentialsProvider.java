package com.rbc.deposits.rest.client.fibrs;

import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.client.CredentialsProvider;

/**
 * CredentialsProvider implementation purposed for NTLM authentication.
 * 
 * @author 316746874
 *
 */
public class NtlmCredentialsProvider implements CredentialsProvider {

    @SuppressWarnings("unused")
    private AuthScope authscope;
    private Credentials credentials;

    public NtlmCredentialsProvider(AuthScope authscope, Credentials credentials) {
        this.authscope = authscope;
        this.credentials = credentials;
    }

    @Override
    public void setCredentials(AuthScope authscope, Credentials credentials) {
        this.authscope = authscope;
        this.credentials = credentials;
    }

    @Override
    public Credentials getCredentials(AuthScope authscope) {
        return credentials;
    }

    @Override
    public void clear() {
        this.authscope = null;
        this.credentials = null;
    }

}
