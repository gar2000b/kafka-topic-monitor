package com.rbc.deposits.interceptor;

import com.rbc.deposits.interceptor.AuditEventThreadLocal;

/**
 * AuditEventContext used by {@link AuditEventThreadLocal}.
 * 
 * @author 316746874
 *
 */
public class AuditEventContext {
    private String guid;

    /**
     * Constructor.
     * 
     * @param guid the GUID to store
     */
    public AuditEventContext(String guid) {
        this.guid = guid;
    }

    /**
     * Get a unique GUID.
     * 
     * @return the guid
     */
    public String getGuid() {
        return guid;
    }
}
