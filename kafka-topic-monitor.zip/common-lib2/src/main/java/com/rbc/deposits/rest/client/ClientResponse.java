package com.rbc.deposits.rest.client;

import org.springframework.http.HttpStatus;

/**
 * ClientResponse is a generic container used by all handlers to return state and optional data.
 * 
 * @author 316746874
 *
 * @param <T> the response value type
 */
public class ClientResponse<T> {
    private HttpStatus httpStatus;
    private String warning;
    private String location;
    private T value;

    /**
     * Constructor.
     * 
     * @param httpStatus the HttpStatus
     * @param warning the Warning Header value
     * @param location the Location Header value
     * @param value the response body contents
     */
    public ClientResponse(HttpStatus httpStatus, String warning, String location, T value) {
        super();
        this.httpStatus = httpStatus;
        this.warning = warning;
        this.location = location;
        this.value = value;
    }

    /**
     * Get the httpStatus.
     * 
     * @return the httpStatus
     */
    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    /**
     * Get the warning.
     * 
     * @return the warning
     */
    public String getWarning() {
        return warning;
    }

    /**
     * Get the location.
     * 
     * @return the location
     */
    public String getLocation() {
        return location;
    }

    /**
     * Get the value.
     * 
     * @return the value
     */
    public T getValue() {
        return value;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ClientResponse [httpStatus=");
        builder.append(httpStatus);
        builder.append(", warning=");
        builder.append(warning);
        builder.append(", location=");
        builder.append(location);
        builder.append(", value=");
        builder.append(value);
        builder.append("]");
        return builder.toString();
    }

}
