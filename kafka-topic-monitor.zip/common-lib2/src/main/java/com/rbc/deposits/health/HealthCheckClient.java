package com.rbc.deposits.health;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.HttpStatus;

import com.rbc.deposits.json.JsonMapper;

import com.rbc.deposits.rest.AdviceControllerUtil;
import com.rbc.deposits.rest.client.ClientException;
import com.rbc.deposits.rest.client.ClientResponse;
import com.rbc.deposits.rest.client.handlers.GetHandler;

/**
 * HealthCheckClient performs health checks on downstream dependents.
 * 
 * @author 340340355
 *
 */
public class HealthCheckClient {

    private static Logger logger = LoggerFactory.getLogger(HealthCheckClient.class);

    public static final String HEALTHY_HTML_RESPONSE = "healthy";

    /**
     * Method to check health of downstream dependent applications.
     * 
     * @param endpoint of the downstream application
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @return true if the downstream application is healthy
     */
    public static boolean checkHealth(String endpoint, HttpServletRequest request, HttpServletResponse response) {
        try {
            endpoint = endpoint + "/health";
            GetHandler<String> getHandler = new GetHandler<>();
            ClientResponse<String> clientResponse = getHandler.exec((endpoint + ".html"), String.class);
            if (HttpStatus.NOT_FOUND == clientResponse.getHttpStatus()) {
                return handleActuatorUrlAndResponse(endpoint);
            } else {
                return handleControllerResponse(clientResponse);
            }
        } catch (ClientException ex) {
            AdviceControllerUtil.processWarningResponse(ex, HttpStatus.SERVICE_UNAVAILABLE.value(), request, response);
            logger.error(ExceptionUtils.getMessage(ex));
            logger.error("health check failed - {} : {}", ExceptionUtils.getRootCauseMessage(ex), endpoint);
        }
        return false;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static boolean handleActuatorUrlAndResponse(String url) throws ClientException {
        GetHandler<HashMap> getHandler = new GetHandler<>();
        ClientResponse<HashMap> clientResponse = getHandler.exec(url, HashMap.class);
        JsonMapper<String> jsonMapper = new JsonMapper<String>();
        if (HttpStatus.OK == clientResponse.getHttpStatus()) {
            String status = jsonMapper.find("status", clientResponse.getValue());
            if ("UP".equals(status)) {
                return true;
            }
            return false;
        }
        return false;
    }

    private static boolean handleControllerResponse(ClientResponse<String> clientResponse) throws ClientException {
        if ((HttpStatus.OK == clientResponse.getHttpStatus()) && ("healthy".equals(clientResponse.getValue()))) {
            return true;
        }
        return false;
    }
}
