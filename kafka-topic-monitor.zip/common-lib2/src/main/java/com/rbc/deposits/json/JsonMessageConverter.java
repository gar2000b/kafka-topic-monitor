package com.rbc.deposits.json;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * JsonMessageConverter.
 * 
 * @author 316746874
 */
public class JsonMessageConverter {

    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    private ObjectMapper objectMapper;

    /**
     * Create a JsonMessageConverter for a specific class type.
     */
    public JsonMessageConverter() {
        objectMapper = getMapper();
    }

    /**
     * Toggle pretty print for JSON output.
     * 
     * @param pretty true or false
     * @return this JsonMessageConverter
     */
    public JsonMessageConverter setPretty(boolean pretty) {
        if (pretty) {
            objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        } else {
            objectMapper.disable(SerializationFeature.INDENT_OUTPUT);
        }
        return this;
    }

    /**
     * Toggle property inclusion when null/empty in JSON output.
     * 
     * @param include true or false
     * @return this JsonMessageConverter
     */
    public JsonMessageConverter includeNull(boolean include) {
        if (include) {
            objectMapper.setSerializationInclusion(Include.ALWAYS);
        } else {
            objectMapper.setSerializationInclusion(Include.NON_NULL);
        }
        return this;
    }

    /**
     * Serialize an object of type T to the named file.
     * 
     * @param <T> the generic type that the converter will operate on
     * @param object the source object
     * @param filename the target file
     * @throws Exception on any errors
     */
    public <T> void marshal(T object, String filename) throws Exception {
        this.marshal(object, new File(filename));
    }

    /**
     * Serialize an object of type T to a file.
     * 
     * @param <T> the generic type that the converter will operate on
     * @param object the source object
     * @param file the file descriptor
     * @throws Exception on any errors
     */
    public <T> void marshal(T object, File file) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("JSON marshal [{}] to [{}]", object.getClass().getName(), file.getPath());
        }
        objectMapper.writeValue(file, object);
    }

    /**
     * Serialize an object of type T to a String.
     * 
     * @param <T> the generic type that the converter will operate on
     * @param object the source object
     * @return a JSON string
     * @throws Exception on any errors
     */
    public <T> String marshal(T object) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("JSON marshal object [{}]", object.getClass().getName());
        }
        return objectMapper.writeValueAsString(object);
    }

    /**
     * Deserialize a file to an object.
     * 
     * @param <T> the generic type that the converter will operate on
     * @param file the source file descriptor
     * @param responseType the expected response class type
     * @return an object of type T
     * @throws Exception on any errors
     */
    public <T> T unmarshal(File file, Class<T> responseType) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("unmarshal JSON file [{}]", file.getAbsoluteFile());
        }

        return objectMapper.readValue(file, responseType);
    }

    /**
     * Deserialize a JSON string to an object.
     * 
     * @param <T> the generic type that the converter will operate on
     * @param json the source String
     * @param responseType the generic response type
     * @return an object of type T
     * @throws Exception on any errors
     */
    public <T> T unmarshal(String json, Class<T> responseType) throws Exception {
        T object = objectMapper.readValue(json, responseType);
        if (logger.isDebugEnabled()) {
            logger.debug("unmarshal JSON string to [{}]", object.getClass().getSimpleName());
        }

        return object;
    }

    /**
     * Deserialize a JSON string to a Map.
     * 
     * @param json the source String
     * @return an object of type T
     * @throws Exception on any errors
     */
    public Map<String, Object> toMap(String json) throws Exception {
        return new ObjectMapper().readValue(json, mapTypeReference);
    }

    private TypeReference<Map<String, Object>> mapTypeReference = new TypeReference<Map<String, Object>>() {};

    private ObjectMapper getMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        objectMapper.configOverride(List.class).setInclude(JsonInclude.Value.construct(JsonInclude.Include.NON_EMPTY, null));
        objectMapper.configOverride(Map.class).setInclude(JsonInclude.Value.construct(JsonInclude.Include.NON_EMPTY, null));

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        return objectMapper.setDateFormat(dateFormat);
    }
}
