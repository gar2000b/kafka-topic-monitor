package com.rbc.deposits.oauth2.token;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Oauth2 Properties.
 * 
 * @author 308816883
 *
 */
@Configuration
public class Oauth2Properties {

    @Value("${application.env-code:#{'l'}}")
    private String applicationEnvCode;

    @Value("${oauth2.url:'https://mrkdlvaiaas493.devfg.rbc.com:9443/as/token.oauth2'}")
    private String pingFedUrl;

    @Value("${oauth2.client_id:'CLIENT_ID'}")
    private String clientId;

    @Value("${oauth2.client_secret:'CLIENT_SECRET'}")
    private String clientSecret;

    /**
     * Returns the value of applicationEnvCode.
     * 
     * @return the applicationEnvCode
     */
    public String getApplicationEnvCode() {
        return applicationEnvCode;
    }

    /**
     * Returns the value of clientId.
     * 
     * @return the clientId
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Returns the value of pingFedUrl.
     * 
     * @return the pingFedUrl
     */
    public String getPingFedUrl() {
        return pingFedUrl;
    }

    /**
     * Returns the value of clientSecret.
     * 
     * @return the clientSecret
     */
    public String getClientSecret() {
        return clientSecret;
    }

}
