package com.rbc.deposits.rest;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;

/**
 * Process response messages for 400 and 500 series response statuses.
 * 
 * <p>
 * This uses the Warning response header to relay additional information back to the caller.
 * </p>
 * 
 * <pre>
 * Warning       = 1#warning-value
 * 
 * warning-value = warn-code SP warn-agent SP warn-text
 *                                       [ SP warn-date ]
 * 
 * warn-code  = 3DIGIT
 * warn-agent = ( uri-host [ ":" port ] ) / pseudonym
 *                 ; the name or pseudonym of the server adding
 *                 ; the Warning header field, for use in debugging
 *                 ; a single "-" is recommended when agent unknown
 * warn-text  = quoted-string
 * warn-date  = DQUOTE HTTP-date DQUOTE
 * </pre>
 * 
 * @see <a href="http://tools.ietf.org/html/rfc7234#section-5.5">Section 5.5 of RFC 7234</a>
 * 
 * @author thomas
 * 
 */
public class AdviceControllerUtil {

    private static boolean stripExceptionClass = true;

    public static final String warnCode = "199";

    private static String warningTemplate = "{warn-code} {uri-host} '{warn-text}' \"{warn-date}\"";
    private static String errorTemplate = "An internal error has occurred and has been logged.";

    public static void stripExceptionClass(boolean flag) {
        stripExceptionClass = flag;
    }

    /**
     * Get a formatted warning String.
     * 
     * @param request the HttpServletRequest
     * @param warning the warning message
     * @return a formatted warning message
     */
    public static String getFormattedWarning(HttpServletRequest request, String warning) {
        //@formatter:off
        return warningTemplate
                .replace("{warn-code}", warnCode)
                .replace("{uri-host}", request.getRequestURI())
                .replace("{warn-text}", warning)
                .replace("{warn-date}", new Date(System.currentTimeMillis()).toString());
        //@formatter:on
    }

    /**
     * Process a Warning response to a WebRequest.
     * 
     * @param warningText the warning text
     * @param headers the HttpHeaders
     * @param status the HttpStatus
     * @param request the WebRequest
     * @return a ReponseEntity
     */
    public static ResponseEntity<Object> getWarningResponse(String warningText, HttpHeaders headers,
            HttpStatus status, WebRequest request) {
        String uriHost = request.getContextPath();

        //@formatter:off
        String warningValue = warningTemplate
                .replace("{warn-code}", warnCode)
                .replace("{uri-host}", uriHost)
                .replace("{warn-text}", warningText)
                .replace("{warn-date}", new Date(System.currentTimeMillis()).toString());
        //@formatter:on

        headers.set(HttpHeaders.WARNING, warningValue);
        return new ResponseEntity<Object>(null, headers, status);
    }
    
    /**
     * Process a Warning response for 400 series client side errors.
     * 
     * @param e the application Exception
     * @param httpStatus the HTTP response status
     * @param request the HttpServletRequest
     * @param response the HttpServletResponse
     */
    public static void processWarningResponse(Exception e, int httpStatus, HttpServletRequest request,
            HttpServletResponse response) {
        String rootCauseMessage = ExceptionUtils.getRootCauseMessage(e);

        if (stripExceptionClass) {
            int index = rootCauseMessage.indexOf(":");
            if (index > -1) {
                rootCauseMessage = rootCauseMessage.substring(index + 1).trim();
            }
        }
        String uriHost = request.getRequestURI();

        //@formatter:off
        String warningValue = warningTemplate
                .replace("{warn-code}", warnCode)
                .replace("{uri-host}", uriHost)
                .replace("{warn-text}", rootCauseMessage)
                .replace("{warn-date}", new Date(System.currentTimeMillis()).toString());
        //@formatter:on

        response.setHeader(HttpHeaders.WARNING, warningValue);
        response.setStatus(httpStatus);
    }

    /**
     * Process a Warning response for 500 series server side errors.
     * 
     * @param e the application Exception
     * @param httpStatus the HTTP response status
     * @param request the HttpServletRequest
     * @param response the HttpServletResponse
     */
    public static void processErrorResponse(Exception e, int httpStatus, HttpServletRequest request,
            HttpServletResponse response) {
        String rootCauseMessage = ExceptionUtils.getRootCauseMessage(e);

        if (stripExceptionClass) {
            int index = rootCauseMessage.indexOf(":");
            if (index > -1) {
                rootCauseMessage = rootCauseMessage.substring(index + 1).trim();
            }
        }
        String uriHost = request.getRequestURI();

        //@formatter:off
        String warningValue = warningTemplate
                .replace("{warn-code}", warnCode)
                .replace("{uri-host}", uriHost)
                .replace("{warn-text}", errorTemplate)
                .replace("{warn-date}", new Date(System.currentTimeMillis()).toString());
        //@formatter:on

        response.setHeader(HttpHeaders.WARNING, warningValue);
        response.setStatus(httpStatus);
    }
}
