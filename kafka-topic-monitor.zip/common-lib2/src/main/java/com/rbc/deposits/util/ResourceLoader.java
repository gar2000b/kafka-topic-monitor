package com.rbc.deposits.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class to load resources.
 * 
 * @author 316746874
 *
 */
public class ResourceLoader {

    private static Logger logger = LoggerFactory.getLogger(ResourceLoader.class);

    /**
     * Load a resource from the classpath.
     * 
     * @param name the resource name
     * @return the resource
     */
    public static String loadResource(String name) {
        if (logger.isDebugEnabled()) {
            logger.debug("loading resource [{}]", name);
        }
        String resource = "";
        try {
            InputStream is = ResourceLoader.class.getClassLoader().getResourceAsStream(name);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                if (sb.length() > 0) {
                    sb.append("\n");
                }
                sb.append(line);
            }
            resource = sb.toString();
        } catch (Exception e) {
            logger.error("loading resource", e);
        }
        return resource;
    }

    /**
     * Load a resource from a file.
     * 
     * @param filename the file name
     * @return the resource
     * @throws Exception on any errors
     */
    public static String loadFile(String filename) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("loading resource [{}]", filename);
        }
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new FileReader(filename));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                if (sb.length() > 0) {
                    sb.append("\n");
                }
                sb.append(line);
            }
            return sb.toString();
        } catch (Exception e) {
            throw e;
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    //
                }
            }
        }
    }
}
