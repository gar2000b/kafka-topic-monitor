/**
 * 
 */
/**
 * VCap support model.
 * 
 * @author 316746874
 *
 */
package com.rbc.deposits.config.vcap.model;
