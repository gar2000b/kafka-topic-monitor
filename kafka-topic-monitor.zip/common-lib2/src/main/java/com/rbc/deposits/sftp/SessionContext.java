package com.rbc.deposits.sftp;

import com.jcraft.jsch.Session;

/**
 * SessionContext holds the Session thereby decoupling the it from the application.
 * 
 * <p>
 * Placing the Session into a secondary container simplifies the process session management.
 * </p>
 * 
 * <p>
 * Decoupling allows for easier implementation of recovery processing during a failure scenario.
 * </p>
 * 
 * @author 264289448
 *
 */
public class SessionContext {

    private Session session;

    /**
     * Constructor.
     * 
     */
    public SessionContext() {
        super();
    }

    /**
     * Get the session.
     * 
     * @return the session
     */
    public Session getSession() {
        return session;
    }

    /**
     * Set the session.
     * 
     * @param session the session to set
     */
    public void setSession(Session session) {
        this.session = session;
    }

    /**
     * Determine if the session is connected.
     * 
     * @return true|false
     */
    public boolean isConnected() {
        return session != null && session.isConnected();
    }

    /**
     * Reset the session.
     */
    public void reset() {
        session = null;
    }

}
