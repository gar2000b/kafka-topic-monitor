package com.rbc.deposits.util;

import java.util.UUID;

/**
 * A GUID generator - 32 characters with '-' removed.
 * 
 * @author 316746874
 */

public class GuidGenerator {

    /**
     * Uses UUID to generate a pseudo-random GUID with no embedded '-'. The result GUID is 32 characters in length.
     * 
     * @return a new GUID
     */
    public static String createGuid() {
        String guid = UUID.randomUUID().toString();
        guid = guid.replaceAll("-", "");
        return guid;
    }
}
