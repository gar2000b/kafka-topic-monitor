package com.rbc.deposits.integration.test;

import java.io.IOException;
import java.util.List;

import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.context.ApplicationContextException;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;

public class IntegrationTestInitializer {

    private IntegrationTestInitializer() {}

    private static final String INTEGRATION_TEST_YML = "integration-test.yml";

    public static void initialize(ConfigurableApplicationContext applicationContext) {
        try {
            YamlPropertySourceLoader loader = new YamlPropertySourceLoader();
            ConfigurableEnvironment env = applicationContext.getEnvironment();
            Resource resource = applicationContext.getResource("classpath:" + INTEGRATION_TEST_YML);

            List<PropertySource<?>> source = loader.load("integration-test", resource);
            if (env.getActiveProfiles().length > 0) {
                for (int i = 0; i < source.size(); i++) {
                    env.getPropertySources().addFirst(source.get(i));
                }
            } else {
                env.getPropertySources().addFirst(source.get(0));
            }
        } catch (IOException e) {
            throw new ApplicationContextException("Failed to load integration-test.yml", e);
        }
    }
}
