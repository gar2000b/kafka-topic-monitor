package com.rbc.deposits.config.vcap.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VcapServices {

    @JsonProperty("user-provided")
    private List<UserProvidedService> userProvidedServices;

    public VcapServices() {}

    public List<UserProvidedService> getUserProvidedServices() {
        return userProvidedServices;
    }

    public void setUserProvidedServices(List<UserProvidedService> userProvidedServices) {
        this.userProvidedServices = userProvidedServices;
    }
}
