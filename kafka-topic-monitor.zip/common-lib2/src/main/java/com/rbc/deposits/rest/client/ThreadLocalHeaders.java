package com.rbc.deposits.rest.client;

import org.springframework.http.HttpHeaders;

/**
 * ThreadLocal storage for HttpHeaders.
 * 
 * @author 316746874
 *
 */
public class ThreadLocalHeaders {

    /** The Constant ThreadLocal Context. */
    public static final ThreadLocal<HttpHeaders> threadLocalContext = new ThreadLocal<HttpHeaders>();

    /**
     * Sets the HttpHeaders.
     *
     * @param httpHeaders the HttpHeaders to set
     */
    public static void set(HttpHeaders httpHeaders) {
        threadLocalContext.set(httpHeaders);
    }

    /**
     * Remove the HttpHeaders.
     */
    public static void unset() {
        threadLocalContext.remove();
    }

    /**
     * Gets the HttpHeaders.
     *
     * @return the HttpHeaders
     */
    public static HttpHeaders get() {
        HttpHeaders httpHeaders = threadLocalContext.get();
        if (httpHeaders == null) {
            httpHeaders = new HttpHeaders();
            threadLocalContext.set(httpHeaders);
        }
        return httpHeaders;
    }

}
