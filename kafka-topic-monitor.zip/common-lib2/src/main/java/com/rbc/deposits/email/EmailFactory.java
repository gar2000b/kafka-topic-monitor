package com.rbc.deposits.email;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EmailFactory {

    @Autowired
    private EmailProperties emailProperties;

    public EmailUtil getEmailUtil() {
        return EmailUtil.getInstance(emailProperties);
    }
    
}
