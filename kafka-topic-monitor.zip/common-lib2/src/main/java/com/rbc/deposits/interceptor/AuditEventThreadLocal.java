package com.rbc.deposits.interceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ThreadLocal storage for a {@link AuditEventContext}.
 * 
 * @author 316746874
 *
 */
public class AuditEventThreadLocal {

    private static Logger logger = LoggerFactory.getLogger(AuditEventThreadLocal.class);

    /** The Constant ThreadLocal Context. */
    public static final ThreadLocal<AuditEventContext> threadLocalContext = new ThreadLocal<AuditEventContext>();

    /**
     * Sets the AuditEventContext.
     *
     * @param auditEventContext the AuditEventContext to set
     */
    public static void set(AuditEventContext auditEventContext) {
        logger.debug("thread [{}] setting auditEventContext", Thread.currentThread().getId());
        threadLocalContext.set(auditEventContext);
    }

    /**
     * Remove the AuditEventContext.
     */
    public static void unset() {
        logger.debug("thread [{}] unsetting auditEventContext", Thread.currentThread().getId());
        threadLocalContext.remove();
    }

    /**
     * Gets the AuditEventContext.
     *
     * @return the AuditEventContext
     */
    public static AuditEventContext get() {
        AuditEventContext auditEventContext = threadLocalContext.get();
        logger.debug("thread [{}] getting auditEventContext [{}]", Thread.currentThread().getId(), auditEventContext);
        return auditEventContext;
    }
}
