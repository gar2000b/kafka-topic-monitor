/**
 * 
 */
/**
 * Common application runtime exceptions.
 * 
 * @author 316746874
 *
 */
package com.rbc.deposits.exceptions;
