package com.rbc.deposits.email;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmailProperties {

    @Value(value = "${email.notification_elapsed_time:60}")
    private String notificationElapsedTime;
    
    @Value(value = "${email.host:labmailer.devfg.rbc.com}")
    private String host;
    
    @Value(value = "${email.from:FGDEPOSITS_CLOUD_SQUAD_CYBERDYNE@rbc.com}")
    private String from;
    
    @Value(value = "${email.replyTo:FGDEPOSITS_CLOUD_SQUAD_CYBERDYNE@rbc.com}")
    private String replyTo;
    
    @Value(value = "${email.recipients:RBCITDDASYSTEMSMAINTENANCESUPPORT@RBC.COM}")
    private String recipients;
    
    @Value(value = "${application.env-code:l}")
    private String envCode;
    
    public String getNotificationElapsedTime() {
        return notificationElapsedTime;
    }
    
    public void setNotificationElapsedTime(String notificationElapsedTime) {
        this.notificationElapsedTime = notificationElapsedTime;
    }
    
    public String getHost() {
        return host;
    }
    
    public void setHost(String host) {
        this.host = host;
    }
    
    public String getFrom() {
        return from;
    }
    
    public void setFrom(String from) {
        this.from = from;
    }
    
    public String getReplyTo() {
        return replyTo;
    }
    
    public void setReplyTo(String replyTo) {
        this.replyTo = replyTo;
    }
    
    public String getRecipients() {
        return recipients;
    }
    
    public void setRecipients(String recipients) {
        this.recipients = recipients;
    }
    
    public String getEnvCode() {
        return envCode;
    }

    public void setEnvCode(String envCode) {
        this.envCode = envCode;
    }

    @Override
    public String toString() {
        return String.format("EmailProperties [notificationElapsedTime=%s, host=%s, from=%s, replyTo=%s, recipients=%s, envCode=%s]", notificationElapsedTime, host, from, replyTo, recipients,
                        envCode);
    }

}
