package com.rbc.deposits.rest.client.handlers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.rbc.deposits.rest.client.ClientException;
import com.rbc.deposits.rest.client.ClientResponse;

/**
 * DeleteHandler.
 * 
 * @author 316746874
 *
 */
public class DeleteHandler extends BaseHandler {

    public DeleteHandler() {
        super(null);
    }

    public DeleteHandler(String environment) {
        super(environment);
    }

    public DeleteHandler(String environment, boolean skipSsl) {
        super(environment, skipSsl);
    }

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Execute a DELETE request and return a {@link ClientResponse}.
     * 
     * @param url the target URL
     * @param uriVariables optional array of URI variables
     * @return a ClientResponse
     * @throws ClientException on any errors
     */
    public ClientResponse<Void> exec(String url, Object... uriVariables) throws ClientException {
        try {
            HttpHeaders requestHeaders = requestHeaders();

            // ------------------------------------------------------------
            // execute the request
            // ------------------------------------------------------------
            HttpEntity<Void> requestEntity = new HttpEntity<>(requestHeaders);
            ResponseEntity<Void> responseEntity = restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, Void.class, uriVariables);
            HttpHeaders responseHeaders = responseEntity.getHeaders();

            // ------------------------------------------------------------
            // build a response
            // ------------------------------------------------------------
            HttpStatus httpStatus = responseEntity.getStatusCode();
            String warning = responseHeaders.getFirst(HttpHeaders.WARNING);
            ClientResponse<Void> response = new ClientResponse<>(httpStatus, warning, null, null);

            if (debugging && logger.isDebugEnabled()) {
                logger.debug("DELETE status [{}]", httpStatus);
            }

            return response;
        } catch (Throwable t) {
            throw new ClientException(t);
        }
    }
    
    public <R> ClientResponse<R> exec(String url, Class<R> responseType, Object... uriVariables) throws ClientException {
        try {
            HttpHeaders requestHeaders = requestHeaders();

            // ------------------------------------------------------------
            // execute the request
            // ------------------------------------------------------------
            HttpEntity<Void> requestEntity = new HttpEntity<>(requestHeaders);
            ResponseEntity<R> responseEntity = restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, responseType, uriVariables);
            HttpHeaders responseHeaders = responseEntity.getHeaders();

            // ------------------------------------------------------------
            // build a response
            // ------------------------------------------------------------
            HttpStatus httpStatus = responseEntity.getStatusCode();
            String location = responseHeaders.getFirst(HttpHeaders.LOCATION);
            String warning = responseHeaders.getFirst(HttpHeaders.WARNING);
            R responseBody = responseEntity.getBody();
            ClientResponse<R> response = new ClientResponse<>(httpStatus, warning, location, responseBody);

            if (debugging && logger.isDebugEnabled()) {
                logger.debug("DELETE status [{}] location [{}]", httpStatus, location);
            }

            return response;
        } catch (Throwable t) {
            throw new ClientException(t);
        }
    }
}

