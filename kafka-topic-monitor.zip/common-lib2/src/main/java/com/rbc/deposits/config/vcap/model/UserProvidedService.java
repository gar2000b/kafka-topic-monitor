package com.rbc.deposits.config.vcap.model;

import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserProvidedService {

    public UserProvidedService() {}

    @JsonProperty("credentials")
    private Map<String, String> credentials;
    
    @JsonProperty("syslog_drain_url")
    @Nullable
    private String syslogDrainUrl;

    @JsonProperty("label")
    @Nullable
    private String label;

    @JsonProperty("name")
    @Nullable
    private String name;
    
    @JsonProperty("instance_name")
    @Nullable
    private String instanceName;
    
    @JsonProperty("binding_name")
    @Nullable
    private String bindingName;

    @JsonProperty("tags")
    private List<String> tags;
    
    @JsonProperty("volume_mounts")
    private List<String> volumeMounts;

    public Map<String, String> getCredentials() {
        return credentials;
    }

    public void setCredentials(Map<String, String> credentials) {
        this.credentials = credentials;
    }

    public String getSyslogDrainUrl() {
        return syslogDrainUrl;
    }

    public void setSyslogDrainUrl(String syslogDrainUrl) {
        this.syslogDrainUrl = syslogDrainUrl;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getInstanceName() {
        return instanceName;
    }
    
    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }
    
    public String getBindingName() {
        return bindingName;
    }
    
    public void setBindingName(String bindingName) {
        this.bindingName = bindingName;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public List<String> getVolumeMounts() {
        return volumeMounts;
    }

    public void setVolumeMounts(List<String> volumeMounts) {
        this.volumeMounts = volumeMounts;
    }
}
