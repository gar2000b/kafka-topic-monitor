/**
 * 
 */
/**
 * Support for email send capability.
 * 
 * @author 316746874
 *
 */
package com.rbc.deposits.email;
