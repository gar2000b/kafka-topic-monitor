package com.rbc.deposits.rest.client.fibrs;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.Arrays;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.auth.NTLMScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import com.rbc.deposits.exceptions.AppRuntimeException;
import com.rbc.deposits.rest.client.ClientException;
import com.rbc.deposits.rest.client.ClientResponse;

/**
 * FibrsRestClient is a discrete FiBRS Rest Client that uses NTLM authentication.
 * 
 * <p>
 * Below are usage considerations.
 * </p>
 * 
 * <ul>
 * <li>Once constructed, this client is bound to target serverUrl provide in the constructor.</li>
 * <li>Request Headers set are persisted across requests.</li>
 * <li>Request Headers may be updated or removed.</li>
 * </ul>
 * 
 * @author 316746874
 *
 */
public class FibrsRestClient {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private RestTemplate restTemplate;

    private boolean preemptiveAuth = true;
    private AuthHttpRequestFactory authHttpRequestFactory;
    private HttpContext localContext;
    private Credentials credentials;
    private CredentialsProvider credentialsProvider;
    private AuthScope authScope;

    private String serverUrl;
    private String ntlmUsername;
    private String ntlmPassword;
    private String workstation;
    private String domain;

    private HttpHeaders requestHeaders = new HttpHeaders();

    /**
     * Constructor a new FibrsRestClient.
     * 
     * <p>
     * Once create the client is bound to the target serverUrl.
     * </p>
     * 
     * <p>
     * The serverUrl is in form protocol://host[:port][...]. The port defaults if not specified and the remainder is ignored.
     * </p>
     * 
     * @param serverUrl the URL of target server
     * @param ntlmUsername the NTLM ntlmUsername
     * @param ntlmPassword the NTLM password
     * @param domain the domain
     */
    public FibrsRestClient(String serverUrl, String ntlmUsername, String ntlmPassword, String domain) {
        this(serverUrl, ntlmUsername, ntlmPassword, null, domain);
    }

    /**
     * Constructor a new FibrsRestClient.
     * 
     * <p>
     * Once create the client is bound to the target serverUrl.
     * </p>
     * 
     * <p>
     * The serverUrl is in form protocol://host[:port][...]. The port defaults if not specified and the remainder is ignored.
     * </p>
     * 
     * @param serverUrl the URL of target server as protocol://hostname[:port][resource[fragment]]
     * @param ntlmUsername the NTLM ntlmUsername
     * @param ntlmPassword the NTLM password
     * @param workstation the optional workstation
     * @param domain the domain
     */
    public FibrsRestClient(String serverUrl, String ntlmUsername, String ntlmPassword, String workstation, String domain) {
        this.serverUrl = serverUrl;
        this.ntlmUsername = ntlmUsername;
        this.ntlmPassword = ntlmPassword;
        this.workstation = workstation;
        this.domain = domain;

        initRestTemplate();
    }

    /**
     * Enable or disable preemptive authentication.
     * 
     * <p>
     * Preemptive authentication is enabled by default.
     * </p>
     * 
     * <p>
     * This may be invoked at any time to alter preemptive authentication behavior.
     * </p>
     * 
     * @param preemptive preemptive setting
     * @return a reference to this to allow chaining
     */
    public final FibrsRestClient preemptive(boolean preemptive) {
        this.preemptiveAuth = preemptive;
        return this;
    }

    /**
     * Build the FibrsRestClient. This must be explicitly called.
     * 
     * @return a reference to this to allow chaining
     * @throws AppRuntimeException on any build errors
     */
    public final FibrsRestClient build() {
        initHttpClient();
        return this;
    }

    /**
     * Set an additional request header.
     * 
     * @param headerName the header name
     * @param headerValue the header value
     * @return a reference to this to allow chaining
     */
    public final FibrsRestClient setHeader(String headerName, String headerValue) {
        requestHeaders.set(headerName, headerValue);
        return this;
    }

    /**
     * Remove an existing request header.
     * 
     * @param headerName the header name
     * @return a reference to this to allow chaining
     */
    public final FibrsRestClient unsetHeader(String headerName) {
        requestHeaders.remove(headerName);
        return this;
    }

    /**
     * Get the request Headers.
     * 
     * @return the HttpHeaders
     */
    protected final HttpHeaders requestHeaders() {
        return requestHeaders;
    }

    /**
     * Execute a GET request and return a {@link ClientResponse}.
     * 
     * @param <T> the expected response type
     * @param url the target URL
     * @param responseType the expected response class type
     * @param uriVariables optional array of URI variables
     * @return a ClientResponse
     * @throws ClientException on any errors
     */
    public final <T> ClientResponse<T> get(String url, Class<T> responseType, Object... uriVariables) throws ClientException {
        try {
            HttpHeaders requestHeaders = requestHeaders();

            // ------------------------------------------------------------
            // execute the request
            // ------------------------------------------------------------
            HttpEntity<Void> requestEntity = new HttpEntity<>(requestHeaders);
            ResponseEntity<T> responseEntity = restTemplate.exchange(url, HttpMethod.GET, requestEntity, responseType, uriVariables);
            HttpHeaders responseHeaders = responseEntity.getHeaders();

            // ------------------------------------------------------------
            // build a response
            // ------------------------------------------------------------
            HttpStatus httpStatus = responseEntity.getStatusCode();
            String warning = responseHeaders.getFirst(HttpHeaders.WARNING);
            T responseBody = responseEntity.getBody();
            ClientResponse<T> response = new ClientResponse<>(httpStatus, warning, null, responseBody);

            logger.info("GET status [{}]", httpStatus);
            return response;
        } catch (Throwable t) {
            throw new ClientException(t);
        }
    }

    /**
     * Build the client with an SSL validation bypass.
     * 
     * <p>
     * This can only be invoked for "l", "i", "di" environments!
     * </p>
     * 
     * @param envCode the environment code to test
     * @return a reference to this to allow chaining
     * @throws AppRuntimeException on invalid environment or build errors
     */
    public final FibrsRestClient buildNoSslValidation(String envCode) {
        if ("l".equals(envCode) || "i".equals(envCode) || "di".equals(envCode)) {
            ;
        } else {
            throw new AppRuntimeException("SSL Validation Bypass not allowed for envCode [{}]", envCode);
        }
        try {
            initSslValidationBypass();
        } catch (Exception e) {
            throw new AppRuntimeException("failed to build SSL Validation Bypass", e);
        }
        return this;
    }

    private void initRestTemplate() {
        restTemplate = new RestTemplate();

        // --------------------------------------------------
        // override the default error handler to allow the
        // request to return unimpeded with all data intact
        // --------------------------------------------------
        restTemplate.setErrorHandler(new ResponseErrorHandler() {

            @Override
            public boolean hasError(ClientHttpResponse response) throws IOException {
                return false;
            }

            @Override
            public void handleError(ClientHttpResponse response) throws IOException {}
        });
    }

    private void initHttpClient() {
        RequestConfig config = RequestConfig.custom().setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM)).build();
        CloseableHttpClient httpClient = HttpClients.custom()
                        .setDefaultRequestConfig(config)
                        .setDefaultCredentialsProvider(credentialsProvider)
                        .build();

        authHttpRequestFactory = new AuthHttpRequestFactory();
        authHttpRequestFactory.setHttpClient(httpClient);

        restTemplate.setRequestFactory(authHttpRequestFactory);
    }

    private void initSslValidationBypass() throws Exception {
        RequestConfig config = RequestConfig.custom().setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM)).build();

        TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
        SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
                        .loadTrustMaterial(null, acceptingTrustStrategy)
                        .build();
        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

        final CloseableHttpClient httpClient = HttpClients.custom()
                        .setDefaultRequestConfig(config)
                        .setDefaultCredentialsProvider(credentialsProvider)
                        .setSSLSocketFactory(csf)
                        .build();

        logger.warn("+--------------------------------------------+");
        logger.warn("| Running with SSL Validation Bypass enabled |");
        logger.warn("| Assuming we are running in local dev mode  |");
        logger.warn("+--------------------------------------------+");

        authHttpRequestFactory = new AuthHttpRequestFactory();
        authHttpRequestFactory.setHttpClient(httpClient);

        restTemplate.setRequestFactory(authHttpRequestFactory);
    }

    private HttpClientContext getAuthContext() {
        if (logger.isDebugEnabled()) {
            logger.debug("creating context for NTLM authentication");
        }
        // --------------------------------------------------
        // create the http host info
        // --------------------------------------------------
        HttpHost httpHost = null;
        try {
            URL url = new URL(serverUrl);
            String protocol = url.getProtocol();
            String host = url.getHost();
            int port = url.getPort();
            if (port == -1) {
                port = url.getDefaultPort();
            }
            httpHost = new HttpHost(host, port, protocol);
            if (logger.isDebugEnabled()) {
                logger.debug("using HttpHost [{}]", httpHost.toString());
            }
        } catch (MalformedURLException e) {
            throw new AppRuntimeException(e);
        }
        // --------------------------------------------------
        // establish a credentials provider
        // --------------------------------------------------
        if (logger.isDebugEnabled()) {
            logger.debug("creating NTLM credentials provider");
        }
        credentials = new NTCredentials(ntlmUsername, ntlmPassword, workstation, domain);
        credentialsProvider = new NtlmCredentialsProvider(AuthScope.ANY, credentials);
        // --------------------------------------------------
        // establish an authorization scope
        // --------------------------------------------------
        // if (authScope == null) {
        if (logger.isDebugEnabled()) {
            logger.debug("creating authorization scope");
        }
        String schemeName = httpHost.getSchemeName();
        String host = httpHost.getHostName();
        int port = httpHost.getPort();
        // --------------------------------------------------
        // default realm is AuthScope.ANY_REALM which == null
        // --------------------------------------------------
        authScope = new AuthScope(host, port, AuthScope.ANY_REALM, schemeName);
        if (logger.isDebugEnabled()) {
            logger.debug("using authScope [{}]", authScope.toString());
        }
        credentialsProvider.setCredentials(authScope, credentials);
        if (logger.isDebugEnabled()) {
            logger.debug("using credentials provider [{}]", credentialsProvider.getClass().getSimpleName());
            logger.debug("using auth scope [{}]", authScope.toString());
        }
        // --------------------------------------------------
        // create a cache for preemptive authorization
        // --------------------------------------------------
        AuthCache authCache = new BasicAuthCache();
        NTLMScheme ntlmScheme = new NTLMScheme();
        authCache.put(httpHost, ntlmScheme);
        // --------------------------------------------------
        // create an execution context
        // add the cache and credentials provider
        // set up the the context for thread local access
        // --------------------------------------------------
        HttpClientContext httpClientContext = HttpClientContext.create();
        httpClientContext.setAuthCache(authCache);
        httpClientContext.setCredentialsProvider(credentialsProvider);

        return httpClientContext;
    }

    /**
     * This class extends HttpComponentsClientHttpRequestFactory to add an HttpContext for local caching of credentials to support preemptive authentication.
     * 
     * @author 316746874
     *
     */
    private class AuthHttpRequestFactory extends HttpComponentsClientHttpRequestFactory {

        public AuthHttpRequestFactory() {
            super();
        }

        @Override
        protected HttpContext createHttpContext(HttpMethod httpMethod, URI uri) {
            if (!preemptiveAuth) {
                if (logger.isDebugEnabled()) {
                    logger.debug("preemptiveAuth false : resetting local context");
                }
                localContext = null;
            }
            if (localContext == null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("createHttpContext for httpMethod [{}] uri [{}]", httpMethod.toString(), uri.toString());
                }
                localContext = getAuthContext();
            }
            return localContext;
        }
    }
}
