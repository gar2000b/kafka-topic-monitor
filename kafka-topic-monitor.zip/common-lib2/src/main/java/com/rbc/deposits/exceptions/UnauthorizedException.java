package com.rbc.deposits.exceptions;

/**
 * Thrown when unauthorized (401) exception is encountered.
 * 
 * @author 316746874
 * 
 */
public class UnauthorizedException extends AppRuntimeException {

    private static final long serialVersionUID = -3592086436327278775L;

    /**
     * Construct a new UnauthorizedException.
     *
     * @param cause the predecessor in the chain
     * @param parameters optional parameters
     */
    public UnauthorizedException(Throwable cause, Object... parameters) {
        super(cause, parameters);
    }

    /**
     * Construct a new UnauthorizedException.
     *
     * @param message the exception specific message
     * @param parameters optional parameters to message
     */
    public UnauthorizedException(String message, Object... parameters) {
        super(message, parameters);
    }

    /**
     * Construct a new UnauthorizedException.
     *
     * @param message the exception specific message
     * @param cause the predecessor in the chain
     * @param parameters optional parameters to message
     */
    public UnauthorizedException(String message, Throwable cause, Object... parameters) {
        super(message, cause, parameters);
    }
}
