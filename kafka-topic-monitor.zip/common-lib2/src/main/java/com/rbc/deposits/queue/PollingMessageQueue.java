package com.rbc.deposits.queue;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * PollingMessageQueue operates as a first in first out (FIFO) buffer providing concurrent and thread safe access to the underlying message queue.
 * 
 * <p>
 * PollingMessageQueue operates as follows.
 * </p>
 * 
 * <ul>
 * <li>Consumers periodically check for the availability of messages.</li>
 * <li>Whenever a messages are available the consumer will receive all available messages up to the maximum value set.</li>
 * <li>If there are no messages available an empty list is returned and the consumer sleeps for the polling interval.</li>
 * </ul>
 * 
 * <p>
 * PollingMessageQueue is the best choice for downstream batch processing of messages. As it uses ConcurrentLinkedQueue and incorporates advantages of LinkedBlockingQueue, while providing polling
 * mechanism.
 * </p>
 * 
 * @author thomas
 *
 * @param <T> the Message payload type
 */
public class PollingMessageQueue<T> extends Object {

    private String queueName;

    /* FIFO Message Queue */
    private ConcurrentLinkedQueue<T> queue;

    /* the maximum number of messages to return */
    private int maxMessages = 100;

    /* running indicator */
    private boolean running = false;

    /**
     * Constructor to create a queue.
     * 
     * @param queueName the queue name
     */
    public PollingMessageQueue(String queueName) {
        this.queueName = queueName;
        queue = new ConcurrentLinkedQueue<T>();
    }

    /**
     * Constructor to create a queue.
     * 
     * @param queueName the queue name
     * @param maxMessages the maximum number of messages a polling consumer may receive
     */
    public PollingMessageQueue(String queueName, int maxMessages) {
        this(queueName);
        this.maxMessages = maxMessages;
    }

    /**
     * Add an object to the queue and notify any threads that may be blocked waiting on an empty queue.
     * 
     * @param message the message to add to the queue
     */
    public final synchronized void putMessage(T message) {
        if (message != null) {
            queue.add(message);
        }
        notifyAll();
    }

    /**
     * Get the name of this queue.
     * 
     * @return the queueName
     */
    public String getQueueName() {
        return queueName;
    }

    /**
     * If the queue is empty then wait until notified. Otherwise return the first object in the queue.
     * 
     * @return Message the first message in the queue
     * @throws InterruptedException if interrupted unexpectedly
     */
    public final synchronized T getMessage() throws InterruptedException {
        T message = null;
        while (running && queue.isEmpty()) {
            wait();
        }
        if (!queue.isEmpty()) {
            message = queue.remove();
        }
        return message;
    }

    /**
     * Poll for available messages from none to maxRecords.
     * 
     * @param timeoutMillis the timeout period between polls
     * @return a List of messages which may be empty
     */
    public final List<T> poll(int timeoutMillis) {
        try {
            Thread.sleep(timeoutMillis);
        } catch (InterruptedException e1) {
            ;
        }
        return getMessages();
    }

    /**
     * Get all available messages off the queue up to the maximum number of messages set.
     * 
     * @return a list of zero to max messages
     */
    private final synchronized List<T> getMessages() {
        List<T> list = new ArrayList<>();
        int recordCount = 0;
        while (running && queue.isEmpty() == false && recordCount < maxMessages) {
            T message = queue.remove();
            list.add(message);
            recordCount++;
        }
        return list;
    }

    /**
     * Enable the queue.
     */
    public final synchronized void start() {
        running = true;
    }

    /**
     * Get the backlog of messages in the queue.
     * 
     * @return the size of the backlog
     */
    public synchronized int getBacklog() {
        int backlog = queue.size();
        return backlog;
    }

    /**
     * Get the maximum records that may be returned.
     * 
     * @return the maxMessages
     */
    public int getMaxMessages() {
        return maxMessages;
    }

    /**
     * Set or reset the maxMessages.
     * 
     * @param maxMessages the maxMessages to set
     */
    public void setMaxMessages(int maxMessages) {
        this.maxMessages = maxMessages;
    }

    /**
     * Reset the queue and dispose of all queued objects.
     */
    public synchronized void reset() {
        queue.clear();
    }

    /**
     * Disable and stop the queue. This does not clear out any objects that may be in queue when it stops.
     */
    public synchronized void stop() {
        running = false;
        notifyAll();
    }
}
