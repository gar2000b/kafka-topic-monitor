package com.rbc.deposits.util;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

/**
 * DateStringUtil supports date and math operations on date strings.
 * 
 * @author 316746874
 *
 */
public class DateStringUtil {

    public static final String YEAR_MONTH_FORMAT = "yyyy-MM";

    public static final String YEAR_MONTH_DAY_FORMAT = "yyyy-MM-dd";

    /**
     * Get the string representation of the current year-month.
     * 
     * @return a String in formatted as 'yyyy-MM'
     */
    public static String getYearMonth() {
        YearMonth yearMonth = YearMonth.now();
        return yearMonth.toString();
    }

    /**
     * Get the String representation of the current year month day.
     * 
     * @return a String in formatted as 'yyyy-MM-dd'
     */
    public static String getYearMonthDay() {
        LocalDate yearMonthDay = LocalDate.now();
        return yearMonthDay.toString();
    }

    /**
     * Perform date math on a date string in the format 'yyyy-MM'.
     * 
     * @param when the sooure year-month
     * @param monthsOffset the number of months to offset
     * @return a String repsenting the offset year-month
     */
    public static String getYearMonthOffset(String when, long monthsOffset) {
        YearMonth yearMonth = YearMonth.parse(when, DateTimeFormatter.ofPattern(YEAR_MONTH_FORMAT));
        yearMonth = yearMonth.plusMonths(monthsOffset);
        return yearMonth.toString();
    }

    /**
     * Perform date math on a date string in the format 'yyyy-MM-dd'.
     * 
     * @param when the source year-month-day
     * @param daysOffset the number of days to offset
     * @return a String repsenting the offset year-month-day
     */
    public static String getYearMonthDayOffset(String when, long daysOffset) {
        LocalDate yearMonthDay = LocalDate.parse(when, DateTimeFormatter.ofPattern(YEAR_MONTH_DAY_FORMAT));
        yearMonthDay = yearMonthDay.plusDays(daysOffset);
        return yearMonthDay.toString();
    }
    
    /**
     * Strip out '-' from an ISO formatted dates.
     * 
     * @param when the source year-month[-day]
     * @return yyyyMM[dd]
     */
    public static String strip(String when) {
        return when.replace("-", "");
    }

}
