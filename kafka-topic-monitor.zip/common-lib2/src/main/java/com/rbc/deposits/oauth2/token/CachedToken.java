package com.rbc.deposits.oauth2.token;

public class CachedToken {

    private String token;
    private Integer expiresIn;
    private Long expiresBy;

    /**
     * Returns the value of token.
     * 
     * @return the token
     */
    public String getToken() {
        return token;
    }

    /**
     * @param token used to set the token.
     */
    public void setToken(String token) {
        this.token = token;
    }

    /**
     * Returns the value of expiresIn.
     * 
     * @return the expiresIn
     */
    protected Integer getExpiresIn() {
        return expiresIn;
    }

    /**
     * @param expiresIn used to set the expiresIn.
     */
    protected void setExpiresIn(Integer expiresIn) {
        this.expiresIn = expiresIn;
    }

    /**
     * Returns the value of expiresBy.
     * 
     * @return the expiresBy
     */
    public Long getExpiresBy() {
        return expiresBy;
    }

    /**
     * @param expiresBy used to set the expiresBy.
     */
    public void setExpiresBy(Long expiresBy) {
        this.expiresBy = expiresBy;
    }

    @Override
    public String toString() {
        return String.format("CachedToken [token=%s, expiresIn=%s, expiresBy=%s]", token, expiresIn, expiresBy);
    }

}
