package com.rbc.deposits.ims;

/**
 * Simple IMS Center Code utility.
 * 
 * @author 316746874
 *
 */
public class ImsUtil {

    /**
     * Case-insensitive derivation of IMS processing center from a center code.
     * 
     * @param centerCode the source center code
     * @return the IMS processing center
     */
    public static String getImsCenter(String centerCode) {
        switch (centerCode.toLowerCase()) {
            case "occ":
                return "OBW";
            case "qcc":
                return "QBW";
            case "bcc":
                return "BBW";
            default:
                return "";
        }
    }
}
