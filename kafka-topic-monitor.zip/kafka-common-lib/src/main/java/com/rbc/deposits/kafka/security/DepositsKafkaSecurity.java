package com.rbc.deposits.kafka.security;

public interface DepositsKafkaSecurity {

    default String reformatYmlSecurityString(String ymlConfig) {
        return ymlConfig.replace("{keytabFile}", "'{keytabFile}'").replace("principal=", "principal='").replace(".COM;", ".COM';");
    }
}
