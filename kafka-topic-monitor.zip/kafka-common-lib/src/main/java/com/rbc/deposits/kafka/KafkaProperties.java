package com.rbc.deposits.kafka;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "kafka")
public class KafkaProperties {

    @Value("${bootstrap.servers:ulvukf001.saifg.rbc.com:9092,ulvukf002.saifg.rbc.com:9092,ulvukf003.saifg.rbc.com:9092,ulvukf004.saifg.rbc.com:9092}")
    private String bootstrapServers;
    
    @Value("${schema.registry.url:http://cpeg-kafka-schema-uat.saifg.rbc.com:8081}")
    private String schemaRegistryUrl;
    
    @Value("${security.java.security.krb5.realm:SAIFG.RBC.COM}")
    private String krb5Realm;

    @Value("${security.java.security.krb5.kdc:saifg.rbc.com}")
    private String krb5Kdc;

    @Value("${security.sun.security.krb5.debug:false}")
    private String krb5Debug;
    
    @Value("${security.truststore.file.name:kafka-security.jks}")
    private String trustStoreFile;
    
    @Value("${security.truststore.password:FAKE_PASSWORD}")
    private String trustStorePassword;
    
    @Value("${security.protocol:SASL_SSL}")
    private String securityProtocol;
    
    @Value("${security.sasl.kerberos.service.name:kafka}")
    private String kerberosServiceName;
    
    private Map<String, TopicConfigModel> topicConfigs;

    public Map<String, TopicConfigModel> getTopicConfigs() {
        return topicConfigs;
    }

    public void setTopicConfigs(Map<String, TopicConfigModel> topicConfigs) {
        this.topicConfigs = topicConfigs;
    }

    /**
     * Returns the value of bootstrapServers.
     * 
     * @return the bootstrapServers
     */
    public String getBootstrapServers() {
        return bootstrapServers;
    }

    /**
     * @param bootstrapServers used to set the bootstrapServers.
     */
    public void setBootstrapServers(String bootstrapServers) {
        this.bootstrapServers = bootstrapServers;
    }

    /**
     * Returns the value of schemaRegistryUrl.
     * 
     * @return the schemaRegistryUrl
     */
    public String getSchemaRegistryUrl() {
        return schemaRegistryUrl;
    }

    /**
     * @param schemaRegistryUrl used to set the schemaRegistryUrl.
     */
    public void setSchemaRegistryUrl(String schemaRegistryUrl) {
        this.schemaRegistryUrl = schemaRegistryUrl;
    }

    /**
     * Returns the value of krb5Realm.
     * 
     * @return the krb5Realm
     */
    public String getKrb5Realm() {
        return krb5Realm;
    }

    /**
     * @param krb5Realm used to set the krb5Realm.
     */
    public void setKrb5Realm(String krb5Realm) {
        this.krb5Realm = krb5Realm;
    }

    /**
     * Returns the value of krb5Kdc.
     * 
     * @return the krb5Kdc
     */
    public String getKrb5Kdc() {
        return krb5Kdc;
    }

    /**
     * @param krb5Kdc used to set the krb5Kdc.
     */
    public void setKrb5Kdc(String krb5Kdc) {
        this.krb5Kdc = krb5Kdc;
    }

    /**
     * Returns the value of krb5Debug.
     * 
     * @return the krb5Debug
     */
    public String getKrb5Debug() {
        return krb5Debug;
    }

    /**
     * @param krb5Debug used to set the krb5Debug.
     */
    public void setKrb5Debug(String krb5Debug) {
        this.krb5Debug = krb5Debug;
    }

    /**
     * Returns the value of trustStoreFile.
     * 
     * @return the trustStoreFile
     */
    public String getTrustStoreFile() {
        return trustStoreFile;
    }

    /**
     * @param trustStoreFile used to set the trustStoreFile.
     */
    public void setTrustStoreFile(String trustStoreFile) {
        this.trustStoreFile = trustStoreFile;
    }

    /**
     * Returns the value of trustStorePassword.
     * 
     * @return the trustStorePassword
     */
    public String getTrustStorePassword() {
        return trustStorePassword;
    }

    /**
     * @param trustStorePassword used to set the trustStorePassword.
     */
    public void setTrustStorePassword(String trustStorePassword) {
        this.trustStorePassword = trustStorePassword;
    }

    /**
     * Returns the value of securityProtocol.
     * 
     * @return the securityProtocol
     */
    public String getSecurityProtocol() {
        return securityProtocol;
    }

    /**
     * @param securityProtocol used to set the securityProtocol.
     */
    public void setSecurityProtocol(String securityProtocol) {
        this.securityProtocol = securityProtocol;
    }

    /**
     * Returns the value of kerberosServiceName.
     * 
     * @return the kerberosServiceName
     */
    public String getKerberosServiceName() {
        return kerberosServiceName;
    }

    /**
     * @param kerberosServiceName used to set the kerberosServiceName.
     */
    public void setKerberosServiceName(String kerberosServiceName) {
        this.kerberosServiceName = kerberosServiceName;
    }

    @Override
    public String toString() {
        return String.format("KafkaProperties [bootstrapServers=%s, schemaRegistryUrl=%s, krb5Realm=%s, krb5Kdc=%s, krb5Debug=%s, trustStoreFile=%s, securityProtocol=%s, kerberosServiceName=%s]",
                        bootstrapServers, schemaRegistryUrl, krb5Realm, krb5Kdc, krb5Debug, trustStoreFile, securityProtocol, kerberosServiceName);
    }

}
